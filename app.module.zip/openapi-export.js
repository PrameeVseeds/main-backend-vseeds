"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const swagger_1 = require("@nestjs/swagger");
const fs_1 = require("fs");
const path_1 = require("path");
const app_module_1 = require("./app.module");
async function exportOpenApi() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.setGlobalPrefix('api');
    const config = new swagger_1.DocumentBuilder()
        .setTitle('VSEEDS API')
        .setDescription('Centralized backend API for VSEEDS applications')
        .setVersion('1.0')
        .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'access-token')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, config);
    const outputPath = process.env['OPENAPI_OUTPUT'] || (0, path_1.join)(process.cwd(), 'openapi.json');
    (0, fs_1.writeFileSync)(outputPath, JSON.stringify(document, null, 2), 'utf-8');
    console.log(`OpenAPI spec written to ${outputPath}`);
    await app.close();
}
exportOpenApi().catch((err) => {
    console.error(err);
    process.exit(1);
});
//# sourceMappingURL=openapi-export.js.map