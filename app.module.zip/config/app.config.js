"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAppConfig = void 0;
const getAppConfig = (configService) => ({
    port: configService.get('PORT', 3000),
    nodeEnv: configService.get('NODE_ENV', 'development'),
    apiPrefix: configService.get('API_PREFIX', 'api'),
    adminOrigin: configService.get('ADMIN_ORIGIN', 'http://localhost:4200'),
    electronicsOrigin: configService.get('ELECTRONICS_ORIGIN', 'http://localhost:4201'),
    embeddedOrigin: configService.get('EMBEDDED_ORIGIN', 'http://localhost:4202'),
    throttleTtl: configService.get('THROTTLE_TTL', 60000),
    throttleLimit: configService.get('THROTTLE_LIMIT', 100),
    twoFactorAppName: configService.get('TWO_FACTOR_APP_NAME', 'VSEEDS'),
});
exports.getAppConfig = getAppConfig;
//# sourceMappingURL=app.config.js.map