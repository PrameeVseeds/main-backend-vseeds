"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStorageConfig = void 0;
const getStorageConfig = (configService) => ({
    uploadDir: configService.get('UPLOAD_DIR', './storage/uploads'),
    maxFileSize: configService.get('MAX_FILE_SIZE', 2 * 1024 * 1024),
});
exports.getStorageConfig = getStorageConfig;
//# sourceMappingURL=storage.config.js.map