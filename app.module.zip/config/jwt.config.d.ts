import { ConfigService } from '@nestjs/config';
export declare const getJwtConfig: (configService: ConfigService) => {
    accessTokenSecret: string | undefined;
    accessTokenExpiry: string;
    refreshTokenSecret: string | undefined;
    refreshTokenExpiry: string;
};
