declare class EnvironmentVariables {
    DB_HOST: string;
    DB_PORT: number;
    DB_USER: string;
    DB_PASSWORD: string;
    DATABASE: string;
    ACCESS_TOKEN_SECRET: string;
    REFRESH_TOKEN_SECRET: string;
    PORT: number;
    NODE_ENV: string;
    MAIL_HOST: string;
    MAIL_PORT: number;
    MAIL_USERNAME: string;
    MAIL_PASSWORD: string;
    MAIL_FROM_ADDRESS: string;
    MAIL_SECURE: string;
    ADMIN_ORIGIN: string;
    ELECTRONICS_ORIGIN: string;
    EMBEDDED_ORIGIN: string;
    UPLOAD_DIR: string;
    CDN_URL: string;
    DISABLE_ACTIVITY_LOGGING: string;
    ENCRYPTION_KEY: string;
    ENCRYPTION_KEY_ID: string;
}
export declare function validate(config: Record<string, unknown>): EnvironmentVariables;
export {};
