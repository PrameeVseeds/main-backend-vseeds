"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getJwtConfig = void 0;
const getJwtConfig = (configService) => ({
    accessTokenSecret: configService.get('ACCESS_TOKEN_SECRET'),
    accessTokenExpiry: configService.get('ACCESS_TOKEN_EXPIRY', '15m'),
    refreshTokenSecret: configService.get('REFRESH_TOKEN_SECRET'),
    refreshTokenExpiry: configService.get('REFRESH_TOKEN_EXPIRY', '7d'),
});
exports.getJwtConfig = getJwtConfig;
//# sourceMappingURL=jwt.config.js.map