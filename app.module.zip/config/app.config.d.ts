import { ConfigService } from '@nestjs/config';
export declare const getAppConfig: (configService: ConfigService) => {
    port: number;
    nodeEnv: string;
    apiPrefix: string;
    adminOrigin: string;
    electronicsOrigin: string;
    embeddedOrigin: string;
    throttleTtl: number;
    throttleLimit: number;
    twoFactorAppName: string;
};
