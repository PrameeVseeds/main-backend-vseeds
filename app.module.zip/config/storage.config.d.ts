import { ConfigService } from '@nestjs/config';
export declare const getStorageConfig: (configService: ConfigService) => {
    uploadDir: string;
    maxFileSize: number;
};
