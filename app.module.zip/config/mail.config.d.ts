import { ConfigService } from '@nestjs/config';
export declare const getMailConfig: (configService: ConfigService) => {
    host: string;
    port: number;
    username: string | undefined;
    password: string | undefined;
    fromAddress: string | undefined;
    bccSystem: string | undefined;
    bccSales: string | undefined;
    bccAll: string | undefined;
};
