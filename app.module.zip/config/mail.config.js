"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMailConfig = void 0;
const getMailConfig = (configService) => ({
    host: configService.get('MAIL_HOST', 'smtp.gmail.com'),
    port: configService.get('MAIL_PORT', 587),
    username: configService.get('MAIL_USERNAME'),
    password: configService.get('MAIL_PASSWORD'),
    fromAddress: configService.get('MAIL_FROM_ADDRESS'),
    bccSystem: configService.get('MAIL_BCC_SYSTEM'),
    bccSales: configService.get('MAIL_BCC_SALES'),
    bccAll: configService.get('MAIL_BCC_ALL'),
});
exports.getMailConfig = getMailConfig;
//# sourceMappingURL=mail.config.js.map