import { PrismaService } from '../../prisma/prisma.service';
import { CreateEmailTemplateDto } from './dto/create-email-template.dto';
import { UpdateEmailTemplateDto } from './dto/update-email-template.dto';
import { EmailTemplateResponseDto } from './dto/email-template-response.dto';
import { EmailTemplate } from '@prisma/client';
export declare class EmailTemplatesService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private toResponseDto;
    findAll(pagination?: {
        page?: number;
        limit?: number;
    }): Promise<EmailTemplateResponseDto[] | {
        templates: EmailTemplateResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<EmailTemplateResponseDto>;
    findBySlug(slug: string): Promise<EmailTemplate>;
    create(dto: CreateEmailTemplateDto): Promise<EmailTemplateResponseDto>;
    update(id: string, dto: UpdateEmailTemplateDto): Promise<EmailTemplateResponseDto>;
    softDelete(id: string): Promise<{
        message: string;
    }>;
    render(slug: string, data: Record<string, string>): Promise<{
        subject: string;
        html: string;
        text: string | null;
    }>;
    private replacePlaceholders;
}
