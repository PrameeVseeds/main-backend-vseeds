export declare class EmailTemplateResponseDto {
    id: string;
    slug: string;
    name: string;
    category?: string;
    description?: string;
    subject: string;
    htmlBody?: string;
    textBody?: string;
    variables?: string[];
    isActive: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}
