export declare class CreateEmailTemplateDto {
    name: string;
    slug: string;
    category?: string;
    description?: string;
    subject: string;
    htmlBody: string;
    textBody?: string;
    variables?: string[];
    isActive?: boolean;
}
