import { EmailTemplatesService } from './email-templates.service';
import { EmailService } from '../email/email.service';
import { EncryptionService } from '../../common/services/encryption.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreateEmailTemplateDto } from './dto/create-email-template.dto';
import { UpdateEmailTemplateDto } from './dto/update-email-template.dto';
export declare class EmailTemplatesController {
    private readonly emailTemplatesService;
    private readonly emailService;
    private readonly encryptionService;
    constructor(emailTemplatesService: EmailTemplatesService, emailService: EmailService, encryptionService: EncryptionService);
    findAll(page?: string, limit?: string): Promise<import("./dto/email-template-response.dto").EmailTemplateResponseDto[] | {
        templates: import("./dto/email-template-response.dto").EmailTemplateResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<import("./dto/email-template-response.dto").EmailTemplateResponseDto>;
    create(dto: CreateEmailTemplateDto): Promise<import("./dto/email-template-response.dto").EmailTemplateResponseDto>;
    update(id: string, dto: UpdateEmailTemplateDto): Promise<import("./dto/email-template-response.dto").EmailTemplateResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    preview(slug: string, data: Record<string, string>): Promise<{
        subject: string;
        html: string;
        text: string | null;
    }>;
    sendTest(id: string, user: JwtPayload): Promise<{
        success: boolean;
        message: string;
    }>;
}
