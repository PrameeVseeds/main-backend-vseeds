export declare class EmailTemplatesModule {
}
