"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailTemplatesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const email_templates_service_1 = require("./email-templates.service");
const email_service_1 = require("../email/email.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const create_email_template_dto_1 = require("./dto/create-email-template.dto");
const update_email_template_dto_1 = require("./dto/update-email-template.dto");
let EmailTemplatesController = class EmailTemplatesController {
    emailTemplatesService;
    emailService;
    encryptionService;
    constructor(emailTemplatesService, emailService, encryptionService) {
        this.emailTemplatesService = emailTemplatesService;
        this.emailService = emailService;
        this.encryptionService = encryptionService;
    }
    findAll(page, limit) {
        const pagination = page != null && limit != null
            ? { page: Number(page) || 1, limit: Number(limit) || 10 }
            : undefined;
        return this.emailTemplatesService.findAll(pagination);
    }
    findById(id) {
        return this.emailTemplatesService.findById(id);
    }
    create(dto) {
        return this.emailTemplatesService.create(dto);
    }
    update(id, dto) {
        return this.emailTemplatesService.update(id, dto);
    }
    delete(id) {
        return this.emailTemplatesService.softDelete(id);
    }
    preview(slug, data) {
        return this.emailTemplatesService.render(slug, data);
    }
    async sendTest(id, user) {
        const template = await this.emailTemplatesService.findById(id);
        const sampleData = {};
        for (const v of template.variables ?? []) {
            sampleData[v] = `[${v}]`;
        }
        const rendered = await this.emailTemplatesService.render(template.slug, sampleData);
        const recipient = this.encryptionService.decrypt(user.email);
        const sent = await this.emailService.send({
            to: recipient,
            subject: `[TEST] ${rendered.subject}`,
            html: rendered.html,
            text: rendered.text ?? undefined,
        });
        if (!sent) {
            return {
                success: false,
                message: 'Failed to send test email. Check mail configuration.',
            };
        }
        return { success: true, message: `Test email sent to ${recipient}` };
    }
};
exports.EmailTemplatesController = EmailTemplatesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all email templates (optional pagination)' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get email template by ID' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/email-template-response.dto").EmailTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "findById", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create email template' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/email-template-response.dto").EmailTemplateResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_email_template_dto_1.CreateEmailTemplateDto]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update email template' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/email-template-response.dto").EmailTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_email_template_dto_1.UpdateEmailTemplateDto]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete email template (soft)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)('preview/:slug'),
    (0, swagger_1.ApiOperation)({ summary: 'Preview rendered template with sample data' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('slug')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], EmailTemplatesController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)('send-test/:id'),
    (0, swagger_1.ApiOperation)({
        summary: 'Send a test email using this template to the current admin',
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EmailTemplatesController.prototype, "sendTest", null);
exports.EmailTemplatesController = EmailTemplatesController = __decorate([
    (0, swagger_1.ApiTags)('Email Templates'),
    (0, common_1.Controller)('email-templates'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    __metadata("design:paramtypes", [email_templates_service_1.EmailTemplatesService,
        email_service_1.EmailService,
        encryption_service_1.EncryptionService])
], EmailTemplatesController);
//# sourceMappingURL=email-templates.controller.js.map