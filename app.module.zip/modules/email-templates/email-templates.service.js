"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailTemplatesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const client_1 = require("@prisma/client");
let EmailTemplatesService = class EmailTemplatesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    toResponseDto(t) {
        return {
            id: t.id,
            slug: t.slug,
            name: t.name,
            category: t.category,
            description: t.description ?? undefined,
            subject: t.subject,
            htmlBody: t.htmlBody,
            textBody: t.textBody ?? undefined,
            variables: t.variables ? t.variables : undefined,
            isActive: t.isActive,
            createdAt: t.createdAt,
            updatedAt: t.updatedAt,
        };
    }
    async findAll(pagination) {
        const page = pagination?.page ?? 1;
        const limit = pagination?.limit;
        if (limit == null || limit <= 0) {
            const templates = await this.prisma.emailTemplate.findMany({
                orderBy: { name: 'asc' },
            });
            return templates.map((t) => this.toResponseDto(t));
        }
        const skip = (page - 1) * limit;
        const [templates, total] = await this.prisma.$transaction([
            this.prisma.emailTemplate.findMany({
                orderBy: { name: 'asc' },
                skip,
                take: limit,
            }),
            this.prisma.emailTemplate.count(),
        ]);
        return {
            templates: templates.map((t) => this.toResponseDto(t)),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async findById(id) {
        const template = await this.prisma.emailTemplate.findUnique({
            where: { id },
        });
        if (!template)
            throw new common_1.NotFoundException('Email template not found');
        return this.toResponseDto(template);
    }
    async findBySlug(slug) {
        const template = await this.prisma.emailTemplate.findFirst({
            where: { slug, isActive: true },
        });
        if (!template)
            throw new common_1.NotFoundException(`Email template '${slug}' not found`);
        return template;
    }
    async create(dto) {
        const existing = await this.prisma.emailTemplate.findUnique({
            where: { slug: dto.slug },
        });
        if (existing)
            throw new common_1.BadRequestException('Template slug already exists');
        const saved = await this.prisma.emailTemplate.create({
            data: {
                slug: dto.slug,
                name: dto.name,
                category: dto.category || 'general',
                description: dto.description,
                subject: dto.subject,
                htmlBody: dto.htmlBody,
                textBody: dto.textBody,
                variables: dto.variables
                    ? dto.variables
                    : undefined,
                isActive: dto.isActive,
            },
        });
        return this.toResponseDto(saved);
    }
    async update(id, dto) {
        await this.findById(id);
        const data = {};
        if (dto.slug !== undefined)
            data.slug = dto.slug;
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.category !== undefined)
            data.category = dto.category;
        if (dto.description !== undefined)
            data.description = dto.description;
        if (dto.subject !== undefined)
            data.subject = dto.subject;
        if (dto.htmlBody !== undefined)
            data.htmlBody = dto.htmlBody;
        if (dto.textBody !== undefined)
            data.textBody = dto.textBody;
        if (dto.variables !== undefined) {
            data.variables = dto.variables ? dto.variables : client_1.Prisma.DbNull;
        }
        if (dto.isActive !== undefined)
            data.isActive = dto.isActive;
        const updated = await this.prisma.emailTemplate.update({
            where: { id },
            data,
        });
        return this.toResponseDto(updated);
    }
    async softDelete(id) {
        await this.findById(id);
        await this.prisma.emailTemplate.delete({
            where: { id },
        });
        return { message: 'Email template deleted' };
    }
    async render(slug, data) {
        const template = await this.findBySlug(slug);
        const subject = this.replacePlaceholders(template.subject, data);
        const html = this.replacePlaceholders(template.htmlBody, data);
        const text = template.textBody
            ? this.replacePlaceholders(template.textBody, data)
            : null;
        return { subject, html, text };
    }
    replacePlaceholders(content, data) {
        return content.replace(/\{\{(\w+)\}\}/g, (_, key) => data[key] ?? '');
    }
};
exports.EmailTemplatesService = EmailTemplatesService;
exports.EmailTemplatesService = EmailTemplatesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], EmailTemplatesService);
//# sourceMappingURL=email-templates.service.js.map