import { ProjectsService } from './projects.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
export declare class ProjectsController {
    private readonly projectsService;
    constructor(projectsService: ProjectsService);
    findPublic(): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    findById(id: string): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    findAll(): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    upload(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    create(dto: CreateProjectDto): Promise<{
        isPublic: boolean;
        category: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string;
        displayOrder: number;
        imageUrl: string | null;
        title: string;
        technologies: import("@prisma/client/runtime/library").JsonValue | null;
    }>;
    update(id: string, dto: UpdateProjectDto): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
