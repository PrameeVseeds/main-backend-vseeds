import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { Prisma } from '@prisma/client';
export declare class ProjectsService {
    private readonly prisma;
    private readonly configService;
    private readonly logger;
    constructor(prisma: PrismaService, configService: ConfigService);
    private get uploadDir();
    private get baseUrl();
    findPublic(): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    findById(id: string): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    findAll(): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    private mapToFrontend;
    create(dto: CreateProjectDto): Promise<{
        isPublic: boolean;
        category: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string;
        displayOrder: number;
        imageUrl: string | null;
        title: string;
        technologies: Prisma.JsonValue | null;
    }>;
    update(id: string, dto: UpdateProjectDto): Promise<{
        id: string;
        title: string;
        category: string;
        description: string;
        imageUrl: string;
        image: string;
        technologies: string[];
        displayOrder: number;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
    uploadImage(file: Express.Multer.File): Promise<string>;
}
