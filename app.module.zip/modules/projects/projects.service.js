"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ProjectsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const file_upload_validation_1 = require("../../common/utils/file-upload-validation");
const client_1 = require("@prisma/client");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto_1 = require("crypto");
let ProjectsService = ProjectsService_1 = class ProjectsService {
    prisma;
    configService;
    logger = new common_1.Logger(ProjectsService_1.name);
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
    }
    get uploadDir() {
        const dir = this.configService.get('UPLOAD_DIR');
        if (dir) {
            if (dir.startsWith('./') || dir.startsWith('../')) {
                return path.resolve(dir);
            }
            return dir;
        }
        const fallback = path.resolve(__dirname, '../../../../public_html/upload_vseeds/images');
        this.logger.warn(`UPLOAD_DIR not set. Falling back to: ${fallback}. Set UPLOAD_DIR in your .env file.`);
        return fallback;
    }
    get baseUrl() {
        return this.configService.get('CDN_URL') || 'https://cdn.vseeds.lk';
    }
    async findPublic() {
        const projects = await this.prisma.project.findMany({
            where: { isPublic: true },
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'desc' }],
        });
        return projects.map((p) => this.mapToFrontend(p));
    }
    async findById(id) {
        const project = await this.prisma.project.findUnique({
            where: { id },
        });
        if (!project)
            throw new common_1.NotFoundException('Project not found');
        return this.mapToFrontend(project);
    }
    async findAll() {
        const projects = await this.prisma.project.findMany({
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'desc' }],
        });
        return projects.map((p) => this.mapToFrontend(p));
    }
    mapToFrontend(p) {
        const defaultImg = 'uploads/general/default-project-img.png';
        return {
            id: p.id,
            title: p.title,
            category: p.category,
            description: p.description,
            imageUrl: p.imageUrl || defaultImg,
            image: p.imageUrl || defaultImg,
            technologies: p.technologies,
            displayOrder: p.displayOrder,
            isActive: p.isPublic,
            createdAt: p.createdAt,
            updatedAt: p.updatedAt,
        };
    }
    async create(dto) {
        return this.prisma.project.create({
            data: {
                title: dto.title,
                category: dto.category || 'general',
                description: dto.description,
                imageUrl: dto.imageUrl,
                technologies: dto.technologies ? dto.technologies : undefined,
                displayOrder: dto.displayOrder,
                isPublic: dto.isPublic,
            },
        });
    }
    async update(id, dto) {
        await this.findById(id);
        const data = {};
        if (dto.title !== undefined)
            data.title = dto.title;
        if (dto.category !== undefined)
            data.category = dto.category;
        if (dto.description !== undefined)
            data.description = dto.description;
        if (dto.imageUrl !== undefined)
            data.imageUrl = dto.imageUrl;
        if (dto.technologies !== undefined) {
            data.technologies = dto.technologies ? dto.technologies : client_1.Prisma.JsonNull;
        }
        if (dto.displayOrder !== undefined)
            data.displayOrder = dto.displayOrder;
        if (dto.isPublic !== undefined)
            data.isPublic = dto.isPublic;
        await this.prisma.project.update({
            where: { id },
            data,
        });
        return this.findById(id);
    }
    async remove(id) {
        const project = await this.findById(id);
        if (project.imageUrl?.startsWith(`${this.baseUrl}/`)) {
            const relativePath = project.imageUrl.replace(`${this.baseUrl}/`, '');
            const filepath = path.join(this.uploadDir, relativePath);
            try {
                if (fs.existsSync(filepath))
                    fs.unlinkSync(filepath);
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                this.logger.error('Failed to delete project image from disk:', errMsg);
            }
        }
        await this.prisma.project.delete({
            where: { id },
        });
        return { message: 'Project deleted' };
    }
    async uploadImage(file) {
        const validation = (0, file_upload_validation_1.validateImageUpload)(file.buffer, file.mimetype, {
            maxSize: file_upload_validation_1.FILE_UPLOAD_LIMITS.image,
        });
        if (!validation.valid) {
            throw new common_1.BadRequestException(validation.error);
        }
        if (validation.detectedMime && file.mimetype !== validation.detectedMime) {
            file.mimetype = validation.detectedMime;
        }
        const filename = `vseeds-projects-${(0, crypto_1.randomUUID)()}${path.extname(file.originalname)}`;
        const target = path.join(this.uploadDir, filename);
        fs.mkdirSync(path.dirname(target), { recursive: true });
        fs.writeFileSync(target, file.buffer);
        return `${this.baseUrl}/${filename}`;
    }
};
exports.ProjectsService = ProjectsService;
exports.ProjectsService = ProjectsService = ProjectsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], ProjectsService);
//# sourceMappingURL=projects.service.js.map