export declare class CreateProjectDto {
    title: string;
    category?: string;
    description: string;
    imageUrl?: string;
    technologies?: string[];
    isPublic?: boolean;
    displayOrder?: number;
}
