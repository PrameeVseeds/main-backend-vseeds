export declare class ProjectResponseDto {
    id: string;
    title: string;
    category?: string;
    description?: string;
    imageUrl?: string;
    image?: string;
    isActive?: boolean;
    isPublic?: boolean;
    technologies?: string[];
    displayOrder?: number;
    createdAt?: Date;
    updatedAt?: Date;
}
