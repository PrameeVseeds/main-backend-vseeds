export declare class ProjectsModule {
}
