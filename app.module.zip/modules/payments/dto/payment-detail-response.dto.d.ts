export declare class PaymentDetailResponseDto {
    id: string;
    orderId: string;
    amount: number;
    status: string;
    paymentMethod?: string;
    paymentNumber?: string;
    referenceNumber?: string;
    paidAt?: Date;
    createdAt?: Date;
    orderNumber?: string;
    orderTotal?: number;
    userEmail?: string;
    firstName?: string;
    lastName?: string;
    userId?: string;
}
