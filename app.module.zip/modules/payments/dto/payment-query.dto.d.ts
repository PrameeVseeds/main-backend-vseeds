import { PaginationDto } from '../../../common/dto/pagination.dto';
export declare class PaymentQueryDto extends PaginationDto {
    status?: string;
}
