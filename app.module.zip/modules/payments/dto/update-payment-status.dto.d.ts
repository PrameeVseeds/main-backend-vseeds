export declare class UpdatePaymentStatusDto {
    status: string;
    referenceNumber?: string;
}
