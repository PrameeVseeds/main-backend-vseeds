export declare class CreatePaymentDto {
    orderId: string;
    amount: number;
    paymentMethod: string;
    referenceNumber?: string;
    receiptUrl?: string;
}
