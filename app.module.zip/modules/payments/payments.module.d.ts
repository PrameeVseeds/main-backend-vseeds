export declare class PaymentsModule {
}
