import { PaymentsService } from './payments.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreatePaymentDto } from './dto/create-payment.dto';
import { UpdatePaymentStatusDto } from './dto/update-payment-status.dto';
import { PaymentQueryDto } from './dto/payment-query.dto';
export declare class PaymentsController {
    private readonly paymentsService;
    constructor(paymentsService: PaymentsService);
    create(dto: CreatePaymentDto): Promise<{
        amount: number;
        referenceNumber: string | undefined;
        receiptUrl: string | undefined;
        paidAt: Date | undefined;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.PaymentStatus;
        orderId: string;
        paymentNumber: string;
        paymentMethod: import(".prisma/client").$Enums.PaymentMethod;
    }>;
    delete(paymentId: string): Promise<{
        message: string;
    }>;
    findByUser(user: JwtPayload, query: PaymentQueryDto): Promise<{
        payments: {
            amount: number;
            referenceNumber: string | undefined;
            receiptUrl: string | undefined;
            paidAt: Date | undefined;
            order: {
                subtotal: number;
                shippingFee: number;
                discountAmount: number;
                totalAmount: number;
                deletedAt: Date | null;
                promoCode: string | null;
                id: string;
                userId: string;
                createdAt: Date;
                updatedAt: Date;
                status: import(".prisma/client").$Enums.OrderStatus;
                orderNumber: string;
                shippingAddressId: string | null;
                orderType: import(".prisma/client").$Enums.OrderType;
                quoteId: string | null;
                taxAmount: import("@prisma/client/runtime/library").Decimal;
                promoCodeId: string | null;
                customerNotes: string | null;
                adminNotes: string | null;
                version: number;
            } | undefined;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.PaymentStatus;
            orderId: string;
            paymentNumber: string;
            paymentMethod: import(".prisma/client").$Enums.PaymentMethod;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(user: JwtPayload, paymentId: string): Promise<import("./dto/payment-detail-response.dto").PaymentDetailResponseDto>;
    findAll(query: PaymentQueryDto): Promise<{
        payments: {
            id: string;
            orderId: string;
            amount: number;
            status: import(".prisma/client").$Enums.PaymentStatus;
            paymentMethod: import(".prisma/client").$Enums.PaymentMethod;
            paymentNumber: string;
            referenceNumber: string | undefined;
            paidAt: Date | undefined;
            createdAt: Date;
            orderNumber: string;
            orderTotal: number;
            userEmail: string;
            firstName: string;
            lastName: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        total: number;
        pending: number;
        completed: number;
        failed: number;
        refunded: number;
    }>;
    countByType(): Promise<{
        paymentMethod: import(".prisma/client").$Enums.PaymentMethod;
        count: number;
    }[]>;
    updateStatus(orderId: string, dto: UpdatePaymentStatusDto): Promise<{
        amount: number;
        referenceNumber: string | undefined;
        receiptUrl: string | undefined;
        paidAt: Date | undefined;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.PaymentStatus;
        orderId: string;
        paymentNumber: string;
        paymentMethod: import(".prisma/client").$Enums.PaymentMethod;
    }>;
}
