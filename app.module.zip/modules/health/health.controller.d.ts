import { PrismaService } from '../../prisma/prisma.service';
import { SettingsService } from '../settings/settings.service';
export declare class HealthController {
    private readonly prisma;
    private readonly settingsService;
    constructor(prisma: PrismaService, settingsService: SettingsService);
    live(): {
        status: string;
        timestamp: string;
    };
    ready(): Promise<{
        status: string;
        database: string;
        timestamp: string;
    }>;
    check(): Promise<{
        status: string;
        database: string;
        maintenanceMode: boolean;
        maintenanceMessage: string;
        uptime: number;
        timestamp: string;
    }>;
}
