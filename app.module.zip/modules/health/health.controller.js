"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const prisma_service_1 = require("../../prisma/prisma.service");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const settings_service_1 = require("../settings/settings.service");
let HealthController = class HealthController {
    prisma;
    settingsService;
    constructor(prisma, settingsService) {
        this.prisma = prisma;
        this.settingsService = settingsService;
    }
    live() {
        return { status: 'ok', timestamp: new Date().toISOString() };
    }
    async ready() {
        let dbStatus = 'disconnected';
        try {
            await this.prisma.$queryRawUnsafe('SELECT 1');
            dbStatus = 'connected';
        }
        catch {
            dbStatus = 'error';
        }
        return {
            status: dbStatus === 'connected' ? 'ok' : 'degraded',
            database: dbStatus,
            timestamp: new Date().toISOString(),
        };
    }
    async check() {
        let dbStatus = 'disconnected';
        try {
            await this.prisma.$queryRawUnsafe('SELECT 1');
            dbStatus = 'connected';
        }
        catch {
            dbStatus = 'error';
        }
        const maintenanceMode = await this.settingsService.getTyped('maintenanceMode', false);
        const maintenanceMessage = await this.settingsService.get('maintenanceMessage');
        return {
            status: 'ok',
            database: dbStatus,
            maintenanceMode,
            maintenanceMessage: maintenanceMessage || '',
            uptime: process.uptime(),
            timestamp: new Date().toISOString(),
        };
    }
};
exports.HealthController = HealthController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('live'),
    (0, swagger_1.ApiOperation)({
        summary: 'Liveness: process is running (e.g. K8s liveness probe)',
    }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HealthController.prototype, "live", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('ready'),
    (0, swagger_1.ApiOperation)({
        summary: 'Readiness: DB connected (e.g. K8s readiness probe)',
    }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "ready", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Health check' }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "check", null);
exports.HealthController = HealthController = __decorate([
    (0, swagger_1.ApiTags)('Health'),
    (0, common_1.Controller)('health'),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        settings_service_1.SettingsService])
], HealthController);
//# sourceMappingURL=health.controller.js.map