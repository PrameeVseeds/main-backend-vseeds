import { WishlistsService } from './wishlists.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { AddWishlistDto } from './dto/add-wishlist.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class WishlistsController {
    private readonly wishlistsService;
    constructor(wishlistsService: WishlistsService);
    add(user: JwtPayload, dto: AddWishlistDto): Promise<{
        id: string;
        userId: string;
        createdAt: Date;
        productId: string;
    }>;
    remove(user: JwtPayload, productId: string): Promise<{
        message: string;
    }>;
    getByUserEmail(email: string, query: {
        page?: number;
        limit?: number;
    }): Promise<import("./dto/wishlist-item-response.dto").WishlistItemResponseDto[] | {
        items: import("./dto/wishlist-item-response.dto").WishlistItemResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    countForProduct(productId: string): Promise<{
        count: number;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        productId: string;
        productName: string;
        sku: string | null;
        quantityInHand: string | number | null;
        wishlistCount: number;
    }[]>;
    getUsersForProduct(productId: string): Promise<{
        id: string;
        createdAt: Date;
        user: {
            id: string;
            email: string;
            username: string;
        } | null;
    }[]>;
}
