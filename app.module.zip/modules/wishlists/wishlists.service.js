"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WishlistsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let WishlistsService = class WishlistsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async add(userId, productId) {
        const existing = await this.prisma.wishlist.findUnique({
            where: {
                uq_wish: { userId, productId },
            },
        });
        if (existing)
            throw new common_1.BadRequestException('Product already in wishlist');
        return this.prisma.wishlist.create({
            data: { userId, productId },
        });
    }
    async remove(userId, productId) {
        const item = await this.prisma.wishlist.findUnique({
            where: {
                uq_wish: { userId, productId },
            },
        });
        if (!item)
            throw new common_1.BadRequestException('Product not in wishlist');
        await this.prisma.wishlist.delete({
            where: { id: item.id },
        });
        return { message: 'Removed from wishlist' };
    }
    async getByUser(userId) {
        return this.getWishlistItemsRaw(userId, 'id');
    }
    async getByUserEmail(email, pagination) {
        const all = await this.getWishlistItemsRaw(email, 'email');
        if (pagination?.page != null || pagination?.limit != null) {
            const page = Math.max(1, pagination.page ?? 1);
            const limit = Math.min(100, Math.max(1, pagination.limit ?? 20));
            const total = all.length;
            const start = (page - 1) * limit;
            const items = all.slice(start, start + limit);
            return { items, total, totalPages: Math.ceil(total / limit), page };
        }
        return all;
    }
    async getWishlistItemsRaw(userIdOrEmail, by) {
        const where = {};
        if (by === 'id') {
            where.userId = userIdOrEmail;
        }
        else {
            where.user = { email: userIdOrEmail };
        }
        const items = await this.prisma.wishlist.findMany({
            where: {
                ...where,
                product: {
                    deletedAt: null,
                },
            },
            include: {
                product: {
                    include: {
                        category: true,
                        productMedia: {
                            where: {
                                isThumbnail: true,
                            },
                            include: {
                                media: true,
                            },
                            take: 1,
                        },
                        priceTiers: {
                            where: {
                                minQuantity: 1,
                            },
                            take: 1,
                        },
                    },
                },
            },
            orderBy: {
                createdAt: 'desc',
            },
        });
        return items.map((item) => {
            const p = item.product;
            const thumbnailMedia = p.productMedia[0]?.media;
            const thumbnailUrl = thumbnailMedia?.url;
            const priceTier = p.priceTiers[0];
            const price = priceTier ? Number(priceTier.price) : undefined;
            const categoryName = p.category?.name;
            return {
                id: item.id,
                productId: item.productId,
                createdAt: item.createdAt,
                product: {
                    id: p.id,
                    name: p.name,
                    slug: p.slug,
                    thumbnailUrl: thumbnailUrl ?? undefined,
                    image: thumbnailUrl ?? undefined,
                    price: price,
                    categoryName: categoryName ?? undefined,
                    category: categoryName != null ? { name: categoryName } : undefined,
                },
            };
        });
    }
    async countForProduct(productId) {
        const count = await this.prisma.wishlist.count({ where: { productId } });
        return { count };
    }
    async findAll(pagination) {
        const { page = 1, limit = 20 } = pagination;
        const offset = (page - 1) * limit;
        const results = await this.prisma.$queryRaw `
      SELECT 
        w.product_id AS productId, 
        COALESCE(NULLIF(TRIM(p.name), ''), NULLIF(TRIM(p.slug), ''), 'Product unavailable') AS productName, 
        p.sku AS sku, 
        p.quantity_in_hand AS quantityInHand, 
        COUNT(*) AS wishlistCount 
      FROM wishlists w 
      LEFT JOIN products p ON TRIM(p.id) = TRIM(w.product_id) 
      GROUP BY w.product_id, p.name, p.slug, p.sku, p.quantity_in_hand 
      ORDER BY wishlistCount DESC 
      LIMIT ${limit} OFFSET ${offset}
    `;
        return results.map((r) => ({
            productId: r.productId,
            productName: r.productName,
            sku: r.sku,
            quantityInHand: r.quantityInHand,
            wishlistCount: Number(r.wishlistCount),
        }));
    }
    async getUsersForProduct(productId) {
        const list = await this.prisma.wishlist.findMany({
            where: { productId },
            select: {
                id: true,
                createdAt: true,
                user: {
                    select: {
                        id: true,
                        email: true,
                        firstName: true,
                        lastName: true,
                    },
                },
            },
            orderBy: {
                createdAt: 'desc',
            },
        });
        return list.map((w) => ({
            id: w.id,
            createdAt: w.createdAt,
            user: w.user
                ? {
                    id: w.user.id,
                    email: w.user.email,
                    username: `${w.user.firstName} ${w.user.lastName}`.trim(),
                }
                : null,
        }));
    }
};
exports.WishlistsService = WishlistsService;
exports.WishlistsService = WishlistsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WishlistsService);
//# sourceMappingURL=wishlists.service.js.map