export declare class WishlistsModule {
}
