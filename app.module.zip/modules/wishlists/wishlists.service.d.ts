import { PrismaService } from '../../prisma/prisma.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { WishlistItemResponseDto } from './dto/wishlist-item-response.dto';
export declare class WishlistsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    add(userId: string, productId: string): Promise<{
        id: string;
        userId: string;
        createdAt: Date;
        productId: string;
    }>;
    remove(userId: string, productId: string): Promise<{
        message: string;
    }>;
    getByUser(userId: string): Promise<WishlistItemResponseDto[]>;
    getByUserEmail(email: string, pagination?: {
        page?: number;
        limit?: number;
    }): Promise<WishlistItemResponseDto[] | {
        items: WishlistItemResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    private getWishlistItemsRaw;
    countForProduct(productId: string): Promise<{
        count: number;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        productId: string;
        productName: string;
        sku: string | null;
        quantityInHand: string | number | null;
        wishlistCount: number;
    }[]>;
    getUsersForProduct(productId: string): Promise<{
        id: string;
        createdAt: Date;
        user: {
            id: string;
            email: string;
            username: string;
        } | null;
    }[]>;
}
