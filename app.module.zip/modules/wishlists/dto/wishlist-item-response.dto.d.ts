export declare class WishlistProductSummaryDto {
    id: string;
    name: string;
    slug: string;
    thumbnailUrl?: string;
    price?: number;
    categoryName?: string;
}
export declare class WishlistItemResponseDto {
    id: string;
    productId: string;
    createdAt?: Date;
    product: WishlistProductSummaryDto;
}
