"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const prisma_service_1 = require("../../../prisma/prisma.service");
let JwtStrategy = class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy) {
    prisma;
    constructor(configService, prisma) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get('ACCESS_TOKEN_SECRET'),
        });
        this.prisma = prisma;
    }
    async validate(payload) {
        if (!payload.id || !payload.email) {
            throw new common_1.UnauthorizedException('Invalid token payload');
        }
        if (payload.type === 'user') {
            const user = await this.prisma.user.findUnique({
                where: { id: payload.id },
                select: { status: true },
            });
            if (!user || user.status !== 'active') {
                throw new common_1.UnauthorizedException('Account is disabled');
            }
        }
        else if (payload.type === 'admin') {
            const admin = await this.prisma.admin.findUnique({
                where: { id: payload.id },
                select: {
                    status: true,
                    role: { select: { name: true } },
                },
            });
            if (!admin ||
                (admin.role?.name?.toLowerCase() !== 'super admin' &&
                    admin.status !== 'active')) {
                throw new common_1.UnauthorizedException('Account is disabled');
            }
        }
        return payload;
    }
};
exports.JwtStrategy = JwtStrategy;
exports.JwtStrategy = JwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService])
], JwtStrategy);
//# sourceMappingURL=jwt.strategy.js.map