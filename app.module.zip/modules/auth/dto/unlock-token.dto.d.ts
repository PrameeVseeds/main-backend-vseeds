export declare class UnlockTokenDto {
    token: string;
}
