export declare class RequestUnlockDto {
    email: string;
}
