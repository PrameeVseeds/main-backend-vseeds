export declare class UpdateProfileDto {
    username?: string;
    phone?: string;
    address?: string;
}
