export declare class ForgotPasswordDto {
    email: string;
    portal?: 'customer' | 'admin' | 'embedded';
}
