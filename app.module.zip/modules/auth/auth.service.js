"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const bcrypt = __importStar(require("bcryptjs"));
const otplib_1 = require("otplib");
const QRCode = __importStar(require("qrcode"));
const email_queue_service_1 = require("../email/email-queue.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const lookup_hash_util_1 = require("../../common/utils/lookup-hash.util");
const SALT_ROUNDS = 12;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;
let AuthService = AuthService_1 = class AuthService {
    prisma;
    jwtService;
    configService;
    emailQueueService;
    encryptionService;
    logger = new common_1.Logger(AuthService_1.name);
    constructor(prisma, jwtService, configService, emailQueueService, encryptionService) {
        this.prisma = prisma;
        this.jwtService = jwtService;
        this.configService = configService;
        this.emailQueueService = emailQueueService;
        this.encryptionService = encryptionService;
    }
    async userLogin(dto) {
        const user = await this.prisma.user.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
        });
        if (!user) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        if (user.status !== 'active') {
            throw new common_1.UnauthorizedException('Account is disabled');
        }
        const passwordValid = await bcrypt.compare(dto.password, user.passwordHash);
        if (!passwordValid) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        const plainEmail = this.decryptField(user.email);
        const plainFirstName = this.decryptField(user.firstName);
        const plainLastName = this.decryptField(user.lastName);
        const tokens = this.generateTokens({
            id: user.id,
            email: plainEmail,
            role: 'user',
            type: 'user',
        });
        await this.prisma.user.update({
            where: { id: user.id },
            data: {
                refreshToken: tokens.refreshToken,
                lastLoginAt: new Date(),
            },
        });
        return {
            ...tokens,
            user: {
                id: user.id,
                email: plainEmail,
                firstName: plainFirstName,
                lastName: plainLastName,
                role: 'user',
            },
        };
    }
    async userSignup(dto) {
        const emailLookup = (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email');
        const existing = await this.prisma.user.findUnique({
            where: { emailLookup },
        });
        if (existing) {
            throw new common_1.BadRequestException('Email already registered');
        }
        const hashedPassword = await bcrypt.hash(dto.password, SALT_ROUNDS);
        const deletedUser = await this.prisma.user.findFirst({
            where: {
                emailLookup,
                deletedAt: { not: null },
            },
        });
        let savedUser;
        if (deletedUser) {
            savedUser = await this.prisma.user.update({
                where: { id: deletedUser.id },
                data: {
                    deletedAt: null,
                    status: 'active',
                    firstName: dto.firstName,
                    lastName: dto.lastName,
                    phone: dto.phone,
                    passwordHash: hashedPassword,
                },
            });
        }
        else {
            try {
                savedUser = await this.prisma.user.create({
                    data: {
                        firstName: dto.firstName,
                        lastName: dto.lastName,
                        email: dto.email,
                        emailLookup,
                        passwordHash: hashedPassword,
                        phone: dto.phone,
                    },
                });
            }
            catch (err) {
                if (err?.code === 'P2002' && err?.meta?.target?.includes('email_lookup')) {
                    throw new common_1.BadRequestException('Email already registered');
                }
                throw err;
            }
        }
        const tokens = this.generateTokens({
            id: savedUser.id,
            email: savedUser.email,
            role: 'user',
            type: 'user',
        });
        await this.prisma.user.update({
            where: { id: savedUser.id },
            data: {
                refreshToken: tokens.refreshToken,
            },
        });
        try {
            void this.emailQueueService.enqueue('welcome-email', savedUser.email, {
                username: `${savedUser.firstName} ${savedUser.lastName}`.trim(),
            });
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(`Welcome email failed: ${errMsg}`);
        }
        return {
            ...tokens,
            user: {
                id: savedUser.id,
                email: savedUser.email,
                firstName: savedUser.firstName,
                lastName: savedUser.lastName,
                role: 'user',
            },
        };
    }
    async adminLogin(dto) {
        const admin = await this.prisma.admin.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
            include: { role: true },
        });
        if (!admin) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        if (admin.status !== 'active' &&
            admin.role?.name?.toLowerCase() !== 'super admin') {
            throw new common_1.UnauthorizedException('Account is disabled');
        }
        if (admin.lockedUntil) {
            if (new Date() < new Date(admin.lockedUntil)) {
                const remainMs = new Date(admin.lockedUntil).getTime() - Date.now();
                const remainMin = Math.ceil(remainMs / 60_000);
                throw new common_1.UnauthorizedException(`Account is locked. Try again in ${remainMin} minute(s), or use the unlock link sent to your email.`);
            }
            await this.prisma.admin.update({
                where: { id: admin.id },
                data: {
                    lockedUntil: null,
                    failedLoginCount: 0,
                },
            });
            admin.failedLoginCount = 0;
            admin.lockedUntil = null;
        }
        const passwordValid = await bcrypt.compare(dto.password, admin.passwordHash);
        if (!passwordValid) {
            const newFailCount = admin.failedLoginCount + 1;
            const updateData = {
                failedLoginCount: newFailCount,
            };
            if (newFailCount >= MAX_LOGIN_ATTEMPTS) {
                const lockUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60_000);
                updateData.lockedUntil = lockUntil;
                this.logger.warn(`Admin ${admin.email} locked until ${lockUntil.toISOString()} after ${newFailCount} failed attempts`);
                try {
                    void this.emailQueueService.enqueue('admin-account-locked', admin.email, {
                        username: admin.username,
                        lockoutMinutes: String(LOCKOUT_MINUTES),
                    });
                }
                catch (error) {
                    const errMsg = error instanceof Error ? error.message : String(error);
                    this.logger.error(`Lockout notification email failed: ${errMsg}`);
                }
            }
            await this.prisma.admin.update({
                where: { id: admin.id },
                data: updateData,
            });
            if (newFailCount >= MAX_LOGIN_ATTEMPTS) {
                throw new common_1.UnauthorizedException(`Account locked for ${LOCKOUT_MINUTES} minutes due to too many failed attempts. Check your email for an unlock link.`);
            }
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        await this.prisma.admin.update({
            where: { id: admin.id },
            data: {
                failedLoginCount: 0,
                lockedUntil: null,
            },
        });
        if (admin.twoFactorEnabled && admin.twoFactorSecret) {
            const tempToken = this.jwtService.sign({ id: admin.id, email: admin.email, purpose: '2fa-login' }, {
                secret: this.configService.get('ACCESS_TOKEN_SECRET'),
                expiresIn: '5m',
            });
            return { requires2fa: true, tempToken };
        }
        return this.completeAdminLogin(admin);
    }
    async verifyLoginOtp(tempToken, otpCode) {
        let payload;
        try {
            payload = this.jwtService.verify(tempToken, {
                secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('Session expired. Please login again.');
        }
        if (payload.purpose !== '2fa-login') {
            throw new common_1.UnauthorizedException('Invalid token');
        }
        const admin = await this.prisma.admin.findUnique({
            where: { id: payload.id },
            include: { role: true },
        });
        if (!admin || !admin.twoFactorSecret) {
            throw new common_1.UnauthorizedException('Account not found');
        }
        const result = (0, otplib_1.verifySync)({
            token: otpCode,
            secret: admin.twoFactorSecret,
        });
        if (!result.valid) {
            throw new common_1.UnauthorizedException('Invalid verification code');
        }
        return this.completeAdminLogin(admin);
    }
    async completeAdminLogin(admin) {
        const tokens = this.generateTokens({
            id: admin.id,
            email: admin.email,
            role: admin.role?.name || 'admin',
            type: 'admin',
        });
        await this.prisma.admin.update({
            where: { id: admin.id },
            data: {
                refreshToken: tokens.refreshToken,
                lastLoginAt: new Date(),
            },
        });
        return {
            requires2fa: false,
            ...tokens,
            user: {
                id: admin.id,
                email: admin.email,
                username: admin.username,
                role: admin.role?.name,
            },
        };
    }
    async requestAdminUnlock(email) {
        const admin = await this.prisma.admin.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(email, 'email') },
        });
        const genericMsg = 'If the account is locked, an unlock link has been sent to the email.';
        if (!admin ||
            !admin.lockedUntil ||
            new Date() >= new Date(admin.lockedUntil)) {
            return { message: genericMsg };
        }
        const unlockToken = this.jwtService.sign({ id: admin.id, email: admin.email, purpose: 'admin-unlock' }, {
            secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            expiresIn: '30m',
        });
        try {
            void this.emailQueueService.enqueue('admin-account-unlock', admin.email, {
                username: admin.username,
                token: unlockToken,
            });
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(`Unlock email failed: ${errMsg}`);
        }
        return { message: genericMsg };
    }
    async unlockAdminByToken(token) {
        let payload;
        try {
            payload = this.jwtService.verify(token, {
                secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            });
        }
        catch {
            throw new common_1.BadRequestException('Invalid or expired unlock token');
        }
        if (payload.purpose !== 'admin-unlock') {
            throw new common_1.BadRequestException('Invalid token');
        }
        const admin = await this.prisma.admin.findUnique({
            where: { id: payload.id },
        });
        if (!admin) {
            throw new common_1.BadRequestException('Account not found');
        }
        await this.prisma.admin.update({
            where: { id: admin.id },
            data: {
                lockedUntil: null,
                failedLoginCount: 0,
            },
        });
        return { message: 'Account unlocked successfully. You can now log in.' };
    }
    async refreshToken(dto) {
        let payload;
        try {
            payload = this.jwtService.verify(dto.refreshToken, {
                secret: this.configService.get('REFRESH_TOKEN_SECRET'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid or expired refresh token');
        }
        if (payload.type === 'user') {
            const user = await this.prisma.user.findUnique({
                where: { id: payload.id },
            });
            if (!user || user.refreshToken !== dto.refreshToken) {
                throw new common_1.UnauthorizedException('Refresh token revoked');
            }
            const tokens = this.generateTokens({
                id: user.id,
                email: user.email,
                role: 'user',
                type: 'user',
            });
            await this.prisma.user.update({
                where: { id: user.id },
                data: {
                    refreshToken: tokens.refreshToken,
                },
            });
            return tokens;
        }
        if (payload.type === 'admin') {
            const admin = await this.prisma.admin.findUnique({
                where: { id: payload.id },
                include: { role: true },
            });
            if (!admin || admin.refreshToken !== dto.refreshToken) {
                throw new common_1.UnauthorizedException('Refresh token revoked');
            }
            const tokens = this.generateTokens({
                id: admin.id,
                email: admin.email,
                role: admin.role?.name || 'admin',
                type: 'admin',
            });
            await this.prisma.admin.update({
                where: { id: admin.id },
                data: {
                    refreshToken: tokens.refreshToken,
                },
            });
            return tokens;
        }
        throw new common_1.UnauthorizedException('Invalid token type');
    }
    async forgotPassword(dto) {
        let user = null;
        let admin = null;
        let accountType;
        if (dto.portal === 'admin') {
            admin = await this.prisma.admin.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
            });
            if (!admin) {
                return {
                    message: 'If an account exists with this email, a reset link has been sent.',
                };
            }
            accountType = 'admin';
        }
        else if (dto.portal === 'customer' || dto.portal === 'embedded') {
            user = await this.prisma.user.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
            });
            if (!user) {
                return {
                    message: 'If an account exists with this email, a reset link has been sent.',
                };
            }
            accountType = 'user';
        }
        else {
            user = await this.prisma.user.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
            });
            admin = await this.prisma.admin.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
            });
            if (!user && !admin) {
                return {
                    message: 'If an account exists with this email, a reset link has been sent.',
                };
            }
            accountType = user ? 'user' : 'admin';
        }
        const username = user
            ? `${user.firstName} ${user.lastName}`.trim()
            : this.encryptionService.decrypt(admin?.username || '');
        const resetToken = this.jwtService.sign({ email: dto.email, type: accountType }, {
            secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            expiresIn: '1h',
        });
        if (accountType === 'user' && user) {
            await this.prisma.user.update({
                where: { id: user.id },
                data: { resetToken },
            });
        }
        else if (admin) {
            await this.prisma.admin.update({
                where: { id: admin.id },
                data: { resetToken },
            });
        }
        const template = accountType === 'user'
            ? 'customer-password-reset'
            : 'admin-password-reset';
        const resetOrigin = accountType === 'admin'
            ? this.configService.get('ADMIN_ORIGIN')
            : dto.portal === 'embedded'
                ? this.configService.get('EMBEDDED_ORIGIN')
                : this.configService.get('ELECTRONICS_ORIGIN');
        const defaultOrigin = accountType === 'admin'
            ? 'https://www.admin-portal.vseeds.lk'
            : 'https://www.vseeds.lk';
        const resetPath = accountType === 'admin' ? '/auth/reset-password' : '/reset-password';
        const resetUrl = `${resetOrigin ?? defaultOrigin}${resetPath}`;
        try {
            void this.emailQueueService.enqueue(template, dto.email, {
                username,
                token: resetToken,
                resetUrl,
            });
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(`Password reset email failed: ${errMsg}`);
        }
        this.logger.log(`Password reset token generated for ${dto.email}`);
        return {
            message: 'If an account exists with this email, a reset link has been sent.',
        };
    }
    async resetPassword(dto) {
        let payload;
        try {
            payload = this.jwtService.verify(dto.token, {
                secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            });
        }
        catch {
            throw new common_1.BadRequestException('Invalid or expired reset token');
        }
        const hashedPassword = await bcrypt.hash(dto.newPassword, SALT_ROUNDS);
        if (payload.type === 'user') {
            const user = await this.prisma.user.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(payload.email, 'email') },
            });
            if (!user || user.resetToken !== dto.token) {
                throw new common_1.BadRequestException('Reset token already used or invalid');
            }
            await this.prisma.user.update({
                where: { id: user.id },
                data: {
                    passwordHash: hashedPassword,
                    resetToken: null,
                },
            });
        }
        else {
            const admin = await this.prisma.admin.findUnique({
                where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(payload.email, 'email') },
            });
            if (!admin || admin.resetToken !== dto.token) {
                throw new common_1.BadRequestException('Reset token already used or invalid');
            }
            await this.prisma.admin.update({
                where: { id: admin.id },
                data: {
                    passwordHash: hashedPassword,
                    resetToken: null,
                },
            });
        }
        return { message: 'Password reset successfully' };
    }
    async getProfile(payload) {
        if (payload.type === 'user') {
            const user = await this.prisma.user.findUnique({
                where: { id: payload.id },
                include: { addresses: true },
            });
            if (!user)
                throw new common_1.UnauthorizedException('User not found');
            return {
                id: user.id,
                email: this.encryptionService.decrypt(user.email),
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                role: 'user',
                type: 'user',
                twoFactorEnabled: user.twoFactorEnabled,
            };
        }
        const admin = await this.prisma.admin.findUnique({
            where: { id: payload.id },
            include: { role: true },
        });
        if (!admin)
            throw new common_1.UnauthorizedException('Admin not found');
        const decryptedEmail = this.encryptionService.decrypt(admin.email);
        const decryptedUsername = this.encryptionService.decrypt(admin.username);
        return {
            id: admin.id,
            email: decryptedEmail,
            username: decryptedUsername,
            role: admin.role?.name,
            type: 'admin',
            phone: admin.phone,
            address: admin.address,
            avatarUrl: admin.avatarUrl,
            createdAt: admin.createdAt,
            twoFactorEnabled: admin.twoFactorEnabled,
        };
    }
    async updateAdminProfile(payload, dto) {
        if (payload.type !== 'admin') {
            throw new common_1.UnauthorizedException('Only admins can update profile here');
        }
        const admin = await this.prisma.admin.findUnique({
            where: { id: payload.id },
        });
        if (!admin)
            throw new common_1.UnauthorizedException('Admin not found');
        const updateData = {};
        if (dto.username !== undefined)
            updateData.username = dto.username;
        if (dto.phone !== undefined)
            updateData.phone = dto.phone;
        if (dto.address !== undefined)
            updateData.address = dto.address;
        await this.prisma.admin.update({
            where: { id: payload.id },
            data: updateData,
        });
        return this.getProfile(payload);
    }
    async get2faEntity(payload) {
        if (payload.type === 'admin') {
            const admin = await this.prisma.admin.findUnique({
                where: { id: payload.id },
            });
            if (!admin)
                throw new common_1.UnauthorizedException('Admin not found');
            return { entity: admin, type: 'admin', issuer: 'VSEEDS Admin' };
        }
        const user = await this.prisma.user.findUnique({
            where: { id: payload.id },
        });
        if (!user)
            throw new common_1.UnauthorizedException('User not found');
        return { entity: user, type: 'user', issuer: 'VSEEDS' };
    }
    async setup2fa(payload) {
        const { entity, type, issuer } = await this.get2faEntity(payload);
        if (entity.twoFactorEnabled) {
            throw new common_1.BadRequestException('2FA is already enabled');
        }
        const secret = (0, otplib_1.generateSecret)();
        if (type === 'admin') {
            await this.prisma.admin.update({
                where: { id: entity.id },
                data: { twoFactorSecret: secret },
            });
        }
        else {
            await this.prisma.user.update({
                where: { id: entity.id },
                data: { twoFactorSecret: secret },
            });
        }
        const otpAuthUrl = (0, otplib_1.generateURI)({ issuer, label: entity.email, secret });
        const qrCodeDataUrl = await QRCode.toDataURL(otpAuthUrl);
        return { secret, qrCode: qrCodeDataUrl };
    }
    async verify2fa(payload, token) {
        const { entity, type } = await this.get2faEntity(payload);
        if (entity.twoFactorEnabled) {
            throw new common_1.BadRequestException('2FA is already enabled');
        }
        if (!entity.twoFactorSecret) {
            throw new common_1.BadRequestException('Run 2FA setup first');
        }
        const result = (0, otplib_1.verifySync)({ token, secret: entity.twoFactorSecret });
        if (!result.valid) {
            throw new common_1.BadRequestException('Invalid verification code');
        }
        if (type === 'admin') {
            await this.prisma.admin.update({
                where: { id: entity.id },
                data: { twoFactorEnabled: true },
            });
        }
        else {
            await this.prisma.user.update({
                where: { id: entity.id },
                data: { twoFactorEnabled: true },
            });
        }
        return { message: 'Two-factor authentication enabled successfully' };
    }
    async disable2fa(payload, token) {
        const { entity, type } = await this.get2faEntity(payload);
        if (!entity.twoFactorEnabled) {
            throw new common_1.BadRequestException('2FA is not enabled');
        }
        const result = (0, otplib_1.verifySync)({ token, secret: entity.twoFactorSecret ?? '' });
        if (!result.valid) {
            throw new common_1.BadRequestException('Invalid verification code');
        }
        if (type === 'admin') {
            await this.prisma.admin.update({
                where: { id: entity.id },
                data: {
                    twoFactorEnabled: false,
                    twoFactorSecret: null,
                },
            });
        }
        else {
            await this.prisma.user.update({
                where: { id: entity.id },
                data: {
                    twoFactorEnabled: false,
                    twoFactorSecret: null,
                },
            });
        }
        return { message: 'Two-factor authentication disabled successfully' };
    }
    generateTokens(payload) {
        const accessToken = this.jwtService.sign(payload, {
            secret: this.configService.get('ACCESS_TOKEN_SECRET'),
            expiresIn: '3h',
        });
        const refreshToken = this.jwtService.sign(payload, {
            secret: this.configService.get('REFRESH_TOKEN_SECRET'),
            expiresIn: '15d',
        });
        return { accessToken, refreshToken };
    }
    decryptField(value) {
        if (!value)
            return '';
        try {
            return this.encryptionService.decrypt(value);
        }
        catch {
            return value;
        }
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        jwt_1.JwtService,
        config_1.ConfigService,
        email_queue_service_1.EmailQueueService,
        encryption_service_1.EncryptionService])
], AuthService);
//# sourceMappingURL=auth.service.js.map