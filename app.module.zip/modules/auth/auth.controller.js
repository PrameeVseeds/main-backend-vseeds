"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const throttler_1 = require("@nestjs/throttler");
const auth_service_1 = require("./auth.service");
const login_dto_1 = require("./dto/login.dto");
const register_dto_1 = require("./dto/register.dto");
const refresh_token_dto_1 = require("./dto/refresh-token.dto");
const forgot_password_dto_1 = require("./dto/forgot-password.dto");
const reset_password_dto_1 = require("./dto/reset-password.dto");
const update_profile_dto_1 = require("./dto/update-profile.dto");
const verify_2fa_dto_1 = require("./dto/verify-2fa.dto");
const request_unlock_dto_1 = require("./dto/request-unlock.dto");
const unlock_token_dto_1 = require("./dto/unlock-token.dto");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
let AuthController = class AuthController {
    authService;
    constructor(authService) {
        this.authService = authService;
    }
    userLogin(dto) {
        return this.authService.userLogin(dto);
    }
    userSignup(dto) {
        return this.authService.userSignup(dto);
    }
    adminLogin(dto) {
        return this.authService.adminLogin(dto);
    }
    verifyLoginOtp(body) {
        return this.authService.verifyLoginOtp(body.tempToken, body.code);
    }
    requestAdminUnlock(dto) {
        return this.authService.requestAdminUnlock(dto.email);
    }
    unlockAdmin(dto) {
        return this.authService.unlockAdminByToken(dto.token);
    }
    refreshToken(dto) {
        return this.authService.refreshToken(dto);
    }
    forgotPassword(dto) {
        return this.authService.forgotPassword(dto);
    }
    resetPassword(dto) {
        return this.authService.resetPassword(dto);
    }
    getProfile(user) {
        return this.authService.getProfile(user);
    }
    updateProfile(user, dto) {
        return this.authService.updateAdminProfile(user, dto);
    }
    setup2fa(user) {
        return this.authService.setup2fa(user);
    }
    verify2fa(user, dto) {
        return this.authService.verify2fa(user, dto.token);
    }
    disable2fa(user, dto) {
        return this.authService.disable2fa(user, dto.token);
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('user-login'),
    (0, swagger_1.ApiOperation)({ summary: 'Customer login' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [login_dto_1.LoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "userLogin", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('user-signup'),
    (0, swagger_1.ApiOperation)({ summary: 'Customer registration' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [register_dto_1.RegisterDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "userSignup", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('admin-login'),
    (0, swagger_1.ApiOperation)({ summary: 'Admin login' }),
    openapi.ApiResponse({ status: 201, type: Object }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [login_dto_1.LoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "adminLogin", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('admin-login/2fa'),
    (0, swagger_1.ApiOperation)({ summary: 'Verify 2FA code to complete admin login' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "verifyLoginOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('admin-unlock/request'),
    (0, swagger_1.ApiOperation)({ summary: 'Request unlock link for locked admin account' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [request_unlock_dto_1.RequestUnlockDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "requestAdminUnlock", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('admin-unlock/verify'),
    (0, swagger_1.ApiOperation)({ summary: 'Unlock admin account using email token' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [unlock_token_dto_1.UnlockTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "unlockAdmin", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('refresh-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Refresh access token' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [refresh_token_dto_1.RefreshTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "refreshToken", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('forgot-password'),
    (0, swagger_1.ApiOperation)({ summary: 'Request password reset' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [forgot_password_dto_1.ForgotPasswordDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "forgotPassword", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('reset-password'),
    (0, swagger_1.ApiOperation)({ summary: 'Reset password with token' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [reset_password_dto_1.ResetPasswordDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "resetPassword", null);
__decorate([
    (0, common_1.Get)('profile'),
    (0, swagger_1.ApiOperation)({ summary: 'Get current user/admin profile' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "getProfile", null);
__decorate([
    (0, common_1.Put)('update-profile'),
    (0, swagger_1.ApiOperation)({ summary: 'Update own admin profile' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, update_profile_dto_1.UpdateProfileDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "updateProfile", null);
__decorate([
    (0, common_1.Post)('2fa/setup'),
    (0, swagger_1.ApiOperation)({ summary: 'Generate 2FA secret and QR code' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "setup2fa", null);
__decorate([
    (0, common_1.Post)('2fa/verify'),
    (0, swagger_1.ApiOperation)({ summary: 'Verify OTP and enable 2FA' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, verify_2fa_dto_1.Verify2faDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "verify2fa", null);
__decorate([
    (0, common_1.Post)('2fa/disable'),
    (0, swagger_1.ApiOperation)({ summary: 'Disable 2FA with OTP verification' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, verify_2fa_dto_1.Verify2faDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "disable2fa", null);
exports.AuthController = AuthController = __decorate([
    (0, throttler_1.Throttle)({ default: { limit: 10, ttl: 60000 } }),
    (0, swagger_1.ApiTags)('Auth'),
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map