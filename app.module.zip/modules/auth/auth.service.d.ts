import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { EmailQueueService } from '../email/email-queue.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { JwtPayload } from './strategies/jwt.strategy';
export declare class AuthService {
    private readonly prisma;
    private readonly jwtService;
    private readonly configService;
    private readonly emailQueueService;
    private readonly encryptionService;
    private readonly logger;
    constructor(prisma: PrismaService, jwtService: JwtService, configService: ConfigService, emailQueueService: EmailQueueService, encryptionService: EncryptionService);
    userLogin(dto: LoginDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: string;
        };
        accessToken: string;
        refreshToken: string;
    }>;
    userSignup(dto: RegisterDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: string;
        };
        accessToken: string;
        refreshToken: string;
    }>;
    adminLogin(dto: LoginDto): Promise<{
        user: {
            id: string;
            email: string;
            username: string;
            role: string | undefined;
        };
        accessToken: string;
        refreshToken: string;
        requires2fa: boolean;
    } | {
        requires2fa: boolean;
        tempToken: string;
    }>;
    verifyLoginOtp(tempToken: string, otpCode: string): Promise<{
        user: {
            id: string;
            email: string;
            username: string;
            role: string | undefined;
        };
        accessToken: string;
        refreshToken: string;
        requires2fa: boolean;
    }>;
    private completeAdminLogin;
    requestAdminUnlock(email: string): Promise<{
        message: string;
    }>;
    unlockAdminByToken(token: string): Promise<{
        message: string;
    }>;
    refreshToken(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    getProfile(payload: JwtPayload): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        role: string;
        type: string;
        twoFactorEnabled: boolean;
        username?: undefined;
        address?: undefined;
        avatarUrl?: undefined;
        createdAt?: undefined;
    } | {
        id: string;
        email: string;
        username: string;
        role: string | undefined;
        type: string;
        phone: string | null;
        address: string | null;
        avatarUrl: string | null;
        createdAt: Date;
        twoFactorEnabled: boolean;
        firstName?: undefined;
        lastName?: undefined;
    }>;
    updateAdminProfile(payload: JwtPayload, dto: {
        username?: string;
        phone?: string;
        address?: string;
    }): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        role: string;
        type: string;
        twoFactorEnabled: boolean;
        username?: undefined;
        address?: undefined;
        avatarUrl?: undefined;
        createdAt?: undefined;
    } | {
        id: string;
        email: string;
        username: string;
        role: string | undefined;
        type: string;
        phone: string | null;
        address: string | null;
        avatarUrl: string | null;
        createdAt: Date;
        twoFactorEnabled: boolean;
        firstName?: undefined;
        lastName?: undefined;
    }>;
    private get2faEntity;
    setup2fa(payload: JwtPayload): Promise<{
        secret: string;
        qrCode: string;
    }>;
    verify2fa(payload: JwtPayload, token: string): Promise<{
        message: string;
    }>;
    disable2fa(payload: JwtPayload, token: string): Promise<{
        message: string;
    }>;
    private generateTokens;
    private decryptField;
}
