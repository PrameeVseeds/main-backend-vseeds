import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { Verify2faDto } from './dto/verify-2fa.dto';
import { RequestUnlockDto } from './dto/request-unlock.dto';
import { UnlockTokenDto } from './dto/unlock-token.dto';
import type { JwtPayload } from './strategies/jwt.strategy';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    userLogin(dto: LoginDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: string;
        };
        accessToken: string;
        refreshToken: string;
    }>;
    userSignup(dto: RegisterDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: string;
        };
        accessToken: string;
        refreshToken: string;
    }>;
    adminLogin(dto: LoginDto): Promise<{
        user: {
            id: string;
            email: string;
            username: string;
            role: string | undefined;
        };
        accessToken: string;
        refreshToken: string;
        requires2fa: boolean;
    } | {
        requires2fa: boolean;
        tempToken: string;
    }>;
    verifyLoginOtp(body: {
        tempToken: string;
        code: string;
    }): Promise<{
        user: {
            id: string;
            email: string;
            username: string;
            role: string | undefined;
        };
        accessToken: string;
        refreshToken: string;
        requires2fa: boolean;
    }>;
    requestAdminUnlock(dto: RequestUnlockDto): Promise<{
        message: string;
    }>;
    unlockAdmin(dto: UnlockTokenDto): Promise<{
        message: string;
    }>;
    refreshToken(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    getProfile(user: JwtPayload): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        role: string;
        type: string;
        twoFactorEnabled: boolean;
        username?: undefined;
        address?: undefined;
        avatarUrl?: undefined;
        createdAt?: undefined;
    } | {
        id: string;
        email: string;
        username: string;
        role: string | undefined;
        type: string;
        phone: string | null;
        address: string | null;
        avatarUrl: string | null;
        createdAt: Date;
        twoFactorEnabled: boolean;
        firstName?: undefined;
        lastName?: undefined;
    }>;
    updateProfile(user: JwtPayload, dto: UpdateProfileDto): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        role: string;
        type: string;
        twoFactorEnabled: boolean;
        username?: undefined;
        address?: undefined;
        avatarUrl?: undefined;
        createdAt?: undefined;
    } | {
        id: string;
        email: string;
        username: string;
        role: string | undefined;
        type: string;
        phone: string | null;
        address: string | null;
        avatarUrl: string | null;
        createdAt: Date;
        twoFactorEnabled: boolean;
        firstName?: undefined;
        lastName?: undefined;
    }>;
    setup2fa(user: JwtPayload): Promise<{
        secret: string;
        qrCode: string;
    }>;
    verify2fa(user: JwtPayload, dto: Verify2faDto): Promise<{
        message: string;
    }>;
    disable2fa(user: JwtPayload, dto: Verify2faDto): Promise<{
        message: string;
    }>;
}
