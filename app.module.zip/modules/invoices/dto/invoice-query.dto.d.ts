import { PaginationDto } from '../../../common/dto/pagination.dto';
export declare class InvoiceQueryDto extends PaginationDto {
    status?: string;
    paymentStatus?: string;
    customer?: string;
    startDate?: string;
    endDate?: string;
}
