export declare class CreateInvoiceDto {
    orderId: string;
    notes?: string;
}
