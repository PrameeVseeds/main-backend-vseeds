"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvoiceQueryDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const pagination_dto_1 = require("../../../common/dto/pagination.dto");
class InvoiceQueryDto extends pagination_dto_1.PaginationDto {
    status;
    paymentStatus;
    customer;
    startDate;
    endDate;
    static _OPENAPI_METADATA_FACTORY() {
        return { status: { required: false, type: () => String }, paymentStatus: { required: false, type: () => String }, customer: { required: false, type: () => String }, startDate: { required: false, type: () => String }, endDate: { required: false, type: () => String } };
    }
}
exports.InvoiceQueryDto = InvoiceQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['draft', 'generated', 'sent', 'paid', 'cancelled', 'all'],
        description: 'Filter by invoice status',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], InvoiceQueryDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['pending', 'completed', 'failed', 'refunded', 'all'],
        description: 'Filter by payment status',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], InvoiceQueryDto.prototype, "paymentStatus", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Search by invoice number, order number, customer name, email or phone',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], InvoiceQueryDto.prototype, "customer", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Start of createdAt date range (ISO 8601)',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], InvoiceQueryDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'End of createdAt date range (ISO 8601)',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], InvoiceQueryDto.prototype, "endDate", void 0);
//# sourceMappingURL=invoice-query.dto.js.map