import { InvoicesService } from './invoices.service';
import { InvoiceQueryDto } from './dto/invoice-query.dto';
export declare class InvoicesController {
    private readonly invoicesService;
    constructor(invoicesService: InvoicesService);
    generateFromOrder(orderId: string): Promise<any>;
    generateAll(): Promise<{
        generated: number;
        total: number;
    }>;
    findAll(query: InvoiceQueryDto): Promise<{
        invoices: any;
        total: any;
        totalPages: number;
        page: number;
    }>;
    findByOrderId(orderId: string): Promise<any>;
    findById(id: string): Promise<any>;
    sendInvoice(id: string): Promise<any>;
}
