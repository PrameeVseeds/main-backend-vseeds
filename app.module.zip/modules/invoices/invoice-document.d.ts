export type InvoiceLayoutId = 'classic' | 'modern' | 'minimal';
export interface InvoiceTemplateSettings {
    layout: InvoiceLayoutId;
    companyName: string;
    companyAddress: string;
    companyPhone: string;
    companyEmail: string;
    companyLogo: string | null;
    accentColor: string;
    notes: string;
    terms: string;
    taxLabel: string;
    signatureName: string;
    signatureTitle: string;
    showLogo: boolean;
    showNotes: boolean;
    showTerms: boolean;
    showSignature: boolean;
}
export declare const INVOICE_LAYOUTS: {
    id: InvoiceLayoutId;
    name: string;
    description: string;
}[];
export interface SampleInvoiceItem {
    no: number;
    name: string;
    qty: number;
    unitPrice: number;
    total: number;
}
export interface SampleInvoiceData {
    invoiceId: string;
    date: string;
    dueDate: string;
    orderNumber: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    status: string;
    items: SampleInvoiceItem[];
    subtotal: number;
    tax: number;
    shipping: number;
    total: number;
}
export declare const DEFAULT_INVOICE_SETTINGS: InvoiceTemplateSettings;
export declare function buildInvoiceCss(): string;
export declare function buildInvoiceBody(s: InvoiceTemplateSettings, sample: SampleInvoiceData): string;
export declare function buildInvoiceDocument(s: InvoiceTemplateSettings, sample: SampleInvoiceData): string;
