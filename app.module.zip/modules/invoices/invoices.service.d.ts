import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { EmailQueueService } from '../email/email-queue.service';
import { InvoiceQueryDto } from './dto/invoice-query.dto';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
export declare class InvoicesService {
    private readonly prisma;
    private readonly encryptionService;
    private readonly emailQueueService;
    constructor(prisma: PrismaService, encryptionService: EncryptionService, emailQueueService: EmailQueueService);
    private get invoiceClient();
    generateFromOrder(orderId: string): Promise<any>;
    findAll(query: InvoiceQueryDto): Promise<{
        invoices: any;
        total: any;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<any>;
    findByOrderId(orderId: string): Promise<any>;
    sendInvoice(id: string): Promise<any>;
    create(dto: CreateInvoiceDto): Promise<any>;
    generateAll(): Promise<{
        generated: number;
        total: number;
    }>;
}
