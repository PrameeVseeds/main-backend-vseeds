export declare class InvoicesModule {
}
