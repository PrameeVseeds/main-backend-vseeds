import { ConfigService } from '@nestjs/config';
export type DumpType = 'latest' | 'old';
export interface DumpMeta {
    fileName: string;
    size: number;
    uploadedAt: string;
}
export interface ImportStatus {
    type: DumpType;
    status: 'running' | 'success' | 'failed';
    startedAt: string;
    finishedAt?: string;
    logTail: string[];
    error?: string;
}
export declare class DatabaseService {
    private readonly config;
    private readonly logger;
    private readonly dumpsDir;
    private readonly metaPath;
    private readonly statuses;
    constructor(config: ConfigService);
    dumpPath(type: DumpType): string;
    private readMeta;
    private writeMeta;
    registerUpload(type: DumpType, file: Express.Multer.File): DumpMeta;
    getDumps(): Record<DumpType, (DumpMeta & {
        exists: boolean;
    }) | null>;
    getImportStatus(type?: DumpType): ImportStatus | {
        latest: ImportStatus | null;
        old: ImportStatus | null;
    } | null;
    private pushLog;
    private dbConfig;
    private splitStatements;
    private sniffDumpFormat;
    importDump(type: DumpType, clearFirst?: boolean): Promise<{
        started: boolean;
    }>;
    private truncateTables;
    private runLatestImport;
    createBackup(): Promise<{
        filePath: string;
        fileName: string;
    }>;
    private syncSchema;
    private runSeed;
    private runOldImport;
}
