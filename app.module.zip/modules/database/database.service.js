"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DatabaseService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const mysql = __importStar(require("mysql2/promise"));
const DUMP_FILES = {
    latest: 'latest_db.sql',
    old: 'old_db.sql',
};
const PRESERVE_TABLES = new Set([
    'admins',
    'roles',
    'privileges',
    'role_privileges',
    'settings',
    'email_templates',
    'invoice_templates',
    'banks',
    '_prisma_migrations',
]);
let DatabaseService = DatabaseService_1 = class DatabaseService {
    config;
    logger = new common_1.Logger(DatabaseService_1.name);
    dumpsDir = path.resolve(process.cwd(), 'db-dumps');
    metaPath = path.join(this.dumpsDir, 'meta.json');
    statuses = new Map();
    constructor(config) {
        this.config = config;
        fs.mkdirSync(this.dumpsDir, { recursive: true });
    }
    dumpPath(type) {
        return path.join(this.dumpsDir, DUMP_FILES[type]);
    }
    readMeta() {
        try {
            return JSON.parse(fs.readFileSync(this.metaPath, 'utf-8'));
        }
        catch {
            return {};
        }
    }
    writeMeta(meta) {
        fs.writeFileSync(this.metaPath, JSON.stringify(meta, null, 2));
    }
    registerUpload(type, file) {
        const meta = this.readMeta();
        const entry = {
            fileName: file.originalname,
            size: file.size,
            uploadedAt: new Date().toISOString(),
        };
        meta[type] = entry;
        this.writeMeta(meta);
        return entry;
    }
    getDumps() {
        const meta = this.readMeta();
        const result = {
            latest: null,
            old: null,
        };
        for (const type of Object.keys(DUMP_FILES)) {
            const m = meta[type];
            const exists = fs.existsSync(this.dumpPath(type));
            result[type] = m && exists ? { ...m, exists } : null;
        }
        return result;
    }
    getImportStatus(type) {
        if (type)
            return this.statuses.get(type) ?? null;
        return {
            latest: this.statuses.get('latest') ?? null,
            old: this.statuses.get('old') ?? null,
        };
    }
    pushLog(st, line) {
        st.logTail.push(line);
        if (st.logTail.length > 200)
            st.logTail.shift();
        this.logger.log(line);
    }
    dbConfig() {
        const url = this.config.get('DATABASE_URL');
        let fromUrl = {};
        if (url) {
            try {
                const u = new URL(url);
                fromUrl = {
                    host: u.hostname,
                    port: Number(u.port) || 3306,
                    user: decodeURIComponent(u.username),
                    password: decodeURIComponent(u.password),
                    database: u.pathname.replace(/^\//, ''),
                };
            }
            catch {
            }
        }
        return {
            host: this.config.get('DB_HOST') || fromUrl.host || 'localhost',
            port: Number(this.config.get('DB_PORT')) || fromUrl.port || 3306,
            user: this.config.get('DB_USER') || fromUrl.user,
            password: this.config.get('DB_PASSWORD') || fromUrl.password,
            database: this.config.get('DATABASE') || fromUrl.database,
        };
    }
    splitStatements(sql) {
        const statements = [];
        let chunk = '';
        for (const line of sql.split('\n')) {
            chunk += line + '\n';
            if (line.trimEnd().endsWith(';')) {
                statements.push(chunk);
                chunk = '';
            }
        }
        if (chunk.trim())
            statements.push(chunk);
        return statements
            .map((s) => s
            .split('\n')
            .filter((l) => !l.trimStart().startsWith('--'))
            .join('\n')
            .trim())
            .filter((s) => s.length > 0 && s !== ';');
    }
    sniffDumpFormat(filePath) {
        let content;
        try {
            content = fs.readFileSync(filePath, 'utf-8');
        }
        catch {
            return 'unknown';
        }
        const hasLegacy = /CREATE TABLE `?(products_list|user_address|user_details|image_details|product_image|resetpassword|contact_replay)`?/i.test(content);
        const hasCurrent = /`(order_number|email_lookup|username_lookup|product_price_tiers|sub_categories)`/i.test(content);
        if (hasLegacy && !hasCurrent)
            return 'legacy';
        if (hasCurrent && !hasLegacy)
            return 'current';
        return 'unknown';
    }
    async importDump(type, clearFirst = false) {
        const filePath = this.dumpPath(type);
        if (!fs.existsSync(filePath)) {
            throw new common_1.NotFoundException(`No ${type} SQL dump uploaded. Upload a file first.`);
        }
        const format = this.sniffDumpFormat(filePath);
        if (type === 'old' && format === 'current') {
            throw new common_1.BadRequestException('This file is a current-schema dump, not a legacy one. Upload it under "Latest DB SQL" and use Run Import instead.');
        }
        if (type === 'latest' && format === 'legacy') {
            throw new common_1.BadRequestException('This file is a legacy-schema dump. Upload it under "Old DB SQL" and use Run Migration instead.');
        }
        const existing = this.statuses.get(type);
        if (existing?.status === 'running') {
            throw new common_1.BadRequestException(`An import for "${type}" is already running`);
        }
        const st = {
            type,
            status: 'running',
            startedAt: new Date().toISOString(),
            logTail: [],
        };
        this.statuses.set(type, st);
        if (type === 'latest') {
            void this.runLatestImport(filePath, st, clearFirst);
        }
        else {
            void this.runOldImport(filePath, st, clearFirst);
        }
        return { started: true };
    }
    async truncateTables(conn, st) {
        const [rows] = await conn.query(`SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'`);
        const tables = rows
            .map((r) => String(Object.values(r)[0]))
            .filter((t) => !PRESERVE_TABLES.has(t));
        for (const t of tables) {
            await conn.query(`TRUNCATE TABLE \`${t}\``);
        }
        const msg = `Cleared ${tables.length} tables (kept: ${[...PRESERVE_TABLES].join(', ')})`;
        if (st)
            this.pushLog(st, msg);
        else
            this.logger.log(msg);
        return tables;
    }
    async runLatestImport(filePath, st, clearFirst = false) {
        const cfg = this.dbConfig();
        if (!cfg.user || !cfg.database) {
            st.status = 'failed';
            st.finishedAt = new Date().toISOString();
            st.error = 'Database credentials not configured (DB_USER/DATABASE or DATABASE_URL)';
            this.pushLog(st, st.error);
            return;
        }
        let conn = null;
        try {
            this.pushLog(st, `Reading dump ${filePath}`);
            const sql = fs.readFileSync(filePath, 'utf-8');
            const statements = this.splitStatements(sql);
            this.pushLog(st, `Executing ${statements.length} statements...`);
            conn = await mysql.createConnection({
                host: cfg.host,
                port: cfg.port,
                user: cfg.user,
                password: cfg.password,
                database: cfg.database,
                multipleStatements: true,
            });
            await conn.query('SET FOREIGN_KEY_CHECKS=0');
            await conn.query('SET UNIQUE_CHECKS=0');
            if (clearFirst) {
                this.pushLog(st, 'Clearing existing data before import...');
                await this.truncateTables(conn, st);
            }
            let executed = 0;
            const errors = [];
            for (const stmt of statements) {
                try {
                    await conn.query(stmt);
                    executed++;
                }
                catch (e) {
                    errors.push(e?.message || String(e));
                    if (errors.length <= 20)
                        this.pushLog(st, `ERR: ${e?.message}`);
                }
            }
            await conn.query('SET FOREIGN_KEY_CHECKS=1');
            await conn.query('SET UNIQUE_CHECKS=1');
            if (errors.length === 0) {
                this.pushLog(st, `Done. ${executed} statements executed.`);
                await this.syncSchema(st);
                st.status = 'success';
            }
            else {
                st.status = 'failed';
                st.error = `${errors.length} statement(s) failed (${executed} succeeded)`;
                this.pushLog(st, st.error);
            }
            st.finishedAt = new Date().toISOString();
        }
        catch (e) {
            st.status = 'failed';
            st.finishedAt = new Date().toISOString();
            st.error = e?.message || String(e);
            this.pushLog(st, `FATAL: ${st.error}`);
        }
        finally {
            await conn?.end().catch(() => undefined);
        }
    }
    async createBackup() {
        const cfg = this.dbConfig();
        if (!cfg.user || !cfg.database) {
            throw new common_1.BadRequestException('Database credentials not configured (DB_USER/DATABASE or DATABASE_URL)');
        }
        const stamp = new Date()
            .toISOString()
            .replace(/[:T]/g, '-')
            .slice(0, 19);
        const fileName = `backup_${cfg.database}_${stamp}.sql`;
        const filePath = path.join(this.dumpsDir, fileName);
        const conn = await mysql.createConnection({
            host: cfg.host,
            port: cfg.port,
            user: cfg.user,
            password: cfg.password,
            database: cfg.database,
        });
        const out = fs.createWriteStream(filePath);
        const write = (s) => new Promise((res, rej) => {
            const ok = out.write(s, (e) => (e ? rej(e) : undefined));
            if (!ok)
                out.once('drain', res);
            else
                res();
        });
        try {
            await write(`-- VSEEDS Database Backup\n` +
                `-- Database: ${cfg.database}\n` +
                `-- Generated: ${new Date().toISOString()}\n\n` +
                `SET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n`);
            const [tables] = await conn.query('SHOW FULL TABLES');
            for (const row of tables) {
                const [name, tableType] = Object.values(row);
                if (tableType === 'VIEW') {
                    const [v] = await conn.query(`SHOW CREATE VIEW \`${name}\``);
                    const createSql = v[0]?.['Create View'];
                    if (createSql) {
                        await write(`-- View: ${name}\nDROP VIEW IF EXISTS \`${name}\`;\n${createSql};\n\n`);
                    }
                    continue;
                }
                const [c] = await conn.query(`SHOW CREATE TABLE \`${name}\``);
                const createSql = c[0]?.['Create Table'];
                if (!createSql)
                    continue;
                await write(`-- Table: ${name}\nDROP TABLE IF EXISTS \`${name}\`;\n${createSql};\n\n`);
                const PAGE = 500;
                let offset = 0;
                let columns = null;
                for (;;) {
                    const [rows, fields] = await conn.query(`SELECT * FROM \`${name}\` LIMIT ${PAGE} OFFSET ${offset}`);
                    if (rows.length === 0)
                        break;
                    if (!columns)
                        columns = fields.map((f) => f.name);
                    const colList = columns.map((col) => `\`${col}\``).join(',');
                    const tuples = [];
                    for (const rec of rows) {
                        tuples.push(`(${columns.map((col) => conn.escape(rec[col])).join(',')})`);
                    }
                    await write(`INSERT INTO \`${name}\` (${colList}) VALUES\n${tuples.join(',\n')};\n`);
                    offset += rows.length;
                    if (rows.length < PAGE)
                        break;
                }
                await write('\n');
            }
            await write(`SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n`);
        }
        finally {
            await conn.end().catch(() => undefined);
            await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
        }
        return { filePath, fileName };
    }
    syncSchema(st) {
        return new Promise((resolve) => {
            const root = process.cwd();
            const prismaBin = path.join(root, 'node_modules', 'prisma', 'build', 'index.js');
            if (!fs.existsSync(prismaBin)) {
                this.pushLog(st, 'WARN: prisma CLI not found — run `npx prisma db push` manually');
                return resolve();
            }
            this.pushLog(st, 'Syncing schema (prisma db push)...');
            const child = (0, child_process_1.spawn)(process.execPath, [prismaBin, 'db', 'push', '--skip-generate', '--accept-data-loss'], { cwd: root, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
            const kill = setTimeout(() => child.kill(), 120_000);
            child.stdout.on('data', (d) => d
                .toString()
                .split('\n')
                .filter(Boolean)
                .forEach((l) => this.pushLog(st, l)));
            child.stderr.on('data', (d) => d
                .toString()
                .split('\n')
                .filter(Boolean)
                .forEach((l) => this.pushLog(st, `ERR: ${l}`)));
            child.on('error', (e) => {
                clearTimeout(kill);
                this.pushLog(st, `WARN: schema sync failed (${e.message}) — run \`npx prisma db push\` manually`);
                resolve();
            });
            child.on('close', (code) => {
                clearTimeout(kill);
                this.pushLog(st, code === 0
                    ? 'Schema synced.'
                    : `WARN: schema sync exited ${code} — run \`npx prisma db push\` manually`);
                resolve();
            });
        });
    }
    runSeed(st) {
        return new Promise((resolve) => {
            const root = process.cwd();
            const tsNodeBin = path.join(root, 'node_modules', 'ts-node', 'dist', 'bin.js');
            const seedScript = path.join(root, 'src', 'seed.ts');
            if (!fs.existsSync(seedScript) || !fs.existsSync(tsNodeBin)) {
                this.pushLog(st, 'WARN: seed script not found — run `npm run seed` manually');
                return resolve();
            }
            this.pushLog(st, 'Restoring default content (seed)...');
            const child = (0, child_process_1.spawn)(process.execPath, [
                tsNodeBin,
                '--transpile-only',
                '-r',
                'tsconfig-paths/register',
                seedScript,
            ], { cwd: root, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
            const kill = setTimeout(() => child.kill(), 180_000);
            child.stdout.on('data', (d) => d
                .toString()
                .split('\n')
                .filter(Boolean)
                .forEach((l) => this.pushLog(st, l)));
            child.stderr.on('data', (d) => d
                .toString()
                .split('\n')
                .filter(Boolean)
                .forEach((l) => this.pushLog(st, `ERR: ${l}`)));
            child.on('error', (e) => {
                clearTimeout(kill);
                this.pushLog(st, `WARN: seed failed (${e.message}) — run \`npm run seed\` manually`);
                resolve();
            });
            child.on('close', (code) => {
                clearTimeout(kill);
                this.pushLog(st, code === 0
                    ? 'Default content restored.'
                    : `WARN: seed exited ${code} — run \`npm run seed\` manually`);
                resolve();
            });
        });
    }
    async runOldImport(filePath, st, clearFirst = false) {
        if (clearFirst) {
            const cfg = this.dbConfig();
            let conn = null;
            try {
                this.pushLog(st, 'Clearing existing data before migration...');
                conn = await mysql.createConnection({
                    host: cfg.host,
                    port: cfg.port,
                    user: cfg.user,
                    password: cfg.password,
                    database: cfg.database,
                });
                await conn.query('SET FOREIGN_KEY_CHECKS=0');
                await this.truncateTables(conn, st);
                await conn.query('SET FOREIGN_KEY_CHECKS=1');
            }
            catch (e) {
                st.status = 'failed';
                st.finishedAt = new Date().toISOString();
                st.error = `Failed to clear database: ${e?.message || e}`;
                this.pushLog(st, `FATAL: ${st.error}`);
                return;
            }
            finally {
                await conn?.end().catch(() => undefined);
            }
        }
        const root = process.cwd();
        const distCandidates = [
            path.join(root, 'dist', 'migrate-old-db.js'),
            path.join(root, 'dist', 'src', 'migrate-old-db.js'),
        ];
        const srcScript = path.join(root, 'src', 'migrate-old-db.ts');
        const tsNodeBin = path.join(root, 'node_modules', 'ts-node', 'dist', 'bin.js');
        const srcMtime = fs.existsSync(srcScript)
            ? fs.statSync(srcScript).mtimeMs
            : 0;
        const distScript = distCandidates.find((p) => fs.existsSync(p) && fs.statSync(p).mtimeMs >= srcMtime);
        const cmd = process.execPath;
        const args = distScript
            ? [distScript, `--file=${filePath}`]
            : [
                tsNodeBin,
                '--transpile-only',
                '-r',
                'tsconfig-paths/register',
                srcScript,
                `--file=${filePath}`,
            ];
        this.pushLog(st, `Starting legacy migration: ${cmd} ${args.join(' ')}`);
        const child = (0, child_process_1.spawn)(cmd, args, {
            cwd: root,
            env: process.env,
        });
        child.stdout.on('data', (d) => d
            .toString()
            .split('\n')
            .filter(Boolean)
            .forEach((l) => this.pushLog(st, l)));
        child.stderr.on('data', (d) => d
            .toString()
            .split('\n')
            .filter(Boolean)
            .forEach((l) => this.pushLog(st, `ERR: ${l}`)));
        child.on('error', (e) => {
            st.status = 'failed';
            st.finishedAt = new Date().toISOString();
            st.error = e.message;
            this.pushLog(st, `FATAL: ${e.message}`);
        });
        child.on('close', (code) => {
            if (code === 0) {
                this.pushLog(st, 'Legacy migration completed.');
                void this.runSeed(st).then(() => {
                    st.status = 'success';
                    st.finishedAt = new Date().toISOString();
                });
            }
            else {
                st.finishedAt = new Date().toISOString();
                st.status = 'failed';
                st.error = `Migration exited with code ${code}`;
                this.pushLog(st, st.error);
            }
        });
    }
};
exports.DatabaseService = DatabaseService;
exports.DatabaseService = DatabaseService = DatabaseService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], DatabaseService);
//# sourceMappingURL=database.service.js.map