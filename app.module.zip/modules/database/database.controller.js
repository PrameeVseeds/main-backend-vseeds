"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const multer_1 = require("multer");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const database_service_1 = require("./database.service");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const DUMPS_DIR = path.resolve(process.cwd(), 'db-dumps');
const DUMP_NAMES = {
    latest: 'latest_db.sql',
    old: 'old_db.sql',
};
function assertType(type) {
    if (type !== 'latest' && type !== 'old') {
        throw new common_1.BadRequestException(`Invalid dump type "${type}". Use "latest" or "old".`);
    }
}
let DatabaseController = class DatabaseController {
    databaseService;
    constructor(databaseService) {
        this.databaseService = databaseService;
    }
    getDumps() {
        return this.databaseService.getDumps();
    }
    async backup(res) {
        const { filePath, fileName } = await this.databaseService.createBackup();
        res.set({
            'Content-Type': 'application/sql',
            'Content-Disposition': `attachment; filename="${fileName}"`,
        });
        return new common_1.StreamableFile(fs.createReadStream(filePath));
    }
    getImportStatus() {
        return this.databaseService.getImportStatus();
    }
    getImportStatusFor(type) {
        assertType(type);
        return this.databaseService.getImportStatus(type);
    }
    uploadDump(type, file) {
        assertType(type);
        if (!file)
            throw new common_1.BadRequestException('No file uploaded');
        return this.databaseService.registerUpload(type, file);
    }
    importDump(type, clear) {
        assertType(type);
        return this.databaseService.importDump(type, clear === 'true');
    }
};
exports.DatabaseController = DatabaseController;
__decorate([
    (0, common_1.Get)('dumps'),
    (0, swagger_1.ApiOperation)({ summary: 'List uploaded SQL dumps (latest + old)' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DatabaseController.prototype, "getDumps", null);
__decorate([
    (0, common_1.Get)('backup'),
    (0, swagger_1.ApiOperation)({ summary: 'Generate and download a full SQL backup of the live database' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DatabaseController.prototype, "backup", null);
__decorate([
    (0, common_1.Get)('import-status'),
    (0, swagger_1.ApiOperation)({ summary: 'Get import status for both dump types' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DatabaseController.prototype, "getImportStatus", null);
__decorate([
    (0, common_1.Get)('import-status/:type'),
    (0, swagger_1.ApiOperation)({ summary: 'Get import status for a dump type' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], DatabaseController.prototype, "getImportStatusFor", null);
__decorate([
    (0, common_1.Post)('upload/:type'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Upload a SQL dump ("latest" full restore or "old" legacy dump)' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: (_req, _file, cb) => {
                fs.mkdirSync(DUMPS_DIR, { recursive: true });
                cb(null, DUMPS_DIR);
            },
            filename: (req, _file, cb) => {
                const type = req.params.type;
                cb(null, DUMP_NAMES[type] ?? `dump_${Date.now()}.sql`);
            },
        }),
        limits: { fileSize: 1024 * 1024 * 1024 },
        fileFilter: (req, file, cb) => {
            const type = req.params.type;
            if (type !== 'latest' && type !== 'old') {
                return cb(new common_1.BadRequestException(`Invalid dump type "${type}". Use "latest" or "old".`), false);
            }
            if (!/\.sql$/i.test(file.originalname)) {
                return cb(new common_1.BadRequestException('Only .sql files are accepted'), false);
            }
            cb(null, true);
        },
    })),
    openapi.ApiResponse({ status: 201, type: Object }),
    __param(0, (0, common_1.Param)('type')),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], DatabaseController.prototype, "uploadDump", null);
__decorate([
    (0, common_1.Post)('import/:type'),
    (0, swagger_1.ApiOperation)({
        summary: 'Run import: "latest" executes the dump on the live DB, "old" runs the legacy migration script. Pass ?clear=true to wipe existing data first (admin/RBAC and system config tables are preserved).',
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('type')),
    __param(1, (0, common_1.Query)('clear')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], DatabaseController.prototype, "importDump", null);
exports.DatabaseController = DatabaseController = __decorate([
    (0, swagger_1.ApiTags)('Database'),
    (0, common_1.Controller)('database'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    __metadata("design:paramtypes", [database_service_1.DatabaseService])
], DatabaseController);
//# sourceMappingURL=database.controller.js.map