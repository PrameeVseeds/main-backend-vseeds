import { StreamableFile } from '@nestjs/common';
import type { Response } from 'express';
import { DatabaseService, DumpType } from './database.service';
export declare class DatabaseController {
    private readonly databaseService;
    constructor(databaseService: DatabaseService);
    getDumps(): Record<DumpType, (import("./database.service").DumpMeta & {
        exists: boolean;
    }) | null>;
    backup(res: Response): Promise<StreamableFile>;
    getImportStatus(): import("./database.service").ImportStatus | {
        latest: import("./database.service").ImportStatus | null;
        old: import("./database.service").ImportStatus | null;
    } | null;
    getImportStatusFor(type: string): import("./database.service").ImportStatus | {
        latest: import("./database.service").ImportStatus | null;
        old: import("./database.service").ImportStatus | null;
    } | null;
    uploadDump(type: string, file: Express.Multer.File): import("./database.service").DumpMeta;
    importDump(type: string, clear?: string): Promise<{
        started: boolean;
    }>;
}
