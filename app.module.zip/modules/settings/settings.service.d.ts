import { PrismaService } from '../../prisma/prisma.service';
import { UpsertSettingDto } from './dto/upsert-setting.dto';
import { SettingResponseDto } from './dto/setting-response.dto';
export declare class SettingsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private toResponseDto;
    findAll(): Promise<SettingResponseDto[]>;
    findByGroup(group: string): Promise<SettingResponseDto[]>;
    getGroups(): Promise<string[]>;
    getPricingSettings(): Promise<{
        shippingFee: number;
        taxEnabled: boolean;
        taxPercentage: number;
    }>;
    getSettingsMap(): Promise<Record<string, unknown>>;
    get(key: string): Promise<string | null>;
    getByKey(key: string): Promise<SettingResponseDto>;
    getTyped<T>(key: string, defaultValue: T): Promise<T>;
    upsert(dto: UpsertSettingDto): Promise<SettingResponseDto>;
    bulkUpsert(dtos: UpsertSettingDto[]): Promise<SettingResponseDto[]>;
    remove(key: string): Promise<{
        message: string;
    }>;
    private castValue;
}
