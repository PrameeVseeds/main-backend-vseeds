"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const settings_service_1 = require("./settings.service");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const upsert_setting_dto_1 = require("./dto/upsert-setting.dto");
const bulk_upsert_dto_1 = require("./dto/bulk-upsert.dto");
const PUBLIC_GROUPS = ['bank-details'];
let SettingsController = class SettingsController {
    settingsService;
    constructor(settingsService) {
        this.settingsService = settingsService;
    }
    findAll() {
        return this.settingsService.findAll();
    }
    getSettingsMap() {
        return this.settingsService.getSettingsMap();
    }
    getGroups() {
        return this.settingsService.getGroups();
    }
    getPricingSettings() {
        return this.settingsService.getPricingSettings();
    }
    findByGroup(group, req) {
        const isAdmin = req.user?.role === 'admin' || req.user?.role === 'super admin';
        if (!PUBLIC_GROUPS.includes(group) && !isAdmin) {
            throw new common_1.ForbiddenException('This settings group requires admin access');
        }
        return this.settingsService.findByGroup(group);
    }
    getByKey(key) {
        return this.settingsService.getByKey(key);
    }
    upsert(dto) {
        return this.settingsService.upsert(dto);
    }
    bulkUpsert(dto) {
        return this.settingsService.bulkUpsert(dto.settings);
    }
    remove(key) {
        return this.settingsService.remove(key);
    }
};
exports.SettingsController = SettingsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all settings (admin)' }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/setting-response.dto").SettingResponseDto] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('map'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all settings as key-value map (admin)' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "getSettingsMap", null);
__decorate([
    (0, common_1.Get)('groups'),
    (0, swagger_1.ApiOperation)({ summary: 'Get setting groups' }),
    openapi.ApiResponse({ status: 200, type: [String] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "getGroups", null);
__decorate([
    (0, common_1.Get)('pricing'),
    (0, public_decorator_1.Public)(),
    (0, swagger_1.ApiOperation)({
        summary: 'Get public pricing settings (shipping fee, tax) for storefronts',
    }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "getPricingSettings", null);
__decorate([
    (0, common_1.Get)('group/:group'),
    (0, public_decorator_1.Public)(),
    (0, swagger_1.ApiOperation)({
        summary: 'Get settings by group (bank-details is public, rest require admin)',
    }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/setting-response.dto").SettingResponseDto] }),
    __param(0, (0, common_1.Param)('group')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "findByGroup", null);
__decorate([
    (0, common_1.Get)('key/:key'),
    (0, swagger_1.ApiOperation)({ summary: 'Get single setting by key (admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/setting-response.dto").SettingResponseDto }),
    __param(0, (0, common_1.Param)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "getByKey", null);
__decorate([
    (0, common_1.Put)(),
    (0, swagger_1.ApiOperation)({ summary: 'Upsert a setting' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/setting-response.dto").SettingResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_setting_dto_1.UpsertSettingDto]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "upsert", null);
__decorate([
    (0, common_1.Post)('bulk'),
    (0, swagger_1.ApiOperation)({ summary: 'Bulk upsert settings' }),
    openapi.ApiResponse({ status: 201, type: [require("./dto/setting-response.dto").SettingResponseDto] }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_upsert_dto_1.BulkUpsertSettingsDto]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "bulkUpsert", null);
__decorate([
    (0, common_1.Delete)(':key'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a setting' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "remove", null);
exports.SettingsController = SettingsController = __decorate([
    (0, swagger_1.ApiTags)('Settings'),
    (0, common_1.Controller)('settings'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    __metadata("design:paramtypes", [settings_service_1.SettingsService])
], SettingsController);
//# sourceMappingURL=settings.controller.js.map