export declare class UpsertSettingDto {
    key: string;
    value: string;
    group?: string;
    description?: string;
    valueType?: string;
}
