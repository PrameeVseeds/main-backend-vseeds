import { UpsertSettingDto } from './upsert-setting.dto';
export declare class BulkUpsertSettingsDto {
    settings: UpsertSettingDto[];
}
