export declare class SettingResponseDto {
    id: string;
    key: string;
    value?: string;
    valueType: string;
    group: string;
    description?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
