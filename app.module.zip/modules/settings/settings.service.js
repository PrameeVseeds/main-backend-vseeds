"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let SettingsService = class SettingsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    toResponseDto(s) {
        return {
            id: s.id,
            key: s.key,
            value: s.value,
            valueType: s.valueType,
            group: s.group,
            description: s.description ?? undefined,
            createdAt: s.createdAt,
            updatedAt: s.updatedAt,
        };
    }
    async findAll() {
        const settings = await this.prisma.setting.findMany({
            orderBy: [{ group: 'asc' }, { key: 'asc' }],
        });
        return settings.map((s) => this.toResponseDto(s));
    }
    async findByGroup(group) {
        const settings = await this.prisma.setting.findMany({
            where: { group },
            orderBy: { key: 'asc' },
        });
        return settings.map((s) => this.toResponseDto(s));
    }
    async getGroups() {
        const result = await this.prisma.setting.findMany({
            select: {
                group: true,
            },
            distinct: ['group'],
        });
        return result.map((r) => r.group).filter(Boolean);
    }
    async getPricingSettings() {
        const [shippingFee, taxEnabled, taxPercentage] = await Promise.all([
            this.getTyped('shippingFee', 0),
            this.getTyped('taxEnabled', false),
            this.getTyped('taxPercentage', 0),
        ]);
        return { shippingFee, taxEnabled, taxPercentage };
    }
    async getSettingsMap() {
        const settings = await this.prisma.setting.findMany({
            select: {
                key: true,
                value: true,
                valueType: true,
            },
        });
        const map = {};
        for (const s of settings) {
            map[s.key] = this.castValue(s.value, s.valueType);
        }
        return map;
    }
    async get(key) {
        const setting = await this.prisma.setting.findUnique({
            where: { key },
            select: { value: true },
        });
        return setting?.value ?? null;
    }
    async getByKey(key) {
        const setting = await this.prisma.setting.findUnique({
            where: { key },
        });
        if (!setting)
            throw new common_1.NotFoundException(`Setting "${key}" not found`);
        return this.toResponseDto(setting);
    }
    async getTyped(key, defaultValue) {
        const setting = await this.prisma.setting.findUnique({
            where: { key },
            select: {
                value: true,
                valueType: true,
            },
        });
        if (!setting)
            return defaultValue;
        return this.castValue(setting.value, setting.valueType);
    }
    async upsert(dto) {
        const existing = await this.prisma.setting.findUnique({
            where: { key: dto.key },
        });
        if (existing) {
            const updated = await this.prisma.setting.update({
                where: { key: dto.key },
                data: {
                    value: dto.value,
                    group: dto.group ?? existing.group,
                    description: dto.description ?? existing.description,
                    valueType: dto.valueType ?? existing.valueType,
                },
            });
            return this.toResponseDto(updated);
        }
        const saved = await this.prisma.setting.create({
            data: {
                key: dto.key,
                value: dto.value,
                valueType: dto.valueType,
                description: dto.description,
                group: dto.group ?? 'general',
            },
        });
        return this.toResponseDto(saved);
    }
    async bulkUpsert(dtos) {
        const results = [];
        for (const dto of dtos) {
            results.push(await this.upsert(dto));
        }
        return results;
    }
    async remove(key) {
        const setting = await this.prisma.setting.findUnique({ where: { key } });
        if (!setting)
            throw new common_1.NotFoundException('Setting not found');
        await this.prisma.setting.delete({ where: { id: setting.id } });
        return { message: 'Setting deleted' };
    }
    castValue(value, valueType) {
        if (value === null || value === undefined)
            return null;
        switch (valueType) {
            case 'number':
                return Number(value);
            case 'boolean':
                return value === 'true';
            case 'json':
                try {
                    return JSON.parse(value);
                }
                catch {
                    return value;
                }
            default:
                return value;
        }
    }
};
exports.SettingsService = SettingsService;
exports.SettingsService = SettingsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SettingsService);
//# sourceMappingURL=settings.service.js.map