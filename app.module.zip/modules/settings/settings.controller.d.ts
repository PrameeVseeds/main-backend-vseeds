import { SettingsService } from './settings.service';
import { UpsertSettingDto } from './dto/upsert-setting.dto';
import { BulkUpsertSettingsDto } from './dto/bulk-upsert.dto';
export declare class SettingsController {
    private readonly settingsService;
    constructor(settingsService: SettingsService);
    findAll(): Promise<import("./dto/setting-response.dto").SettingResponseDto[]>;
    getSettingsMap(): Promise<Record<string, unknown>>;
    getGroups(): Promise<string[]>;
    getPricingSettings(): Promise<{
        shippingFee: number;
        taxEnabled: boolean;
        taxPercentage: number;
    }>;
    findByGroup(group: string, req: {
        user?: {
            role?: string;
        };
    }): Promise<import("./dto/setting-response.dto").SettingResponseDto[]>;
    getByKey(key: string): Promise<import("./dto/setting-response.dto").SettingResponseDto>;
    upsert(dto: UpsertSettingDto): Promise<import("./dto/setting-response.dto").SettingResponseDto>;
    bulkUpsert(dto: BulkUpsertSettingsDto): Promise<import("./dto/setting-response.dto").SettingResponseDto[]>;
    remove(key: string): Promise<{
        message: string;
    }>;
}
