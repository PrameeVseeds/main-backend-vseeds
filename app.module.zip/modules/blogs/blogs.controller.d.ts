import { BlogsService } from './blogs.service';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class BlogsController {
    private readonly blogsService;
    constructor(blogsService: BlogsService);
    findPublished(pagination: PaginationDto): Promise<{
        blogs: import("./dto/blog-response.dto").BlogResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findBySlug(slug: string): Promise<import("./dto/blog-response.dto").BlogResponseDto>;
    findAll(pagination: PaginationDto): Promise<{
        blogs: import("./dto/blog-response.dto").BlogResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<import("./dto/blog-response.dto").BlogResponseDto>;
    create(dto: CreateBlogDto): Promise<import("./dto/blog-response.dto").BlogResponseDto>;
    update(id: string, dto: UpdateBlogDto): Promise<import("./dto/blog-response.dto").BlogResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
