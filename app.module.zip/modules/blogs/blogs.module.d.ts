export declare class BlogsModule {
}
