"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlogsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const client_1 = require("@prisma/client");
let BlogsService = class BlogsService {
    prisma;
    configService;
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
    }
    get defaultIcon() {
        const icon = this.configService.get('DEFAULT_BLOG_IMAGE');
        if (!icon)
            return '';
        if (icon.startsWith('http://') || icon.startsWith('https://')) {
            return icon;
        }
        const cdnUrl = this.configService.get('CDN_URL');
        return icon && cdnUrl ? `${cdnUrl}/${icon}` : '';
    }
    mapBlog(blog) {
        if (!blog)
            return blog;
        if (!blog.coverImageUrl) {
            blog.coverImageUrl = this.defaultIcon;
        }
        return blog;
    }
    toResponseDto(blog) {
        return {
            id: blog.id,
            title: blog.title,
            slug: blog.slug,
            excerpt: blog.excerpt ?? undefined,
            content: blog.content,
            coverImageUrl: blog.coverImageUrl ?? undefined,
            author: blog.author,
            tags: blog.tags,
            status: blog.status,
            publishedAt: blog.publishedAt ?? undefined,
            createdAt: blog.createdAt,
            updatedAt: blog.updatedAt,
        };
    }
    async findPublished(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const skip = (page - 1) * limit;
        const [blogs, total] = await this.prisma.$transaction([
            this.prisma.blog.findMany({
                where: { status: 'published' },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.blog.count({
                where: { status: 'published' },
            }),
        ]);
        return {
            blogs: blogs.map((b) => this.toResponseDto(this.mapBlog(b))),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async findBySlug(slug) {
        const blog = await this.prisma.blog.findUnique({
            where: { slug },
        });
        if (!blog)
            throw new common_1.NotFoundException('Blog not found');
        return this.toResponseDto(this.mapBlog(blog));
    }
    async findById(id) {
        const blog = await this.prisma.blog.findUnique({
            where: { id },
        });
        if (!blog)
            throw new common_1.NotFoundException('Blog not found');
        return this.toResponseDto(this.mapBlog(blog));
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const skip = (page - 1) * limit;
        const [blogs, total] = await this.prisma.$transaction([
            this.prisma.blog.findMany({
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.blog.count(),
        ]);
        return {
            blogs: blogs.map((b) => this.toResponseDto(this.mapBlog(b))),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async create(dto) {
        const slug = this.generateSlug(dto.title);
        const existing = await this.prisma.blog.findUnique({ where: { slug } });
        if (existing)
            throw new common_1.BadRequestException('A blog with a similar title already exists');
        const saved = await this.prisma.blog.create({
            data: {
                title: dto.title,
                content: dto.content || '',
                author: dto.author || '',
                excerpt: dto.excerpt,
                status: dto.status,
                slug,
                coverImageUrl: dto.coverImageUrl,
                publishedAt: dto.status === 'published' ? new Date() : undefined,
                tags: dto.tags ? dto.tags : undefined,
            },
        });
        return this.findById(saved.id);
    }
    async update(id, dto) {
        const existing = await this.findById(id);
        const data = {};
        if (dto.title !== undefined) {
            data.title = dto.title;
            data.slug = this.generateSlug(dto.title);
        }
        if (dto.content !== undefined)
            data.content = dto.content;
        if (dto.author !== undefined)
            data.author = dto.author;
        if (dto.excerpt !== undefined)
            data.excerpt = dto.excerpt;
        if (dto.status !== undefined) {
            data.status = dto.status;
            if (dto.status === 'published' && existing.status !== 'published') {
                data.publishedAt = new Date();
            }
        }
        if (dto.coverImageUrl !== undefined)
            data.coverImageUrl = dto.coverImageUrl;
        if (dto.tags !== undefined) {
            data.tags = dto.tags ? dto.tags : client_1.Prisma.DbNull;
        }
        await this.prisma.blog.update({
            where: { id },
            data,
        });
        return this.findById(id);
    }
    async softDelete(id) {
        await this.findById(id);
        await this.prisma.blog.delete({
            where: { id },
        });
        return { message: 'Blog deleted' };
    }
    generateSlug(title) {
        return title
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    }
};
exports.BlogsService = BlogsService;
exports.BlogsService = BlogsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], BlogsService);
//# sourceMappingURL=blogs.service.js.map