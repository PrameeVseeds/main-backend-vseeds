import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { BlogResponseDto } from './dto/blog-response.dto';
export declare class BlogsService {
    private readonly prisma;
    private readonly configService;
    constructor(prisma: PrismaService, configService: ConfigService);
    private get defaultIcon();
    private mapBlog;
    private toResponseDto;
    findPublished(pagination: PaginationDto): Promise<{
        blogs: BlogResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findBySlug(slug: string): Promise<BlogResponseDto>;
    findById(id: string): Promise<BlogResponseDto>;
    findAll(pagination: PaginationDto): Promise<{
        blogs: BlogResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    create(dto: CreateBlogDto): Promise<BlogResponseDto>;
    update(id: string, dto: UpdateBlogDto): Promise<BlogResponseDto>;
    softDelete(id: string): Promise<{
        message: string;
    }>;
    private generateSlug;
}
