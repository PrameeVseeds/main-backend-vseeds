export declare class BlogResponseDto {
    id: string;
    title: string;
    slug: string;
    excerpt?: string;
    content?: string;
    coverImageUrl?: string;
    author?: string;
    tags?: string[];
    status: string;
    publishedAt?: Date;
    createdAt?: Date;
    updatedAt?: Date;
}
