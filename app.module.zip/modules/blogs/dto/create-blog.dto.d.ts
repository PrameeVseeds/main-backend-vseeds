export declare class CreateBlogDto {
    title: string;
    content?: string;
    excerpt?: string;
    coverImageUrl?: string;
    author?: string;
    status?: string;
    tags?: string[];
    publishedAt?: string;
}
