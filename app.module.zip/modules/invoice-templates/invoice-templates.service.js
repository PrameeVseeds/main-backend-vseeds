"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvoiceTemplatesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let InvoiceTemplatesService = class InvoiceTemplatesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    toResponse(t) {
        return {
            id: t.id,
            name: t.name,
            settings: t.settings,
            isActive: t.isActive,
            createdAt: t.createdAt,
            updatedAt: t.updatedAt,
        };
    }
    get client() {
        return this.prisma.invoiceTemplate;
    }
    async findAll() {
        const list = await this.client.findMany({
            where: { deletedAt: null },
            orderBy: { createdAt: 'desc' },
        });
        return list.map((t) => this.toResponse(t));
    }
    async findActive() {
        const active = await this.client.findFirst({
            where: { isActive: true, deletedAt: null },
        });
        if (active)
            return this.toResponse(active);
        const first = await this.client.findFirst({
            where: { deletedAt: null },
            orderBy: { createdAt: 'asc' },
        });
        return first ? this.toResponse(first) : null;
    }
    async findById(id) {
        const t = await this.client.findUnique({ where: { id } });
        if (!t || t.deletedAt) {
            throw new common_1.NotFoundException('Invoice template not found');
        }
        return this.toResponse(t);
    }
    async create(dto) {
        if (dto.isActive) {
            await this.client.updateMany({
                where: { isActive: true },
                data: { isActive: false },
            });
        }
        const created = await this.client.create({
            data: {
                name: dto.name,
                settings: dto.settings,
                isActive: dto.isActive ?? false,
            },
        });
        return this.toResponse(created);
    }
    async update(id, dto) {
        await this.findById(id);
        if (dto.isActive) {
            await this.client.updateMany({
                where: { isActive: true, id: { not: id } },
                data: { isActive: false },
            });
        }
        const updated = await this.client.update({
            where: { id },
            data: {
                ...(dto.name !== undefined && { name: dto.name }),
                ...(dto.settings !== undefined && { settings: dto.settings }),
                ...(dto.isActive !== undefined && { isActive: dto.isActive }),
            },
        });
        return this.toResponse(updated);
    }
    async remove(id) {
        await this.findById(id);
        await this.client.update({
            where: { id },
            data: { deletedAt: new Date(), isActive: false },
        });
        return { message: 'Invoice template deleted' };
    }
    async activate(id) {
        await this.client.updateMany({ data: { isActive: false } });
        const updated = await this.client.update({
            where: { id },
            data: { isActive: true },
        });
        return this.toResponse(updated);
    }
    async deactivate(id) {
        const updated = await this.client.update({
            where: { id },
            data: { isActive: false },
        });
        return this.toResponse(updated);
    }
};
exports.InvoiceTemplatesService = InvoiceTemplatesService;
exports.InvoiceTemplatesService = InvoiceTemplatesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], InvoiceTemplatesService);
//# sourceMappingURL=invoice-templates.service.js.map