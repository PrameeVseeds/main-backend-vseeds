export declare class InvoiceTemplatesModule {
}
