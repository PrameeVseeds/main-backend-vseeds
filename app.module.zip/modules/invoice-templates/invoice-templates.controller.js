"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvoiceTemplatesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const invoice_templates_service_1 = require("./invoice-templates.service");
const create_invoice_template_dto_1 = require("./dto/create-invoice-template.dto");
const update_invoice_template_dto_1 = require("./dto/update-invoice-template.dto");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
let InvoiceTemplatesController = class InvoiceTemplatesController {
    service;
    constructor(service) {
        this.service = service;
    }
    findAll() {
        return this.service.findAll();
    }
    findActive() {
        return this.service.findActive();
    }
    findById(id) {
        return this.service.findById(id);
    }
    create(dto) {
        return this.service.create(dto);
    }
    update(id, dto) {
        return this.service.update(id, dto);
    }
    remove(id) {
        return this.service.remove(id);
    }
    activate(id) {
        return this.service.activate(id);
    }
    deactivate(id) {
        return this.service.deactivate(id);
    }
};
exports.InvoiceTemplatesController = InvoiceTemplatesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all invoice template versions' }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: 'Get the active invoice template' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "findActive", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get invoice template by ID' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "findById", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new invoice template version' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_invoice_template_dto_1.CreateInvoiceTemplateDto]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update an invoice template version' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_invoice_template_dto_1.UpdateInvoiceTemplateDto]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete an invoice template version' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "remove", null);
__decorate([
    (0, common_1.Put)(':id/activate'),
    (0, swagger_1.ApiOperation)({ summary: 'Set an invoice template as active' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "activate", null);
__decorate([
    (0, common_1.Put)(':id/deactivate'),
    (0, swagger_1.ApiOperation)({ summary: 'Set an invoice template as inactive' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], InvoiceTemplatesController.prototype, "deactivate", null);
exports.InvoiceTemplatesController = InvoiceTemplatesController = __decorate([
    (0, swagger_1.ApiTags)('Invoice Templates'),
    (0, common_1.Controller)('invoice-templates'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    __metadata("design:paramtypes", [invoice_templates_service_1.InvoiceTemplatesService])
], InvoiceTemplatesController);
//# sourceMappingURL=invoice-templates.controller.js.map