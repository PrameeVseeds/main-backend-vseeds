export declare class UpdateInvoiceTemplateDto {
    name?: string;
    settings?: Record<string, any>;
    isActive?: boolean;
}
