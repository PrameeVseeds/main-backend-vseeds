"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvoiceTemplateResponseDto = void 0;
const openapi = require("@nestjs/swagger");
class InvoiceTemplateResponseDto {
    id;
    name;
    settings;
    isActive;
    createdAt;
    updatedAt;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, name: { required: true, type: () => String }, settings: { required: true, type: () => Object }, isActive: { required: true, type: () => Boolean }, createdAt: { required: true, type: () => Date }, updatedAt: { required: true, type: () => Date } };
    }
}
exports.InvoiceTemplateResponseDto = InvoiceTemplateResponseDto;
//# sourceMappingURL=invoice-template-response.dto.js.map