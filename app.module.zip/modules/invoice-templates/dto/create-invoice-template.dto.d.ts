export declare class CreateInvoiceTemplateDto {
    name: string;
    settings: Record<string, any>;
    isActive?: boolean;
}
