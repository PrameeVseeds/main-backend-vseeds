import { InvoiceTemplatesService } from './invoice-templates.service';
import { CreateInvoiceTemplateDto } from './dto/create-invoice-template.dto';
import { UpdateInvoiceTemplateDto } from './dto/update-invoice-template.dto';
export declare class InvoiceTemplatesController {
    private readonly service;
    constructor(service: InvoiceTemplatesService);
    findAll(): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto[]>;
    findActive(): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto | null>;
    findById(id: string): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto>;
    create(dto: CreateInvoiceTemplateDto): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto>;
    update(id: string, dto: UpdateInvoiceTemplateDto): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto>;
    remove(id: string): Promise<{
        message: string;
    }>;
    activate(id: string): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto>;
    deactivate(id: string): Promise<import("./dto/invoice-template-response.dto").InvoiceTemplateResponseDto>;
}
