import { PrismaService } from '../../prisma/prisma.service';
import { CreateInvoiceTemplateDto } from './dto/create-invoice-template.dto';
import { UpdateInvoiceTemplateDto } from './dto/update-invoice-template.dto';
import { InvoiceTemplateResponseDto } from './dto/invoice-template-response.dto';
export declare class InvoiceTemplatesService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private toResponse;
    private get client();
    findAll(): Promise<InvoiceTemplateResponseDto[]>;
    findActive(): Promise<InvoiceTemplateResponseDto | null>;
    findById(id: string): Promise<InvoiceTemplateResponseDto>;
    create(dto: CreateInvoiceTemplateDto): Promise<InvoiceTemplateResponseDto>;
    update(id: string, dto: UpdateInvoiceTemplateDto): Promise<InvoiceTemplateResponseDto>;
    remove(id: string): Promise<{
        message: string;
    }>;
    activate(id: string): Promise<InvoiceTemplateResponseDto>;
    deactivate(id: string): Promise<InvoiceTemplateResponseDto>;
}
