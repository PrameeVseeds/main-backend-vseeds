"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const products_service_1 = require("./products.service");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const image_file_filter_1 = require("../../common/utils/image-file-filter");
const create_product_dto_1 = require("./dto/create-product.dto");
const update_product_dto_1 = require("./dto/update-product.dto");
const product_query_dto_1 = require("./dto/product-query.dto");
const update_product_status_dto_1 = require("./dto/update-product-status.dto");
let ProductsController = class ProductsController {
    productsService;
    constructor(productsService) {
        this.productsService = productsService;
    }
    getAttributes() {
        return this.productsService.getAttributes();
    }
    findAll(query) {
        return this.productsService.findAll(query);
    }
    search(search, query) {
        return this.productsService.search(search, query);
    }
    checkStock(productId, quantity) {
        return this.productsService.checkStock(productId, quantity);
    }
    getRelated(id) {
        return this.productsService.getRelated(id);
    }
    findSimilar(query) {
        return this.productsService.findSimilar(query);
    }
    getPrices(id) {
        return this.productsService.getPriceTiers(id);
    }
    findBySlug(slug) {
        return this.productsService.findBySlug(slug);
    }
    findBySku(sku) {
        return this.productsService.findBySku(sku);
    }
    count() {
        return this.productsService.count();
    }
    findOne(id) {
        return this.productsService.findById(id);
    }
    create(dto, files) {
        return this.productsService.create(dto, files?.thumbnail?.[0], files?.images);
    }
    update(id, dto, files) {
        return this.productsService.update(id, dto, files?.thumbnail?.[0], files?.images);
    }
    delete(id) {
        return this.productsService.softDelete(id);
    }
    updateStatus(id, dto) {
        return this.productsService.updateStatus(id, dto);
    }
    updateSpecifications(id, specifications) {
        return this.productsService.updateSpecifications(id, specifications);
    }
    findByCategory(id, query) {
        return this.productsService.findByCategory(id, query);
    }
};
exports.ProductsController = ProductsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('attributes'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all reusable product attributes' }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "getAttributes", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('all'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all products with search/filter/pagination' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [product_query_dto_1.ProductQueryDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findAll", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('search/:search'),
    (0, swagger_1.ApiOperation)({ summary: 'Search products' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('search')),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, product_query_dto_1.ProductQueryDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "search", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('stock'),
    (0, swagger_1.ApiOperation)({ summary: 'Check stock availability' }),
    (0, swagger_1.ApiQuery)({ name: 'productId', required: true }),
    (0, swagger_1.ApiQuery)({ name: 'quantity', required: true }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)('productId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Query)('quantity', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "checkStock", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('related/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get related products' }),
    openapi.ApiResponse({ status: 200, type: [Object] }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "getRelated", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('similar'),
    (0, swagger_1.ApiOperation)({
        summary: 'Filter similar products by category, subcategory or tags',
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [product_query_dto_1.ProductQueryDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findSimilar", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('prices/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product price tiers' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "getPrices", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('slug/:slug'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product by slug' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('slug')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findBySlug", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('sku/:sku'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product by SKU' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('sku')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findBySku", null);
__decorate([
    (0, common_1.Get)('count'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product count' }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "count", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product by ID' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)('add'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileFieldsInterceptor)([
        { name: 'thumbnail', maxCount: 1 },
        { name: 'images', maxCount: 10 },
    ], { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Create product (with optional images)' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.UploadedFiles)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_product_dto_1.CreateProductDto, Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('update/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileFieldsInterceptor)([
        { name: 'thumbnail', maxCount: 1 },
        { name: 'images', maxCount: 10 },
    ], { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Update product (with optional images)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.UploadedFiles)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_product_dto_1.UpdateProductDto, Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)('delete/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete product (soft)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "delete", null);
__decorate([
    (0, common_1.Put)('status/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Update product status & stock' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_product_status_dto_1.UpdateProductStatusDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Put)('specification/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Update product specifications' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)('specifications')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "updateSpecifications", null);
__decorate([
    (0, common_1.Get)('category/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get products by category' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, product_query_dto_1.ProductQueryDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findByCategory", null);
exports.ProductsController = ProductsController = __decorate([
    (0, swagger_1.ApiTags)('Products'),
    (0, common_1.Controller)('products'),
    __metadata("design:paramtypes", [products_service_1.ProductsService])
], ProductsController);
//# sourceMappingURL=products.controller.js.map