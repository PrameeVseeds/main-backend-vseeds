import { PaginationDto } from '../../../common/dto/pagination.dto';
export declare class ProductQueryDto extends PaginationDto {
    search?: string;
    status?: string;
    filter?: string;
    categoryId?: string;
    subcategory?: string;
    excludeId?: string;
    tags?: string;
    productId?: string;
    attributeIds?: string;
    attributes?: string;
    manufacturer?: string;
    view?: 'admin' | 'catalog';
}
