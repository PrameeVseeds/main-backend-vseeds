export declare class UpdateProductStatusDto {
    status?: string;
    quantityInHand?: number;
    isFeatured?: boolean;
}
