"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateProductDto = exports.ProductAttributeDto = exports.toBool = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const toNumber = ({ value }) => {
    if (value === null || value === undefined || value === '')
        return undefined;
    const n = Number(value);
    return isNaN(n) ? undefined : n;
};
const toBool = ({ value, obj, key, }) => {
    const raw = obj && typeof key === 'string'
        ? obj[key]
        : undefined;
    const v = raw !== undefined ? raw : value;
    if (typeof v === 'boolean')
        return v;
    if (v === 'true' || v === '1')
        return true;
    if (v === 'false' || v === '0')
        return false;
    return undefined;
};
exports.toBool = toBool;
const safeStringify = (val) => {
    if (val === null || val === undefined)
        return '';
    if (typeof val === 'string')
        return val;
    if (typeof val === 'number' || typeof val === 'boolean')
        return String(val);
    try {
        return JSON.stringify(val);
    }
    catch {
        return '';
    }
};
class ProductAttributeDto {
    attributeId;
    name;
    value;
    isSimilarFilter;
    static _OPENAPI_METADATA_FACTORY() {
        return { attributeId: { required: false, type: () => String, format: "uuid" }, name: { required: true, type: () => String }, value: { required: true, type: () => String }, isSimilarFilter: { required: false, type: () => Boolean } };
    }
}
exports.ProductAttributeDto = ProductAttributeDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], ProductAttributeDto.prototype, "attributeId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ProductAttributeDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ProductAttributeDto.prototype, "value", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(exports.toBool),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], ProductAttributeDto.prototype, "isSimilarFilter", void 0);
class CreateProductDto {
    name;
    categoryId;
    categoryName;
    sku;
    description;
    shortDescription;
    minPurchaseValue;
    specifications;
    tags;
    datasheetUrl;
    model3dUrl;
    subCategory;
    storeId;
    manufacturer;
    manufacturerProductNumber;
    quantityInHand;
    quantityOrdered;
    purchasedPrice;
    expectedDate;
    isFeatured;
    price1;
    price10;
    price100;
    status;
    attributes;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: true, type: () => String }, categoryId: { required: false, type: () => String, format: "uuid" }, categoryName: { required: false, type: () => String }, sku: { required: false, type: () => String }, description: { required: false, type: () => String }, shortDescription: { required: false, type: () => String }, minPurchaseValue: { required: false, type: () => Number }, specifications: { required: false, type: () => String }, tags: { required: false, type: () => [String] }, datasheetUrl: { required: false, type: () => String }, model3dUrl: { required: false, type: () => String }, subCategory: { required: false, type: () => String }, storeId: { required: false, type: () => String }, manufacturer: { required: false, type: () => String }, manufacturerProductNumber: { required: false, type: () => String }, quantityInHand: { required: false, type: () => Number }, quantityOrdered: { required: false, type: () => Number }, purchasedPrice: { required: false, type: () => Number }, expectedDate: { required: false, type: () => String }, isFeatured: { required: false, type: () => Boolean }, price1: { required: false, type: () => Number }, price10: { required: false, type: () => Number }, price100: { required: false, type: () => Number }, status: { required: false, type: () => String }, attributes: { required: false, type: () => [require("./create-product.dto").ProductAttributeDto] } };
    }
}
exports.CreateProductDto = CreateProductDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "categoryId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "categoryName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "sku", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "shortDescription", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Minimum purchase quantity (unit count)',
    }),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "minPurchaseValue", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Product specifications (HTML string)',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined || value === '')
            return null;
        let result = value;
        for (let i = 0; i < 10; i++) {
            if (typeof result === 'string') {
                try {
                    result = JSON.parse(result);
                    continue;
                }
                catch {
                    break;
                }
            }
            if (Array.isArray(result) && result.length === 1) {
                result = result[0];
                continue;
            }
            break;
        }
        return typeof result === 'string' ? result : safeStringify(value);
    }),
    __metadata("design:type", String)
], CreateProductDto.prototype, "specifications", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [String] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined || value === '')
            return [];
        if (Array.isArray(value))
            return value.map(safeStringify);
        if (typeof value === 'string') {
            try {
                const parsed = JSON.parse(value);
                return Array.isArray(parsed)
                    ? parsed.map(safeStringify)
                    : [safeStringify(parsed)];
            }
            catch {
                return [value];
            }
        }
        return [safeStringify(value)];
    }),
    __metadata("design:type", Array)
], CreateProductDto.prototype, "tags", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "datasheetUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "model3dUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "subCategory", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "storeId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "manufacturer", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "manufacturerProductNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "quantityInHand", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "quantityOrdered", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "purchasedPrice", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "expectedDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(exports.toBool),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateProductDto.prototype, "isFeatured", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "price1", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "price10", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(toNumber),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "price100", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['active', 'inactive', 'out_of_stock', 'discontinued'],
    }),
    (0, class_validator_1.IsEnum)(['active', 'inactive', 'out_of_stock', 'discontinued']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [ProductAttributeDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (!value)
            return [];
        if (Array.isArray(value))
            return value;
        if (typeof value === 'string') {
            try {
                const parsed = JSON.parse(value);
                return Array.isArray(parsed) ? parsed : [];
            }
            catch {
                return [];
            }
        }
        return [];
    }),
    __metadata("design:type", Array)
], CreateProductDto.prototype, "attributes", void 0);
//# sourceMappingURL=create-product.dto.js.map