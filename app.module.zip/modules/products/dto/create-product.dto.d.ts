import { TransformFnParams } from 'class-transformer';
export declare const toBool: ({ value, obj, key, }: TransformFnParams) => boolean | undefined;
export declare class ProductAttributeDto {
    attributeId?: string;
    name: string;
    value: string;
    isSimilarFilter?: boolean;
}
export declare class CreateProductDto {
    name: string;
    categoryId?: string;
    categoryName?: string;
    sku?: string;
    description?: string;
    shortDescription?: string;
    minPurchaseValue?: number;
    specifications?: string;
    tags?: string[];
    datasheetUrl?: string;
    model3dUrl?: string;
    subCategory?: string;
    storeId?: string;
    manufacturer?: string;
    manufacturerProductNumber?: string;
    quantityInHand?: number;
    quantityOrdered?: number;
    purchasedPrice?: number;
    expectedDate?: string;
    isFeatured?: boolean;
    price1?: number;
    price10?: number;
    price100?: number;
    status?: string;
    attributes?: ProductAttributeDto[];
}
