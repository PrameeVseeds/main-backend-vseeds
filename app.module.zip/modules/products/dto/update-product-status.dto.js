"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateProductStatusDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const create_product_dto_1 = require("./create-product.dto");
class UpdateProductStatusDto {
    status;
    quantityInHand;
    isFeatured;
    static _OPENAPI_METADATA_FACTORY() {
        return { status: { required: false, type: () => String, enum: ['active', 'inactive', 'out_of_stock', 'discontinued'] }, quantityInHand: { required: false, type: () => Number }, isFeatured: { required: false, type: () => Boolean } };
    }
}
exports.UpdateProductStatusDto = UpdateProductStatusDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['active', 'inactive', 'out_of_stock', 'discontinued'],
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsIn)(['active', 'inactive', 'out_of_stock', 'discontinued']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateProductStatusDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateProductStatusDto.prototype, "quantityInHand", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_transformer_1.Transform)(create_product_dto_1.toBool),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], UpdateProductStatusDto.prototype, "isFeatured", void 0);
//# sourceMappingURL=update-product-status.dto.js.map