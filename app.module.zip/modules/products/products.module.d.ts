export declare class ProductsModule {
}
