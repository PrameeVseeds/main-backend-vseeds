import { OrdersService } from './orders.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { CreateShipmentDto } from './dto/create-shipment.dto';
import { OrderQueryDto } from './dto/order-query.dto';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    create(user: JwtPayload, dto: CreateOrderDto): Promise<import("./dto/order-detail-response.dto").OrderDetailResponseDto>;
    findMyOrders(user: JwtPayload, query: OrderQueryDto): Promise<{
        orders: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findByUserEmail(user: JwtPayload, email: string, query: OrderQueryDto): Promise<{
        orders: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findUserOrder(user: JwtPayload, orderId: string): Promise<import("./dto/order-detail-response.dto").OrderDetailResponseDto>;
    findOne(orderId: string): Promise<import("./dto/order-detail-response.dto").OrderDetailResponseDto>;
    delete(orderId: string): Promise<{
        message: string;
    }>;
    findAll(query: OrderQueryDto): Promise<{
        orders: {
            id: string;
            orderNumber: string;
            email: string | null;
            createdAt: Date;
            totalAmount: number;
            status: import(".prisma/client").$Enums.OrderStatus;
            itemCount: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findFiltered(query: OrderQueryDto): Promise<{
        orders: {
            id: string;
            orderNumber: string;
            email: string | null;
            createdAt: Date;
            totalAmount: number;
            status: import(".prisma/client").$Enums.OrderStatus;
            itemCount: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        total: number;
        pending: number;
        waitingForPayment: number;
        processing: number;
        shipped: number;
        delivered: number;
        cancelled: number;
        refunded: number;
    }>;
    updateStatus(orderId: string, dto: UpdateOrderStatusDto): Promise<import("./dto/order-detail-response.dto").OrderDetailResponseDto>;
    createShipment(orderId: string, dto: CreateShipmentDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        shippingFee: import("@prisma/client/runtime/library").Decimal;
        orderId: string;
        trackingNumber: string | null;
        carrier: string | null;
        shippedAt: Date | null;
        expectedDeliveryAt: Date | null;
        deliveredAt: Date | null;
    }>;
    updateOrder(orderId: string, dto: UpdateOrderDto): Promise<import("./dto/order-detail-response.dto").OrderDetailResponseDto>;
    sendPaymentRequest(orderId: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
