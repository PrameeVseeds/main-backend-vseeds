import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { Prisma } from '@prisma/client';
declare const orderEntityInclude: {
    user: {
        include: {
            addresses: true;
        };
    };
    items: {
        include: {
            product: {
                include: {
                    productMedia: {
                        include: {
                            media: true;
                        };
                    };
                };
            };
        };
    };
    shippingAddress: true;
    statusHistory: {
        orderBy: {
            createdAt: "asc";
        };
    };
    shipments: true;
    payments: true;
};
export type OrderEntity = Prisma.OrderGetPayload<{
    include: typeof orderEntityInclude;
}>;
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { CreateShipmentDto } from './dto/create-shipment.dto';
import { OrderQueryDto } from './dto/order-query.dto';
import { OrderDetailResponseDto } from './dto/order-detail-response.dto';
import { EmailQueueService } from '../email/email-queue.service';
import { BanksService } from '../banks/banks.service';
import { PromoCodesService } from '../promo-codes/promo-codes.service';
import { SettingsService } from '../settings/settings.service';
export declare const UNPAID_AUTO_CANCEL_DAYS = 10;
export declare class OrdersService {
    private readonly prisma;
    private readonly emailQueueService;
    private readonly banksService;
    private readonly promoCodesService;
    private readonly encryptionService;
    private readonly settingsService;
    private readonly logger;
    constructor(prisma: PrismaService, emailQueueService: EmailQueueService, banksService: BanksService, promoCodesService: PromoCodesService, encryptionService: EncryptionService, settingsService: SettingsService);
    create(userId: string, dto: CreateOrderDto): Promise<OrderDetailResponseDto>;
    private getOrderEntity;
    findById(orderId: string): Promise<OrderDetailResponseDto>;
    private mapOrderToDetailDto;
    findByUser(userId: string, query: OrderQueryDto): Promise<{
        orders: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findByUserEmail(email: string, query: OrderQueryDto): Promise<{
        orders: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findAll(query: OrderQueryDto): Promise<{
        orders: {
            id: string;
            orderNumber: string;
            email: string | null;
            createdAt: Date;
            totalAmount: number;
            status: import(".prisma/client").$Enums.OrderStatus;
            itemCount: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        total: number;
        pending: number;
        waitingForPayment: number;
        processing: number;
        shipped: number;
        delivered: number;
        cancelled: number;
        refunded: number;
    }>;
    cancelStaleUnpaidOrders(): Promise<{
        cancelled: number;
        orderIds: string[];
    }>;
    updateStatus(orderId: string, dto: UpdateOrderStatusDto, changedBy?: string): Promise<OrderDetailResponseDto>;
    createShipment(orderId: string, dto: CreateShipmentDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        shippingFee: Prisma.Decimal;
        orderId: string;
        trackingNumber: string | null;
        carrier: string | null;
        shippedAt: Date | null;
        expectedDeliveryAt: Date | null;
        deliveredAt: Date | null;
    }>;
    sendPaymentRequest(orderId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    updateOrder(orderId: string, dto: UpdateOrderDto): Promise<OrderDetailResponseDto>;
    deleteOrder(orderId: string): Promise<{
        message: string;
    }>;
    private handleInventoryOnStatusChange;
    private handlePaymentOnStatusChange;
    private generateOrderNumber;
    private generatePaymentNumber;
    private resolveUnitPrice;
    private decryptField;
    private decryptOrderAddresses;
}
export {};
