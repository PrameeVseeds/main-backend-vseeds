"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const orders_service_1 = require("./orders.service");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const create_order_dto_1 = require("./dto/create-order.dto");
const update_order_status_dto_1 = require("./dto/update-order-status.dto");
const update_order_dto_1 = require("./dto/update-order.dto");
const create_shipment_dto_1 = require("./dto/create-shipment.dto");
const order_query_dto_1 = require("./dto/order-query.dto");
let OrdersController = class OrdersController {
    ordersService;
    constructor(ordersService) {
        this.ordersService = ordersService;
    }
    create(user, dto) {
        return this.ordersService.create(user.id, dto);
    }
    findMyOrders(user, query) {
        return this.ordersService.findByUser(user.id, query);
    }
    findByUserEmail(user, email, query) {
        const normalizedUserEmail = user.email?.toLowerCase().trim();
        const normalizedParamEmail = email?.toLowerCase().trim();
        const isAdmin = user.type === 'admin' || user.role === 'admin' || user.role === 'super admin';
        if (!isAdmin && normalizedUserEmail !== normalizedParamEmail) {
            throw new common_1.ForbiddenException('You can only access your own orders');
        }
        return this.ordersService.findByUserEmail(email, query);
    }
    async findUserOrder(user, orderId) {
        const order = await this.ordersService.findById(orderId);
        if (user.type !== 'admin' && order.userId !== user.id) {
            throw new common_1.ForbiddenException('You can only access your own orders');
        }
        return order;
    }
    findOne(orderId) {
        return this.ordersService.findById(orderId);
    }
    delete(orderId) {
        return this.ordersService.deleteOrder(orderId);
    }
    findAll(query) {
        return this.ordersService.findAll(query);
    }
    findFiltered(query) {
        return this.ordersService.findAll(query);
    }
    count() {
        return this.ordersService.count();
    }
    updateStatus(orderId, dto) {
        return this.ordersService.updateStatus(orderId, dto);
    }
    createShipment(orderId, dto) {
        return this.ordersService.createShipment(orderId, dto);
    }
    updateOrder(orderId, dto) {
        return this.ordersService.updateOrder(orderId, dto);
    }
    sendPaymentRequest(orderId) {
        return this.ordersService.sendPaymentRequest(orderId);
    }
};
exports.OrdersController = OrdersController;
__decorate([
    (0, common_1.Post)('add'),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new order' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/order-detail-response.dto").OrderDetailResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, create_order_dto_1.CreateOrderDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('my'),
    (0, swagger_1.ApiOperation)({ summary: 'Get orders for current user' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, order_query_dto_1.OrderQueryDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findMyOrders", null);
__decorate([
    (0, common_1.Get)('user/:email'),
    (0, swagger_1.ApiOperation)({ summary: 'Get orders by user email (own or admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('email')),
    __param(2, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, order_query_dto_1.OrderQueryDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findByUserEmail", null);
__decorate([
    (0, common_1.Get)('order_id/:orderId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get order by ID (own or admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/order-detail-response.dto").OrderDetailResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "findUserOrder", null);
__decorate([
    (0, common_1.Get)('order-by-id/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get order by ID (admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/order-detail-response.dto").OrderDetailResponseDto }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Delete)('delete/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete order (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "delete", null);
__decorate([
    (0, common_1.Get)('all'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all orders (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [order_query_dto_1.OrderQueryDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('get'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get orders with filters (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [order_query_dto_1.OrderQueryDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findFiltered", null);
__decorate([
    (0, common_1.Get)('count'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get order count by status' }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "count", null);
__decorate([
    (0, common_1.Put)('status/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Update order status' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/order-detail-response.dto").OrderDetailResponseDto }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_status_dto_1.UpdateOrderStatusDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Post)('shipping/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Create shipment for order' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_shipment_dto_1.CreateShipmentDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "createShipment", null);
__decorate([
    (0, common_1.Put)('update/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Update order items and shipping fee' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/order-detail-response.dto").OrderDetailResponseDto }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_dto_1.UpdateOrderDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "updateOrder", null);
__decorate([
    (0, common_1.Post)('send-payment-request/:orderId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Send payment request email to customer' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "sendPaymentRequest", null);
exports.OrdersController = OrdersController = __decorate([
    (0, swagger_1.ApiTags)('Orders'),
    (0, common_1.Controller)('orders'),
    __metadata("design:paramtypes", [orders_service_1.OrdersService])
], OrdersController);
//# sourceMappingURL=orders.controller.js.map