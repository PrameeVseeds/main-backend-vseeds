export declare class UpdateOrderItemDto {
    productId?: string;
    product: string;
    storeId?: string;
    qty: number;
    unitPrice: number;
}
export declare class UpdateOrderDto {
    lineItems: UpdateOrderItemDto[];
    shippingFee?: number;
}
