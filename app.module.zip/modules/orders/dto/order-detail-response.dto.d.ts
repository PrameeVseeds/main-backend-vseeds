export declare class OrderDetailItemDto {
    id: string;
    productId: string | null;
    productName: string;
    productSku?: string;
    productImage?: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
}
export declare class OrderDetailAddressDto {
    id: string;
    label?: string;
    fullName: string;
    email?: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city?: string;
    district: string;
    province: string;
    postalCode: string;
}
export declare class OrderDetailStatusHistoryDto {
    id: string;
    fromStatus?: string;
    toStatus: string;
    note?: string;
    createdAt: string;
}
export declare class OrderDetailShipmentDto {
    id: string;
    trackingNumber?: string;
    carrier?: string;
    shippedAt?: string;
    expectedDeliveryAt?: string;
    deliveredAt?: string;
    createdAt: string;
}
export declare class OrderDetailPaymentDto {
    id: string;
    paymentNumber: string;
    amount: number;
    paymentMethod: string;
    status: string;
    paidAt?: string;
}
export declare class OrderDetailResponseDto {
    id: string;
    orderNumber: string;
    userId: string;
    userEmail?: string;
    shippingAddressId?: string;
    shippingAddress?: OrderDetailAddressDto;
    orderType: string;
    quoteId?: string;
    subtotal: number;
    shippingFee: number;
    taxAmount: number;
    discountAmount: number;
    promoCode?: string;
    totalAmount: number;
    status: string;
    customerNotes?: string;
    adminNotes?: string;
    createdAt: string;
    updatedAt: string;
    items: OrderDetailItemDto[];
    statusHistory: OrderDetailStatusHistoryDto[];
    shipments: OrderDetailShipmentDto[];
    payments: OrderDetailPaymentDto[];
}
