"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderDetailResponseDto = exports.OrderDetailPaymentDto = exports.OrderDetailShipmentDto = exports.OrderDetailStatusHistoryDto = exports.OrderDetailAddressDto = exports.OrderDetailItemDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
class OrderDetailItemDto {
    id;
    productId;
    productName;
    productSku;
    productImage;
    quantity;
    unitPrice;
    totalPrice;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, productId: { required: true, type: () => String, nullable: true }, productName: { required: true, type: () => String }, productSku: { required: false, type: () => String }, productImage: { required: false, type: () => String }, quantity: { required: true, type: () => Number }, unitPrice: { required: true, type: () => Number }, totalPrice: { required: true, type: () => Number } };
    }
}
exports.OrderDetailItemDto = OrderDetailItemDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailItemDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Object)
], OrderDetailItemDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailItemDto.prototype, "productName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailItemDto.prototype, "productSku", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailItemDto.prototype, "productImage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailItemDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailItemDto.prototype, "unitPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailItemDto.prototype, "totalPrice", void 0);
class OrderDetailAddressDto {
    id;
    label;
    fullName;
    email;
    phone;
    addressLine1;
    addressLine2;
    city;
    district;
    province;
    postalCode;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, label: { required: false, type: () => String }, fullName: { required: true, type: () => String }, email: { required: false, type: () => String }, phone: { required: true, type: () => String }, addressLine1: { required: true, type: () => String }, addressLine2: { required: false, type: () => String }, city: { required: false, type: () => String }, district: { required: true, type: () => String }, province: { required: true, type: () => String }, postalCode: { required: true, type: () => String } };
    }
}
exports.OrderDetailAddressDto = OrderDetailAddressDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "label", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "fullName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "addressLine1", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "addressLine2", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "city", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "district", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "province", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailAddressDto.prototype, "postalCode", void 0);
class OrderDetailStatusHistoryDto {
    id;
    fromStatus;
    toStatus;
    note;
    createdAt;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, fromStatus: { required: false, type: () => String }, toStatus: { required: true, type: () => String }, note: { required: false, type: () => String }, createdAt: { required: true, type: () => String } };
    }
}
exports.OrderDetailStatusHistoryDto = OrderDetailStatusHistoryDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailStatusHistoryDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailStatusHistoryDto.prototype, "fromStatus", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailStatusHistoryDto.prototype, "toStatus", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailStatusHistoryDto.prototype, "note", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailStatusHistoryDto.prototype, "createdAt", void 0);
class OrderDetailShipmentDto {
    id;
    trackingNumber;
    carrier;
    shippedAt;
    expectedDeliveryAt;
    deliveredAt;
    createdAt;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, trackingNumber: { required: false, type: () => String }, carrier: { required: false, type: () => String }, shippedAt: { required: false, type: () => String }, expectedDeliveryAt: { required: false, type: () => String }, deliveredAt: { required: false, type: () => String }, createdAt: { required: true, type: () => String } };
    }
}
exports.OrderDetailShipmentDto = OrderDetailShipmentDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "trackingNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "carrier", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "shippedAt", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "expectedDeliveryAt", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "deliveredAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailShipmentDto.prototype, "createdAt", void 0);
class OrderDetailPaymentDto {
    id;
    paymentNumber;
    amount;
    paymentMethod;
    status;
    paidAt;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, paymentNumber: { required: true, type: () => String }, amount: { required: true, type: () => Number }, paymentMethod: { required: true, type: () => String }, status: { required: true, type: () => String }, paidAt: { required: false, type: () => String } };
    }
}
exports.OrderDetailPaymentDto = OrderDetailPaymentDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailPaymentDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailPaymentDto.prototype, "paymentNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailPaymentDto.prototype, "amount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailPaymentDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailPaymentDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailPaymentDto.prototype, "paidAt", void 0);
class OrderDetailResponseDto {
    id;
    orderNumber;
    userId;
    userEmail;
    shippingAddressId;
    shippingAddress;
    orderType;
    quoteId;
    subtotal;
    shippingFee;
    taxAmount;
    discountAmount;
    promoCode;
    totalAmount;
    status;
    customerNotes;
    adminNotes;
    createdAt;
    updatedAt;
    items;
    statusHistory;
    shipments;
    payments;
    static _OPENAPI_METADATA_FACTORY() {
        return { id: { required: true, type: () => String }, orderNumber: { required: true, type: () => String }, userId: { required: true, type: () => String }, userEmail: { required: false, type: () => String }, shippingAddressId: { required: false, type: () => String }, shippingAddress: { required: false, type: () => require("./order-detail-response.dto").OrderDetailAddressDto }, orderType: { required: true, type: () => String }, quoteId: { required: false, type: () => String }, subtotal: { required: true, type: () => Number }, shippingFee: { required: true, type: () => Number }, taxAmount: { required: true, type: () => Number }, discountAmount: { required: true, type: () => Number }, promoCode: { required: false, type: () => String }, totalAmount: { required: true, type: () => Number }, status: { required: true, type: () => String }, customerNotes: { required: false, type: () => String }, adminNotes: { required: false, type: () => String }, createdAt: { required: true, type: () => String }, updatedAt: { required: true, type: () => String }, items: { required: true, type: () => [require("./order-detail-response.dto").OrderDetailItemDto] }, statusHistory: { required: true, type: () => [require("./order-detail-response.dto").OrderDetailStatusHistoryDto] }, shipments: { required: true, type: () => [require("./order-detail-response.dto").OrderDetailShipmentDto] }, payments: { required: true, type: () => [require("./order-detail-response.dto").OrderDetailPaymentDto] } };
    }
}
exports.OrderDetailResponseDto = OrderDetailResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "orderNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "userId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "userEmail", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "shippingAddressId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", OrderDetailAddressDto)
], OrderDetailResponseDto.prototype, "shippingAddress", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "orderType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "quoteId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailResponseDto.prototype, "subtotal", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailResponseDto.prototype, "shippingFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailResponseDto.prototype, "taxAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailResponseDto.prototype, "discountAmount", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "promoCode", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OrderDetailResponseDto.prototype, "totalAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "customerNotes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "adminNotes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "createdAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OrderDetailResponseDto.prototype, "updatedAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [OrderDetailItemDto] }),
    __metadata("design:type", Array)
], OrderDetailResponseDto.prototype, "items", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [OrderDetailStatusHistoryDto] }),
    __metadata("design:type", Array)
], OrderDetailResponseDto.prototype, "statusHistory", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [OrderDetailShipmentDto] }),
    __metadata("design:type", Array)
], OrderDetailResponseDto.prototype, "shipments", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [OrderDetailPaymentDto] }),
    __metadata("design:type", Array)
], OrderDetailResponseDto.prototype, "payments", void 0);
//# sourceMappingURL=order-detail-response.dto.js.map