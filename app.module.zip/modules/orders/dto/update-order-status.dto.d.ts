export declare const ORDER_STATUSES: readonly ["pending", "waiting_for_payment", "processing", "shipped", "delivered", "cancelled", "refunded"];
export declare class UpdateOrderStatusDto {
    status: string;
    note?: string;
}
