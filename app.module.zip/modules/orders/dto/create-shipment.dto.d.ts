export declare class CreateShipmentDto {
    trackingNumber?: string;
    carrier?: string;
    shippedAt: string;
    expectedDeliveryAt?: string;
    shippingFee?: number;
}
