export declare class OrderItemDto {
    productId: string;
    quantity: number;
}
export declare class CreateOrderDto {
    items: OrderItemDto[];
    shippingAddressId?: string;
    orderType?: string;
    quoteId?: string;
    shippingFee?: number;
    discountAmount?: number;
    promoCode?: string;
    site?: string;
    customerNotes?: string;
}
