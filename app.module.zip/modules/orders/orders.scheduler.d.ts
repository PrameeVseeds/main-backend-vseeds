import { OrdersService } from './orders.service';
export declare class OrdersScheduler {
    private readonly ordersService;
    private readonly logger;
    constructor(ordersService: OrdersService);
    cancelStaleUnpaidOrders(): Promise<void>;
}
