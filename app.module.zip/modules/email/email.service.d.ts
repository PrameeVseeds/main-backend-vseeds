import { ConfigService } from '@nestjs/config';
import { EmailTemplatesService } from '../email-templates/email-templates.service';
export interface SendMailOptions {
    to: string | string[];
    subject: string;
    html: string;
    text?: string;
    bcc?: string | string[];
    attachments?: {
        filename: string;
        content: Buffer;
        contentType?: string;
    }[];
}
export declare class EmailService {
    private readonly configService;
    private readonly emailTemplatesService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService, emailTemplatesService: EmailTemplatesService);
    send(options: SendMailOptions): Promise<boolean>;
    sendWithTemplate(templateSlug: string, to: string | string[], data: Record<string, string>, bcc?: string | string[]): Promise<boolean>;
    sendToSystem(subject: string, html: string): Promise<boolean>;
    sendToSales(to: string, subject: string, html: string): Promise<boolean>;
    sendToCustomer(to: string, subject: string, html: string): Promise<boolean>;
}
