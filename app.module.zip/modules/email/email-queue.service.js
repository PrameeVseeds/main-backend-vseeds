"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EmailQueueService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailQueueService = void 0;
const common_1 = require("@nestjs/common");
const email_service_1 = require("./email.service");
let EmailQueueService = EmailQueueService_1 = class EmailQueueService {
    emailService;
    logger = new common_1.Logger(EmailQueueService_1.name);
    constructor(emailService) {
        this.emailService = emailService;
    }
    async enqueue(templateSlug, to, data, bcc) {
        const recipients = Array.isArray(to) ? to.join(',') : to;
        this.logger.log(`Directly sending templated email: ${templateSlug} to ${recipients}`);
        try {
            await this.emailService.sendWithTemplate(templateSlug, to, data, bcc);
        }
        catch (err) {
            const errMsg = err instanceof Error ? err.message : String(err);
            this.logger.error(`Direct email send failed for ${recipients}: ${errMsg}`);
        }
    }
    async enqueueRaw(to, subject, html, text, attachments) {
        const recipients = Array.isArray(to) ? to.join(',') : to;
        this.logger.log(`Directly sending raw email to ${recipients}`);
        try {
            await this.emailService.send({ to, subject, html, text, attachments });
        }
        catch (err) {
            const errMsg = err instanceof Error ? err.message : String(err);
            this.logger.error(`Direct raw email send failed for ${recipients}: ${errMsg}`);
        }
    }
};
exports.EmailQueueService = EmailQueueService;
exports.EmailQueueService = EmailQueueService = EmailQueueService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [email_service_1.EmailService])
], EmailQueueService);
//# sourceMappingURL=email-queue.service.js.map