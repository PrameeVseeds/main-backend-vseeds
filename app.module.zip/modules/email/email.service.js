"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EmailService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const nodemailer = __importStar(require("nodemailer"));
const email_templates_service_1 = require("../email-templates/email-templates.service");
let EmailService = EmailService_1 = class EmailService {
    configService;
    emailTemplatesService;
    logger = new common_1.Logger(EmailService_1.name);
    transporter;
    constructor(configService, emailTemplatesService) {
        this.configService = configService;
        this.emailTemplatesService = emailTemplatesService;
        const port = Number(this.configService.get('MAIL_PORT', '587'));
        const mailSecureEnv = this.configService.get('MAIL_SECURE');
        const secure = mailSecureEnv ? mailSecureEnv === 'true' : port === 465;
        this.transporter = nodemailer.createTransport({
            host: this.configService.get('MAIL_HOST'),
            port,
            secure,
            auth: {
                user: this.configService.get('MAIL_USERNAME'),
                pass: this.configService.get('MAIL_PASSWORD'),
            },
        });
    }
    async send(options) {
        const recipients = Array.isArray(options.to)
            ? options.to.join(',')
            : options.to;
        try {
            await this.transporter.sendMail({
                from: this.configService.get('MAIL_FROM_ADDRESS'),
                to: recipients,
                subject: options.subject,
                html: options.html,
                text: options.text,
                bcc: options.bcc
                    ? Array.isArray(options.bcc)
                        ? options.bcc.join(',')
                        : options.bcc
                    : undefined,
                attachments: options.attachments,
            });
            this.logger.log(`Email sent to ${recipients}`);
            return true;
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(`Failed to send email to ${recipients}: ${errMsg}`);
            return false;
        }
    }
    async sendWithTemplate(templateSlug, to, data, bcc) {
        const rendered = await this.emailTemplatesService.render(templateSlug, data);
        return this.send({
            to,
            subject: rendered.subject,
            html: rendered.html,
            text: rendered.text ?? undefined,
            bcc,
        });
    }
    async sendToSystem(subject, html) {
        const bccSystem = this.configService.get('MAIL_BCC_SYSTEM');
        if (!bccSystem)
            return false;
        return this.send({ to: bccSystem, subject, html });
    }
    async sendToSales(to, subject, html) {
        const bccSales = this.configService.get('MAIL_BCC_SALES');
        return this.send({ to, subject, html, bcc: bccSales });
    }
    async sendToCustomer(to, subject, html) {
        return this.send({ to, subject, html });
    }
};
exports.EmailService = EmailService;
exports.EmailService = EmailService = EmailService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        email_templates_service_1.EmailTemplatesService])
], EmailService);
//# sourceMappingURL=email.service.js.map