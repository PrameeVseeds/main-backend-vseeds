import { EmailService } from './email.service';
export declare class EmailQueueService {
    private readonly emailService;
    private readonly logger;
    constructor(emailService: EmailService);
    enqueue(templateSlug: string, to: string | string[], data: Record<string, string>, bcc?: string | string[]): Promise<void>;
    enqueueRaw(to: string | string[], subject: string, html: string, text?: string, attachments?: {
        filename: string;
        content: Buffer;
        contentType?: string;
    }[]): Promise<void>;
}
