import { ReviewsService } from './reviews.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';
import { AdminReplyDto } from './dto/admin-reply.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class ReviewsController {
    private readonly reviewsService;
    constructor(reviewsService: ReviewsService);
    getAverageRating(productId: string): Promise<{
        rating: number;
        count: number;
    }>;
    findByProduct(productId: string, pagination: PaginationDto): Promise<{
        reviews: {
            id: string;
            userId: string | null;
            name: string | null;
            rating: number;
            reviewText: string | null;
            imageUrl: string | null;
            adminReply: string | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findByProductId(id: string, pagination: PaginationDto): Promise<{
        reviews: {
            id: string;
            userId: string | null;
            name: string | null;
            rating: number;
            reviewText: string | null;
            imageUrl: string | null;
            adminReply: string | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    checkEligibility(user: JwtPayload, productId?: string): Promise<{
        eligible: boolean;
        completedOrderId: string | null;
        approvedQuoteId: string | null;
        reason: string;
    }>;
    create(user: JwtPayload, dto: CreateReviewDto): Promise<{
        deletedAt: Date | null;
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        quoteId: string | null;
        productId: string;
        rating: number;
        reviewText: string | null;
        imageUrl: string | null;
        adminReply: string | null;
        adminReplyAt: Date | null;
        isApproved: boolean;
        orderId: string | null;
    }>;
    findByUserEmail(email: string): Promise<({
        product: {
            deletedAt: Date | null;
            subCategory: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: string;
            name: string;
            slug: string;
            description: string | null;
            categoryId: string | null;
            sku: string | null;
            shortDescription: string | null;
            minPurchaseValue: number | null;
            specifications: import("@prisma/client/runtime/library").JsonValue | null;
            tags: import("@prisma/client/runtime/library").JsonValue | null;
            datasheetUrl: string | null;
            model3dUrl: string | null;
            productLink: string | null;
            subCategoryId: string | null;
            storeId: string | null;
            manufacturer: string | null;
            manufacturerProductNumber: string | null;
            quantityInHand: number;
            quantityOrdered: number;
            purchasedPrice: import("@prisma/client/runtime/library").Decimal | null;
            expectedDate: Date | null;
            isFeatured: boolean;
            isNewArrival: boolean;
        };
    } & {
        deletedAt: Date | null;
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        quoteId: string | null;
        productId: string;
        rating: number;
        reviewText: string | null;
        imageUrl: string | null;
        adminReply: string | null;
        adminReplyAt: Date | null;
        isApproved: boolean;
        orderId: string | null;
    })[]>;
    update(user: JwtPayload, productId: string, dto: UpdateReviewDto): Promise<{
        deletedAt: Date | null;
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        quoteId: string | null;
        productId: string;
        rating: number;
        reviewText: string | null;
        imageUrl: string | null;
        adminReply: string | null;
        adminReplyAt: Date | null;
        isApproved: boolean;
        orderId: string | null;
    }>;
    findById(id: string): Promise<{
        id: string;
        productId: string;
        productName: string;
        userId: string | null;
        userEmail: string | undefined;
        rating: number;
        reviewText: string | undefined;
        imageUrl: string | undefined;
        adminReply: string | undefined;
        adminReplyAt: string | undefined;
        isApproved: boolean;
        createdAt: string;
        updatedAt: string;
    }>;
    findAllAdmin(pagination: PaginationDto): Promise<{
        reviews: {
            id: string;
            userId: string | null;
            productId: string;
            rating: number;
            reviewText: string | null;
            adminReply: string | null;
            isApproved: boolean;
            createdAt: Date;
            name: string | null;
            productName: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    adminReply(id: string, dto: AdminReplyDto): Promise<{
        deletedAt: Date | null;
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        quoteId: string | null;
        productId: string;
        rating: number;
        reviewText: string | null;
        imageUrl: string | null;
        adminReply: string | null;
        adminReplyAt: Date | null;
        isApproved: boolean;
        orderId: string | null;
    }>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
