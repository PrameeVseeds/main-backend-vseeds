export declare class ReviewResponseDto {
    id: string;
    productId: string;
    productName?: string;
    userId: string;
    userEmail?: string;
    rating: number;
    reviewText?: string;
    imageUrl?: string;
    adminReply?: string;
    adminReplyAt?: string;
    isApproved: boolean;
    createdAt: string;
    updatedAt: string;
}
