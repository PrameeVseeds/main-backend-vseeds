export declare class UpdateReviewDto {
    reviewText?: string;
    rating?: number;
    imageUrl?: string;
}
