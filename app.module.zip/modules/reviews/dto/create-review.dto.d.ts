export declare class CreateReviewDto {
    productId: string;
    reviewText: string;
    rating: number;
    imageUrl?: string;
    orderId?: string;
    quoteId?: string;
}
