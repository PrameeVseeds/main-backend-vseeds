export declare class ReviewsModule {
}
