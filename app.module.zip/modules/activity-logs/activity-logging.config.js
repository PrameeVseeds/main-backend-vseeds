"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SENSITIVE_FIELDS = exports.ENTITY_TABLE_MAP = exports.PATH_SEGMENT_TO_ENTITY = exports.METHOD_ACTION_MAP = exports.ALWAYS_LOG_DELETE = exports.LOGGED_ENTITIES = exports.LOGGABLE_METHODS = exports.LOGIN_PATHS = exports.SKIP_PATHS = void 0;
exports.SKIP_PATHS = [
    '/api/health',
    '/api/activity-logs',
    '/api/docs',
    '/api/auth/refresh-token',
    '/api/email-templates/preview',
    '/api/email-templates/send-test',
];
exports.LOGIN_PATHS = ['/api/auth/admin-login', '/api/auth/user-login'];
exports.LOGGABLE_METHODS = ['POST', 'PUT', 'PATCH', 'DELETE'];
exports.LOGGED_ENTITIES = [
    'auth',
    'admin',
    'role',
    'user',
    'product',
    'category',
    'order',
    'payment',
    'delivery',
    'setting',
    'email_template',
];
exports.ALWAYS_LOG_DELETE = true;
exports.METHOD_ACTION_MAP = {
    POST: 'create',
    PUT: 'update',
    PATCH: 'update',
    DELETE: 'delete',
};
exports.PATH_SEGMENT_TO_ENTITY = {
    products: 'product',
    categories: 'category',
    orders: 'order',
    users: 'user',
    payments: 'payment',
    reviews: 'review',
    wishlists: 'wishlist',
    deliveries: 'delivery',
    contact: 'contact',
    images: 'media',
    roles: 'role',
    admins: 'admin',
    auth: 'auth',
    quotes: 'quote',
    banner: 'banner',
    blogs: 'blog',
    faqs: 'faq',
    projects: 'project',
    settings: 'setting',
    'email-templates': 'email_template',
};
exports.ENTITY_TABLE_MAP = {
    product: { table: 'products', nameCol: 'name' },
    category: { table: 'categories', nameCol: 'name' },
    order: { table: 'orders', nameCol: 'order_number' },
    user: { table: 'users', nameCol: 'first_name' },
    admin: { table: 'admins', nameCol: 'username' },
    role: { table: 'roles', nameCol: 'name' },
    banner: { table: 'banners', nameCol: 'title' },
    blog: { table: 'blogs', nameCol: 'title' },
    faq: { table: 'faqs', nameCol: 'question' },
    project: { table: 'projects', nameCol: 'title' },
    setting: { table: 'settings', nameCol: 'setting_key' },
    contact: { table: 'contacts', nameCol: 'name' },
    review: { table: 'product_reviews', nameCol: 'review_text' },
    payment: { table: 'payments', nameCol: 'payment_number' },
    delivery: { table: 'shipments', nameCol: 'tracking_number' },
    media: { table: 'media', nameCol: 'original_name' },
    quote: { table: 'quotes', nameCol: 'quote_number' },
    email_template: { table: 'email_templates', nameCol: 'name' },
    wishlist: { table: 'wishlists' },
};
exports.SENSITIVE_FIELDS = [
    'password',
    'passwordHash',
    'password_hash',
    'twoFactorSecret',
    'two_factor_secret',
    'refreshToken',
    'refresh_token',
];
//# sourceMappingURL=activity-logging.config.js.map