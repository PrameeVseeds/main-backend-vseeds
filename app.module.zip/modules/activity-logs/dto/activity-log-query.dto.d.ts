export declare class ActivityLogQueryDto {
    actor_id?: string;
    actor_type?: string;
    action?: string;
    entity_type?: string;
    entity_id?: string;
    start_date?: string;
    end_date?: string;
    limit?: number;
    offset?: number;
}
