export declare class CreateActivityLogDto {
    actorId?: string;
    actorType?: string;
    action: string;
    entityType: string;
    entityId?: string;
    description?: string;
    ipAddress?: string;
    userAgent?: string;
    metadata?: any;
}
