export declare const SKIP_PATHS: string[];
export declare const LOGIN_PATHS: string[];
export declare const LOGGABLE_METHODS: readonly ["POST", "PUT", "PATCH", "DELETE"];
export declare const LOGGED_ENTITIES: readonly ["auth", "admin", "role", "user", "product", "category", "order", "payment", "delivery", "setting", "email_template"];
export declare const ALWAYS_LOG_DELETE = true;
export declare const METHOD_ACTION_MAP: Record<string, string>;
export declare const PATH_SEGMENT_TO_ENTITY: Record<string, string>;
export declare const ENTITY_TABLE_MAP: Record<string, {
    table: string;
    nameCol?: string;
}>;
export declare const SENSITIVE_FIELDS: string[];
