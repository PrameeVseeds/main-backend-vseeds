import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { PrismaService } from '../../prisma/prisma.service';
import { ActivityLogsService } from './activity-logs.service';
export declare class ActivityLoggingInterceptor implements NestInterceptor {
    private readonly activityLogsService;
    private readonly prisma;
    constructor(activityLogsService: ActivityLogsService, prisma: PrismaService);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
    private isAuditable;
    private fetchOldEntity;
    private sanitize;
    private logActivity;
    private buildChanges;
    private extractEntityName;
    private buildDescription;
    private extractEntityType;
    private extractEntityIdFromUrl;
    private extractEntityId;
    private safeStringify;
}
