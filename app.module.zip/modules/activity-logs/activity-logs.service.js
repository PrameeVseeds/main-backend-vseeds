"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLogsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const activity_logging_config_1 = require("./activity-logging.config");
const token_blacklist_service_1 = require("../../common/services/token-blacklist.service");
const LOGGABLE_ACTIONS = ['login', 'create', 'update', 'delete'];
let ActivityLogsService = class ActivityLogsService {
    prisma;
    tokenBlacklist;
    encryptionService;
    constructor(prisma, tokenBlacklist, encryptionService) {
        this.prisma = prisma;
        this.tokenBlacklist = tokenBlacklist;
        this.encryptionService = encryptionService;
    }
    async create(dto) {
        return this.prisma.activityLog.create({
            data: {
                actorId: dto.actorId ?? null,
                actorType: dto.actorType ?? 'system',
                action: dto.action,
                entityType: dto.entityType,
                entityId: dto.entityId ?? null,
                description: dto.description ?? null,
                ipAddress: dto.ipAddress ?? null,
                userAgent: dto.userAgent ?? null,
                metadata: dto.metadata ?? null,
            },
        });
    }
    async findOne(id) {
        const log = await this.prisma.activityLog.findUnique({ where: { id } });
        if (!log)
            return null;
        const withActors = await this.resolveActorNames([log]);
        const enriched = await this.resolveEntityDisplayNames(withActors);
        const [decrypted] = this.decryptSensitiveFields(enriched);
        return decrypted;
    }
    async findAll(query) {
        const where = {
            action: {
                in: LOGGABLE_ACTIONS,
            },
        };
        if (query.actor_id)
            where.actorId = query.actor_id;
        if (query.actor_type)
            where.actorType = query.actor_type;
        if (query.action)
            where.action = query.action;
        if (query.entity_type)
            where.entityType = query.entity_type;
        if (query.entity_id)
            where.entityId = query.entity_id;
        if (query.start_date || query.end_date) {
            where.createdAt = {};
            if (query.start_date)
                where.createdAt.gte = new Date(query.start_date);
            if (query.end_date)
                where.createdAt.lte = new Date(query.end_date);
        }
        const [logs, total] = await this.prisma.$transaction([
            this.prisma.activityLog.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: query.offset || 0,
                take: query.limit || 50,
            }),
            this.prisma.activityLog.count({ where }),
        ]);
        const withActors = await this.resolveActorNames(logs);
        const enriched = await this.resolveEntityDisplayNames(withActors);
        const decrypted = this.decryptSensitiveFields(enriched);
        return { logs: decrypted, total };
    }
    async resolveActorNames(logs) {
        const adminIds = [
            ...new Set(logs
                .filter((l) => l.actorType === 'admin' && l.actorId)
                .map((l) => l.actorId)),
        ];
        const userIds = [
            ...new Set(logs
                .filter((l) => l.actorType === 'user' && l.actorId)
                .map((l) => l.actorId)),
        ];
        const adminMap = new Map();
        const userMap = new Map();
        if (adminIds.length) {
            const admins = await this.prisma.admin.findMany({
                where: { id: { in: adminIds } },
                select: {
                    id: true,
                    username: true,
                    email: true,
                    role: { select: { name: true } },
                },
            });
            admins.forEach((a) => adminMap.set(a.id, {
                name: this.encryptionService.decrypt(a.username) || this.encryptionService.decrypt(a.email),
                email: this.encryptionService.decrypt(a.email),
                role: a.role?.name || 'admin',
            }));
        }
        if (userIds.length) {
            const users = await this.prisma.user.findMany({
                where: { id: { in: userIds } },
                select: { id: true, firstName: true, email: true },
            });
            users.forEach((u) => userMap.set(u.id, {
                name: u.firstName || this.encryptionService.decrypt(u.email),
                email: this.encryptionService.decrypt(u.email),
                role: 'customer',
            }));
        }
        return logs.map((log) => {
            let actor = { name: 'System', email: '', role: 'system' };
            if (log.actorType === 'admin' && log.actorId) {
                actor = adminMap.get(log.actorId) || {
                    name: `Admin #${log.actorId}`,
                    email: '',
                    role: 'admin',
                };
            }
            else if (log.actorType === 'user' && log.actorId) {
                actor = userMap.get(log.actorId) || {
                    name: `User #${log.actorId}`,
                    email: '',
                    role: 'customer',
                };
            }
            return {
                ...log,
                actorName: actor.name,
                actorEmail: actor.email,
                actorRole: actor.role,
            };
        });
    }
    async resolveEntityDisplayNames(logs) {
        const byType = new Map();
        for (const log of logs) {
            const id = log.entityId?.trim();
            if (!id || !log.entityType)
                continue;
            const list = byType.get(log.entityType) ?? [];
            if (!list.includes(id))
                list.push(id);
            byType.set(log.entityType, list);
        }
        const labelMap = new Map();
        for (const [entityType, ids] of byType) {
            if (!ids.length)
                continue;
            const batch = await this.batchEntityLabels(entityType, ids);
            batch.forEach((label, trimmedId) => {
                labelMap.set(`${entityType}:${trimmedId}`, label);
            });
        }
        return logs.map((log) => {
            const id = log.entityId?.trim();
            let entityDisplayName;
            if (id && log.entityType) {
                entityDisplayName = labelMap.get(`${log.entityType}:${id}`);
                if (!entityDisplayName) {
                    entityDisplayName = this.shortEntityIdFallback(id);
                }
            }
            return { ...log, entityDisplayName };
        });
    }
    shortEntityIdFallback(entityId) {
        const t = entityId.trim();
        return t.length >= 8 ? `…${t.slice(-8)}` : t || '—';
    }
    async batchEntityLabels(entityType, ids) {
        const out = new Map();
        if (!ids.length)
            return out;
        try {
            if (entityType === 'wishlist') {
                const placeholders = ids.map(() => '?').join(',');
                const rows = await this.prisma.$queryRawUnsafe(`SELECT TRIM(w.id) AS id, p.name AS label FROM wishlists w INNER JOIN products p ON TRIM(p.id) = TRIM(w.product_id) WHERE TRIM(w.id) IN (${placeholders})`, ...ids);
                for (const row of rows) {
                    const id = String(row.id ?? '').trim();
                    const label = String(row.label ?? '').trim();
                    if (id && label)
                        out.set(id, label);
                }
                return out;
            }
            const config = activity_logging_config_1.ENTITY_TABLE_MAP[entityType];
            if (!config?.nameCol)
                return out;
            const { table, nameCol } = config;
            if (!/^[a-z_][a-z0-9_]*$/i.test(table) ||
                !/^[a-z_][a-z0-9_]*$/i.test(nameCol)) {
                return out;
            }
            const placeholders = ids.map(() => '?').join(',');
            const rows = await this.prisma.$queryRawUnsafe(`SELECT TRIM(t.id) AS id, t.\`${nameCol}\` AS disp FROM \`${table}\` t WHERE TRIM(t.id) IN (${placeholders})`, ...ids);
            for (const row of rows) {
                const id = String(row.id ?? '').trim();
                const rawDisp = row.disp ?? row.DISP;
                let label = rawDisp != null && rawDisp !== undefined
                    ? String(rawDisp).trim()
                    : '';
                if (entityType === 'review' && label.length > 80) {
                    label = `${label.slice(0, 77)}…`;
                }
                if (id && label)
                    out.set(id, label);
            }
        }
        catch {
        }
        return out;
    }
    async findRecent(days = 7, limit = 20) {
        const since = new Date();
        since.setDate(since.getDate() - days);
        return this.prisma.activityLog.findMany({
            where: {
                action: { in: LOGGABLE_ACTIONS },
                createdAt: { gte: since },
            },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }
    async findRecentRaw(days = 7, limit = 20) {
        return this.prisma.$queryRawUnsafe(`SELECT * FROM activity_logs WHERE action IN ('login','create','update','delete') AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) ORDER BY created_at DESC LIMIT ?`, days, limit);
    }
    decryptSensitiveFields(logs) {
        return logs.map(log => {
            const decrypted = { ...log };
            if (decrypted.description && typeof decrypted.description === 'string') {
                decrypted.description = this.decryptStringIfEncrypted(decrypted.description);
            }
            if (decrypted.entityDisplayName && typeof decrypted.entityDisplayName === 'string') {
                decrypted.entityDisplayName = this.decryptStringIfEncrypted(decrypted.entityDisplayName);
            }
            if (decrypted.metadata && typeof decrypted.metadata === 'object') {
                decrypted.metadata = this.decryptMetadata(decrypted.metadata);
            }
            return decrypted;
        });
    }
    decryptStringIfEncrypted(str) {
        if (str.startsWith('ENC:v1:')) {
            try {
                return this.encryptionService.decrypt(str);
            }
            catch {
                return str;
            }
        }
        const encryptedPattern = /ENC:v1:[^"]+/g;
        if (encryptedPattern.test(str)) {
            try {
                return str.replace(encryptedPattern, (match) => {
                    try {
                        return this.encryptionService.decrypt(match);
                    }
                    catch {
                        return match;
                    }
                });
            }
            catch {
                return str;
            }
        }
        return str;
    }
    decryptMetadata(metadata) {
        if (!metadata || typeof metadata !== 'object')
            return metadata;
        const decrypted = { ...metadata };
        if (decrypted.oldData && typeof decrypted.oldData === 'object') {
            decrypted.oldData = this.decryptObjectFields(decrypted.oldData);
        }
        if (decrypted.newData && typeof decrypted.newData === 'object') {
            decrypted.newData = this.decryptObjectFields(decrypted.newData);
        }
        return decrypted;
    }
    decryptObjectFields(obj) {
        if (!obj || typeof obj !== 'object')
            return obj;
        const decrypted = { ...obj };
        const encryptedFields = ['username', 'email', 'bankName', 'branch', 'accountNumber', 'accountName', 'code', 'customerEmail'];
        for (const field of encryptedFields) {
            if (decrypted[field] && typeof decrypted[field] === 'string' && decrypted[field].startsWith('ENC:v1:')) {
                try {
                    decrypted[field] = this.encryptionService.decrypt(decrypted[field]);
                }
                catch {
                }
            }
        }
        return decrypted;
    }
    async findByUser(actorId, pagination) {
        const page = pagination?.page ?? 1;
        const limit = Math.min(100, Math.max(1, pagination?.limit ?? 50));
        const where = {
            actorId,
            action: { in: LOGGABLE_ACTIONS },
        };
        const [logs, total] = await this.prisma.$transaction([
            this.prisma.activityLog.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.activityLog.count({ where }),
        ]);
        return { logs, total, totalPages: Math.ceil(total / limit), page };
    }
    async findByEntity(entityType, entityId, pagination) {
        const page = pagination?.page ?? 1;
        const limit = Math.min(100, Math.max(1, pagination?.limit ?? 50));
        const where = {
            entityType,
            entityId,
            action: { in: LOGGABLE_ACTIONS },
        };
        const [logs, total] = await this.prisma.$transaction([
            this.prisma.activityLog.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.activityLog.count({ where }),
        ]);
        return { logs, total, totalPages: Math.ceil(total / limit), page };
    }
    async getNotifications(days = 7, limit = 30) {
        const since = new Date();
        since.setDate(since.getDate() - days);
        const [recentOrders, recentQuotes] = await Promise.all([
            this.prisma.order.findMany({
                select: {
                    id: true,
                    orderNumber: true,
                    userId: true,
                    totalAmount: true,
                    status: true,
                    orderType: true,
                    createdAt: true,
                    user: {
                        select: {
                            firstName: true,
                            lastName: true,
                            email: true,
                        },
                    },
                },
                where: { createdAt: { gte: since } },
                orderBy: { createdAt: 'desc' },
                take: limit,
            }),
            this.prisma.quote.findMany({
                select: {
                    id: true,
                    quoteNumber: true,
                    customerName: true,
                    customerEmail: true,
                    serviceType: true,
                    totalPrice: true,
                    status: true,
                    createdAt: true,
                },
                where: { createdAt: { gte: since } },
                orderBy: { createdAt: 'desc' },
                take: limit,
            }),
        ]);
        const orders = recentOrders.map((o) => ({
            id: o.id,
            type: 'order',
            source: 'electronics-vseeds',
            orderNumber: o.orderNumber,
            customerName: o.user
                ? `${o.user.firstName ?? ''} ${o.user.lastName ?? ''}`.trim() ||
                    o.user.email
                : `User #${o.userId}`,
            customerEmail: o.user?.email ?? '',
            totalAmount: Number(o.totalAmount),
            status: o.status,
            createdAt: o.createdAt,
        }));
        const quotes = recentQuotes.map((q) => ({
            id: q.id,
            type: 'quote',
            source: 'embedded-vseeds',
            quoteNumber: q.quoteNumber,
            customerName: q.customerName,
            customerEmail: q.customerEmail,
            serviceType: q.serviceType,
            totalPrice: q.totalPrice ? Number(q.totalPrice) : null,
            status: q.status,
            createdAt: q.createdAt,
        }));
        const all = [...orders, ...quotes].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return {
            notifications: all.slice(0, limit),
            orderCount: orders.length,
            quoteCount: quotes.length,
        };
    }
    async getStatistics(days = 30) {
        const [totalResult] = await this.prisma.$queryRawUnsafe(`SELECT COUNT(*) as total FROM activity_logs WHERE action IN ('login','create','update','delete') AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)`, days);
        const byEntityType = await this.prisma.$queryRawUnsafe(`SELECT entity_type, COUNT(*) as count FROM activity_logs WHERE action IN ('login','create','update','delete') AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY entity_type ORDER BY count DESC`, days);
        const byActorType = await this.prisma.$queryRawUnsafe(`SELECT actor_type, COUNT(*) as count FROM activity_logs WHERE action IN ('login','create','update','delete') AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY actor_type ORDER BY count DESC`, days);
        const byAction = await this.prisma.$queryRawUnsafe(`SELECT action, COUNT(*) as count FROM activity_logs WHERE action IN ('login','create','update','delete') AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY action ORDER BY count DESC`, days);
        return {
            total: Number(totalResult?.total || 0),
            days,
            byEntityType,
            byActorType,
            byAction,
        };
    }
    async deleteOne(id) {
        const log = await this.prisma.activityLog.findUnique({ where: { id } });
        if (!log)
            return { message: 'Not found' };
        const metadataObj = log.metadata;
        const sessionToken = metadataObj?.sessionToken;
        if (sessionToken) {
            this.tokenBlacklist.revoke(sessionToken);
        }
        await this.prisma.activityLog.delete({ where: { id } });
        return { message: 'Session revoked and removed' };
    }
    async cleanOldLogs(days = 90) {
        const result = await this.prisma.$queryRawUnsafe(`DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)`, days);
        return {
            message: `Cleaned logs older than ${days} days`,
            affected: result?.affectedRows || 0,
        };
    }
};
exports.ActivityLogsService = ActivityLogsService;
exports.ActivityLogsService = ActivityLogsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        token_blacklist_service_1.TokenBlacklistService,
        encryption_service_1.EncryptionService])
], ActivityLogsService);
//# sourceMappingURL=activity-logs.service.js.map