"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLoggingInterceptor = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const prisma_service_1 = require("../../prisma/prisma.service");
const activity_logs_service_1 = require("./activity-logs.service");
const activity_logging_config_1 = require("./activity-logging.config");
let ActivityLoggingInterceptor = class ActivityLoggingInterceptor {
    activityLogsService;
    prisma;
    constructor(activityLogsService, prisma) {
        this.activityLogsService = activityLogsService;
        this.prisma = prisma;
    }
    intercept(context, next) {
        if (process.env.DISABLE_ACTIVITY_LOGGING === 'true')
            return next.handle();
        const req = context.switchToHttp().getRequest();
        const { method, originalUrl } = req;
        const isLogin = activity_logging_config_1.LOGIN_PATHS.includes(originalUrl);
        const isLoggable = activity_logging_config_1.LOGGABLE_METHODS.includes(method);
        if (activity_logging_config_1.SKIP_PATHS.some((p) => originalUrl.startsWith(p)) ||
            method === 'OPTIONS' ||
            method === 'GET' ||
            (!isLoggable && !isLogin)) {
            return next.handle();
        }
        const entityType = this.extractEntityType(originalUrl);
        if (!this.isAuditable(entityType, method, isLogin)) {
            return next.handle();
        }
        const start = Date.now();
        const needsOldData = method === 'PUT' || method === 'PATCH' || method === 'DELETE';
        const entityId = this.extractEntityIdFromUrl(originalUrl);
        const oldData$ = needsOldData && entityId
            ? (0, rxjs_1.from)(this.fetchOldEntity(entityType, entityId).catch(() => null))
            : (0, rxjs_1.of)(null);
        return oldData$.pipe((0, rxjs_1.switchMap)((oldData) => next.handle().pipe((0, rxjs_1.tap)({
            next: (responseBody) => {
                this.logActivity(req, Date.now() - start, 'success', responseBody, oldData);
            },
            error: () => {
                this.logActivity(req, Date.now() - start, 'error', undefined, oldData);
            },
        }))));
    }
    isAuditable(entityType, method, isLogin) {
        if (isLogin)
            return true;
        if (activity_logging_config_1.ALWAYS_LOG_DELETE && method === 'DELETE')
            return true;
        return activity_logging_config_1.LOGGED_ENTITIES.includes(entityType);
    }
    async fetchOldEntity(entityType, entityId) {
        const mapping = activity_logging_config_1.ENTITY_TABLE_MAP[entityType];
        if (!mapping)
            return null;
        const rows = await this.prisma.$queryRawUnsafe(`SELECT * FROM \`${mapping.table}\` WHERE id = ? LIMIT 1`, entityId);
        if (!Array.isArray(rows) || rows.length === 0)
            return null;
        const firstRow = rows[0];
        return this.sanitize(firstRow);
    }
    sanitize(data) {
        if (!data || typeof data !== 'object')
            return null;
        const clean = { ...data };
        for (const key of activity_logging_config_1.SENSITIVE_FIELDS) {
            delete clean[key];
        }
        return clean;
    }
    logActivity(req, duration, result, responseBody, oldData) {
        let actorId = req.user?.id || undefined;
        let actorType = req.user?.type || 'system';
        const entityType = this.extractEntityType(req.originalUrl);
        const isLogin = activity_logging_config_1.LOGIN_PATHS.includes(req.originalUrl);
        let sessionToken;
        if (isLogin && result === 'success') {
            const loginUser = responseBody?.data?.user || responseBody?.user;
            if (loginUser) {
                actorId = loginUser.id || undefined;
                actorType = req.originalUrl.includes('admin') ? 'admin' : 'user';
            }
            sessionToken =
                responseBody?.data?.accessToken || responseBody?.accessToken;
        }
        const action = isLogin
            ? 'login'
            : activity_logging_config_1.METHOD_ACTION_MAP[req.method] || req.method.toLowerCase();
        const entityId = this.extractEntityId(req.originalUrl, responseBody);
        const entityName = this.extractEntityName(entityType, oldData, responseBody, req.body);
        const description = this.buildDescription(req, action, entityType, entityName, result);
        const changes = action === 'update' && oldData
            ? this.buildChanges(oldData, req.body)
            : undefined;
        this.activityLogsService
            .create({
            actorId,
            actorType,
            action,
            entityType,
            entityId,
            description,
            ipAddress: req.ip ||
                (Array.isArray(req.headers?.['x-forwarded-for'])
                    ? req.headers['x-forwarded-for'][0]
                    : req.headers?.['x-forwarded-for']) ||
                '',
            userAgent: req.headers?.['user-agent'] || '',
            metadata: {
                duration,
                result,
                statusCode: result === 'success' ? 200 : 500,
                ...(changes ? { changes } : {}),
                ...(sessionToken ? { sessionToken } : {}),
            },
        })
            .catch(() => { });
    }
    buildChanges(oldData, requestBody) {
        if (!oldData || !requestBody || typeof requestBody !== 'object')
            return undefined;
        const changes = [];
        for (const key of Object.keys(requestBody)) {
            if (activity_logging_config_1.SENSITIVE_FIELDS.includes(key))
                continue;
            const snakeKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            const oldVal = oldData[key] ?? oldData[snakeKey];
            const newVal = requestBody[key];
            if (oldVal !== undefined &&
                this.safeStringify(oldVal) !== this.safeStringify(newVal)) {
                changes.push({ field: key, from: oldVal, to: newVal });
            }
        }
        return changes.length > 0 ? changes : undefined;
    }
    extractEntityName(entityType, oldData, responseBody, reqBody) {
        const mapping = activity_logging_config_1.ENTITY_TABLE_MAP[entityType];
        if (!mapping?.nameCol)
            return '';
        const col = mapping.nameCol.replace(/`/g, '');
        const val = oldData?.[col] ??
            responseBody?.data?.[col] ??
            responseBody?.[col] ??
            reqBody?.[col] ??
            '';
        return this.safeStringify(val);
    }
    buildDescription(req, action, entityType, entityName, result) {
        if (action === 'login') {
            const email = req.body?.email || 'unknown';
            const type = req.originalUrl.includes('admin') ? 'Admin' : 'User';
            return result === 'success'
                ? `${type} login successful for ${email}`
                : `${type} login failed for ${email}`;
        }
        const actionLabel = action.charAt(0).toUpperCase() + action.slice(1);
        const typeLabel = entityType.replace(/_/g, ' ');
        const nameLabel = entityName ? ` "${entityName}"` : '';
        return `${actionLabel} ${typeLabel}${nameLabel} - ${result}`;
    }
    extractEntityType(url) {
        const segments = url.replace('/api/', '').split('/');
        return activity_logging_config_1.PATH_SEGMENT_TO_ENTITY[segments[0]] || 'other';
    }
    extractEntityIdFromUrl(url) {
        const segments = url.replace('/api/', '').split('/');
        const lastSegment = segments[segments.length - 1];
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        return uuidRegex.test(lastSegment) ? lastSegment : undefined;
    }
    extractEntityId(url, responseBody) {
        const fromUrl = this.extractEntityIdFromUrl(url);
        if (fromUrl)
            return fromUrl;
        const data = responseBody?.data || responseBody;
        return data?.id ? String(data.id) : undefined;
    }
    safeStringify(val) {
        if (val === null || val === undefined)
            return '';
        if (typeof val === 'object') {
            try {
                return JSON.stringify(val);
            }
            catch {
                return '[Object]';
            }
        }
        if (typeof val === 'string' ||
            typeof val === 'number' ||
            typeof val === 'boolean' ||
            typeof val === 'symbol' ||
            typeof val === 'bigint') {
            return String(val);
        }
        return '';
    }
};
exports.ActivityLoggingInterceptor = ActivityLoggingInterceptor;
exports.ActivityLoggingInterceptor = ActivityLoggingInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [activity_logs_service_1.ActivityLogsService,
        prisma_service_1.PrismaService])
], ActivityLoggingInterceptor);
//# sourceMappingURL=activity-logging.interceptor.js.map