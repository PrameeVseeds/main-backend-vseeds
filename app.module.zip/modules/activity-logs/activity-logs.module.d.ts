export declare class ActivityLogsModule {
}
