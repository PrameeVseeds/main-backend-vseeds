import { ActivityLogsService } from './activity-logs.service';
import { ActivityLogQueryDto } from './dto/activity-log-query.dto';
import { CreateActivityLogDto } from './dto/create-activity-log.dto';
export declare class ActivityLogsController {
    private readonly activityLogsService;
    constructor(activityLogsService: ActivityLogsService);
    findAll(query: ActivityLogQueryDto): Promise<{
        logs: any[];
        total: number;
    }>;
    findOne(id: string): Promise<any>;
    findRecent(days?: number, limit?: number): Promise<any[]>;
    getNotifications(days?: number, limit?: number): Promise<{
        notifications: ({
            id: string;
            type: "order";
            source: string;
            orderNumber: string;
            customerName: string;
            customerEmail: string;
            totalAmount: number;
            status: import(".prisma/client").$Enums.OrderStatus;
            createdAt: Date;
        } | {
            id: string;
            type: "quote";
            source: string;
            quoteNumber: string;
            customerName: string;
            customerEmail: string;
            serviceType: string;
            totalPrice: number | null;
            status: string;
            createdAt: Date;
        })[];
        orderCount: number;
        quoteCount: number;
    }>;
    getStatistics(days?: number): Promise<{
        total: number;
        days: number;
        byEntityType: any[];
        byActorType: any[];
        byAction: any[];
    }>;
    findByUser(userId: string, query: {
        page?: number;
        limit?: number;
    }): Promise<{
        logs: {
            id: string;
            createdAt: Date;
            description: string | null;
            actorId: string | null;
            actorType: string;
            action: string;
            entityType: string;
            entityId: string | null;
            ipAddress: string | null;
            userAgent: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findByEntity(entityType: string, entityId: string, query: {
        page?: number;
        limit?: number;
    }): Promise<{
        logs: {
            id: string;
            createdAt: Date;
            description: string | null;
            actorId: string | null;
            actorType: string;
            action: string;
            entityType: string;
            entityId: string | null;
            ipAddress: string | null;
            userAgent: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    create(dto: CreateActivityLogDto): Promise<{
        id: string;
        createdAt: Date;
        description: string | null;
        actorId: string | null;
        actorType: string;
        action: string;
        entityType: string;
        entityId: string | null;
        ipAddress: string | null;
        userAgent: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue | null;
    }>;
    deleteOne(id: string): Promise<{
        message: string;
    }>;
    clean(days?: number): Promise<{
        message: string;
        affected: any;
    }>;
}
