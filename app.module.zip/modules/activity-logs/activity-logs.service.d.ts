import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { TokenBlacklistService } from '../../common/services/token-blacklist.service';
import { CreateActivityLogDto } from './dto/create-activity-log.dto';
import { ActivityLogQueryDto } from './dto/activity-log-query.dto';
export declare class ActivityLogsService {
    private readonly prisma;
    private readonly tokenBlacklist;
    private readonly encryptionService;
    constructor(prisma: PrismaService, tokenBlacklist: TokenBlacklistService, encryptionService: EncryptionService);
    create(dto: CreateActivityLogDto): Promise<{
        id: string;
        createdAt: Date;
        description: string | null;
        actorId: string | null;
        actorType: string;
        action: string;
        entityType: string;
        entityId: string | null;
        ipAddress: string | null;
        userAgent: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue | null;
    }>;
    findOne(id: string): Promise<any>;
    findAll(query: ActivityLogQueryDto): Promise<{
        logs: any[];
        total: number;
    }>;
    private resolveActorNames;
    private resolveEntityDisplayNames;
    private shortEntityIdFallback;
    private batchEntityLabels;
    findRecent(days?: number, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        description: string | null;
        actorId: string | null;
        actorType: string;
        action: string;
        entityType: string;
        entityId: string | null;
        ipAddress: string | null;
        userAgent: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue | null;
    }[]>;
    findRecentRaw(days?: number, limit?: number): Promise<any[]>;
    private decryptSensitiveFields;
    private decryptStringIfEncrypted;
    private decryptMetadata;
    private decryptObjectFields;
    findByUser(actorId: string, pagination?: {
        page?: number;
        limit?: number;
    }): Promise<{
        logs: {
            id: string;
            createdAt: Date;
            description: string | null;
            actorId: string | null;
            actorType: string;
            action: string;
            entityType: string;
            entityId: string | null;
            ipAddress: string | null;
            userAgent: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findByEntity(entityType: string, entityId: string, pagination?: {
        page?: number;
        limit?: number;
    }): Promise<{
        logs: {
            id: string;
            createdAt: Date;
            description: string | null;
            actorId: string | null;
            actorType: string;
            action: string;
            entityType: string;
            entityId: string | null;
            ipAddress: string | null;
            userAgent: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    getNotifications(days?: number, limit?: number): Promise<{
        notifications: ({
            id: string;
            type: "order";
            source: string;
            orderNumber: string;
            customerName: string;
            customerEmail: string;
            totalAmount: number;
            status: import(".prisma/client").$Enums.OrderStatus;
            createdAt: Date;
        } | {
            id: string;
            type: "quote";
            source: string;
            quoteNumber: string;
            customerName: string;
            customerEmail: string;
            serviceType: string;
            totalPrice: number | null;
            status: string;
            createdAt: Date;
        })[];
        orderCount: number;
        quoteCount: number;
    }>;
    getStatistics(days?: number): Promise<{
        total: number;
        days: number;
        byEntityType: any[];
        byActorType: any[];
        byAction: any[];
    }>;
    deleteOne(id: string): Promise<{
        message: string;
    }>;
    cleanOldLogs(days?: number): Promise<{
        message: string;
        affected: any;
    }>;
}
