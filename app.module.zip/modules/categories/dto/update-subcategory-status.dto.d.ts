export declare class UpdateSubcategoryStatusDto {
    parentId: string;
    status: string;
}
