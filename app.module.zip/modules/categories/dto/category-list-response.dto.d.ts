export declare class CategoryListResponseDto {
    id: string;
    name: string;
    slug: string;
    icon?: string;
    status?: string;
    displayOrder?: number;
    parentId?: string | null;
    children?: CategoryListResponseDto[];
    createdAt?: Date;
    updatedAt?: Date;
}
