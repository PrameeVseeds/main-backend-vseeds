export declare class CreateCategoryDto {
    name: string;
    parentId?: string;
    icon?: string;
    description?: string;
    displayOrder?: number;
    slug?: string;
    status?: string;
    products?: unknown[];
    statusType?: string;
}
