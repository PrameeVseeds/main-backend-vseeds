"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoriesService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const redis_cache_service_1 = require("../../common/services/redis-cache.service");
let CategoriesService = class CategoriesService {
    prisma;
    configService;
    cacheService;
    constructor(prisma, configService, cacheService) {
        this.prisma = prisma;
        this.configService = configService;
        this.cacheService = cacheService;
    }
    get defaultIcon() {
        const icon = this.configService.get('DEFAULT_CATEGORY_ICON');
        if (!icon)
            return '';
        if (icon.startsWith('http://') || icon.startsWith('https://')) {
            return icon;
        }
        const baseUrl = this.configService.get('BASE_URL') || '';
        return `${baseUrl}/uploads/media/${icon}`;
    }
    mapCategory(category) {
        if (!category)
            return category;
        if (!category.icon) {
            category.icon = this.defaultIcon;
        }
        if (category.children) {
            category.children = category.children.map((child) => this.mapCategory(child));
        }
        return category;
    }
    toListDto(cat) {
        const icon = cat.icon || this.defaultIcon;
        return {
            id: cat.id,
            name: cat.name,
            slug: cat.slug,
            icon,
            status: cat.status,
            displayOrder: cat.displayOrder,
            parentId: cat.parentId,
            children: cat.children?.map((c) => this.toListDto(c)),
            createdAt: cat.createdAt,
            updatedAt: cat.updatedAt,
        };
    }
    async findAll(status, limit = 5) {
        const cacheKey = `categories:all:${status || 'any'}:${limit}`;
        const cached = await this.cacheService.get(cacheKey);
        if (cached && cached.length > 0) {
            return cached;
        }
        const whereCondition = { parentId: null };
        if (status)
            whereCondition.status = status;
        const categories = await this.prisma.category.findMany({
            where: whereCondition,
            include: { children: true },
            orderBy: [{ displayOrder: 'asc' }, { id: 'asc' }],
            take: limit,
        });
        if (categories.length === 0)
            return [];
        const rootIds = categories.map((c) => c.id);
        const productSubsMap = await this.getProductSubcategoriesByCategoryIds(rootIds, status);
        const result = categories.map((cat) => {
            const dto = this.toListDto(this.mapCategory(cat));
            const productSubs = productSubsMap.get(cat.id) || [];
            const existingNames = new Set((dto.children || []).map((c) => (c.name || '').toLowerCase().trim()));
            const added = productSubs.filter((p) => !existingNames.has((p.name || '').toLowerCase().trim()));
            dto.children = [...(dto.children || []), ...added].sort((a, b) => (a.name || '').localeCompare(b.name || ''));
            return dto;
        });
        await this.cacheService.set(cacheKey, result, 300000);
        return result;
    }
    async search(query) {
        const categories = await this.prisma.category.findMany({
            where: { name: { contains: query } },
            include: { children: true },
            orderBy: [{ displayOrder: 'asc' }, { id: 'asc' }],
        });
        return categories.map((cat) => this.toListDto(this.mapCategory(cat)));
    }
    async findById(id) {
        const category = await this.prisma.category.findUnique({
            where: { id },
            include: { children: true, parent: true },
        });
        if (!category)
            throw new common_1.NotFoundException('Category not found');
        return this.toListDto(this.mapCategory(category));
    }
    async findBySlug(slug) {
        const category = await this.prisma.category.findUnique({
            where: { slug },
            include: { children: true, parent: true },
        });
        if (!category)
            throw new common_1.NotFoundException('Category not found');
        return this.toListDto(this.mapCategory(category));
    }
    async create(dto) {
        const slug = this.generateSlug(dto.name);
        const icon = dto.icon || this.defaultIcon;
        const saved = await this.prisma.category.create({
            data: {
                name: dto.name,
                slug,
                icon,
                description: dto.description ?? null,
                displayOrder: dto.displayOrder ?? 0,
                status: dto.status ?? 'active',
                parentId: dto.parentId ?? null,
            },
        });
        void this.cacheService.clear();
        return saved;
    }
    async update(id, dto) {
        await this.findById(id);
        const updateData = {};
        if (dto.name !== undefined) {
            updateData.name = dto.name;
            updateData.slug = this.generateSlug(dto.name);
        }
        if (dto.parentId !== undefined) {
            if (dto.parentId) {
                updateData.parent = { connect: { id: dto.parentId } };
            }
            else {
                updateData.parent = { disconnect: true };
            }
        }
        if (dto.icon !== undefined)
            updateData.icon = dto.icon;
        if (dto.description !== undefined)
            updateData.description = dto.description ?? null;
        if (dto.displayOrder !== undefined)
            updateData.displayOrder = dto.displayOrder;
        if (dto.status !== undefined)
            updateData.status = dto.status;
        await this.prisma.category.update({
            where: { id },
            data: updateData,
        });
        void this.cacheService.clear();
        return this.findById(id);
    }
    async updateStatus(id, dto) {
        await this.findById(id);
        await this.prisma.category.update({
            where: { id },
            data: { status: dto.status },
        });
        void this.cacheService.clear();
        return this.findById(id);
    }
    async softDelete(id) {
        const category = await this.findById(id);
        const productCount = await this.prisma.product.count({
            where: { categoryId: id },
        });
        if (productCount > 0) {
            throw new common_1.BadRequestException(`Cannot delete category "${category.name}" because it contains ${productCount} product(s). Please move or delete the products first.`);
        }
        const defaultIconPath = this.configService.get('DEFAULT_CATEGORY_ICON');
        if (category.icon &&
            (!defaultIconPath ||
                !category.icon.includes(defaultIconPath.split('/').pop() || ''))) {
        }
        await this.prisma.category.delete({ where: { id } });
        void this.cacheService.clear();
        return { message: 'Category deleted successfully' };
    }
    async count() {
        const active = await this.prisma.category.count({
            where: { status: 'active' },
        });
        const inactive = await this.prisma.category.count({
            where: { status: 'inactive' },
        });
        return { active, inactive, total: active + inactive };
    }
    async getChildren(parentId, status) {
        await this.findById(parentId);
        const fromCategories = await this.getChildrenFromCategoriesTable(parentId, status);
        const fromProducts = await this.getChildrenFromProductsTable(parentId, status);
        const byName = new Map();
        fromCategories.forEach((c) => byName.set(c.name.toLowerCase().trim(), c));
        fromProducts.forEach((p) => {
            const key = p.name.toLowerCase().trim();
            if (!byName.has(key))
                byName.set(key, p);
        });
        return Array.from(byName.values()).sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    }
    async getChildrenFromCategoriesTable(parentId, status) {
        const where = { parentId: parentId.trim() };
        if (status) {
            where.status = status;
        }
        const children = await this.prisma.category.findMany({
            where,
            orderBy: [{ displayOrder: 'asc' }, { id: 'asc' }],
        });
        return children.map((c) => this.toListDto(this.mapCategory(c)));
    }
    async getChildrenFromProductsTable(parentId, status) {
        const map = await this.getProductSubcategoriesByCategoryIds([parentId], status);
        return map.get(parentId.trim()) || [];
    }
    async getProductSubcategoriesByCategoryIds(categoryIds, status) {
        if (!categoryIds.length)
            return new Map();
        const where = {
            categoryId: { in: categoryIds },
            subCategory: { not: null, notIn: [''] },
            deletedAt: null,
        };
        if (status) {
            where.status = status;
        }
        const products = await this.prisma.product.findMany({
            where,
            select: { categoryId: true, subCategory: true },
            distinct: ['categoryId', 'subCategory'],
        });
        const byCategory = new Map();
        for (const product of products) {
            const cid = (product.categoryId ?? '').trim();
            const name = (product.subCategory ?? '').trim();
            if (!cid || !name)
                continue;
            const slug = this.generateSlug(name);
            const dto = { id: slug, name, slug };
            const list = byCategory.get(cid) || [];
            if (!list.some((x) => (x.name || '').toLowerCase() === name.toLowerCase())) {
                list.push(dto);
                byCategory.set(cid, list);
            }
        }
        return byCategory;
    }
    async getAllWithChildren() {
        const categories = await this.prisma.category.findMany({
            where: { parentId: null },
            include: { children: true },
            orderBy: [{ displayOrder: 'asc' }, { id: 'asc' }],
        });
        return categories.map((cat) => this.toListDto(this.mapCategory(cat)));
    }
    async updateChildrenStatus(parentId, status) {
        await this.findById(parentId);
        await this.prisma.category.updateMany({
            where: { parentId },
            data: { status },
        });
        void this.cacheService.clear();
        return this.getChildren(parentId);
    }
    generateSlug(name) {
        return name
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    }
};
exports.CategoriesService = CategoriesService;
exports.CategoriesService = CategoriesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        redis_cache_service_1.RedisCacheService])
], CategoriesService);
//# sourceMappingURL=categories.service.js.map