export declare class CategoriesModule {
}
