import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { UpdateStatusDto } from './dto/update-status.dto';
import { CategoryListResponseDto } from './dto/category-list-response.dto';
import { RedisCacheService } from '../../common/services/redis-cache.service';
import { Category } from '@prisma/client';
export type CategoryWithChildren = Category & {
    children?: CategoryWithChildren[];
};
export declare class CategoriesService {
    private readonly prisma;
    private readonly configService;
    private readonly cacheService;
    constructor(prisma: PrismaService, configService: ConfigService, cacheService: RedisCacheService);
    private get defaultIcon();
    private mapCategory;
    private toListDto;
    findAll(status?: string, limit?: number): Promise<CategoryListResponseDto[]>;
    search(query: string): Promise<CategoryListResponseDto[]>;
    findById(id: string): Promise<CategoryListResponseDto>;
    findBySlug(slug: string): Promise<CategoryListResponseDto>;
    create(dto: CreateCategoryDto): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        name: string;
        slug: string;
        icon: string | null;
        description: string | null;
        displayOrder: number;
        parentId: string | null;
    }>;
    update(id: string, dto: UpdateCategoryDto): Promise<CategoryListResponseDto>;
    updateStatus(id: string, dto: UpdateStatusDto): Promise<CategoryListResponseDto>;
    softDelete(id: string): Promise<{
        message: string;
    }>;
    count(): Promise<{
        active: number;
        inactive: number;
        total: number;
    }>;
    getChildren(parentId: string, status?: string): Promise<CategoryListResponseDto[]>;
    private getChildrenFromCategoriesTable;
    private getChildrenFromProductsTable;
    private getProductSubcategoriesByCategoryIds;
    getAllWithChildren(): Promise<CategoryListResponseDto[]>;
    updateChildrenStatus(parentId: string, status: string): Promise<CategoryListResponseDto[]>;
    private generateSlug;
}
