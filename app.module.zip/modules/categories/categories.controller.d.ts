import { CategoriesService } from './categories.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { UpdateStatusDto } from './dto/update-status.dto';
import { UpdateSubcategoryStatusDto } from './dto/update-subcategory-status.dto';
export declare class CategoriesController {
    private readonly categoriesService;
    constructor(categoriesService: CategoriesService);
    findAll(status?: string, limit?: string): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto[]>;
    search(search: string): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto[]>;
    getAllWithChildren(): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto[]>;
    getChildren(id: string, status?: string): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto[]>;
    findBySlug(slug: string): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto>;
    count(): Promise<{
        active: number;
        inactive: number;
        total: number;
    }>;
    findById(id: string): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto>;
    create(dto: CreateCategoryDto): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        name: string;
        slug: string;
        icon: string | null;
        description: string | null;
        displayOrder: number;
        parentId: string | null;
    }>;
    update(id: string, dto: UpdateCategoryDto): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto>;
    updateStatus(id: string, dto: UpdateStatusDto): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto>;
    updateChildrenStatus(dto: UpdateSubcategoryStatusDto): Promise<import("./dto/category-list-response.dto").CategoryListResponseDto[]>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
