"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let RolesService = class RolesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findAll() {
        const roles = await this.prisma.role.findMany({
            orderBy: { id: 'asc' },
        });
        if (roles.length === 0)
            return [];
        const roleIds = roles.map((r) => r.id);
        const [memberCounts, rps] = await Promise.all([
            this.prisma.admin.groupBy({
                by: ['roleId'],
                _count: { _all: true },
                where: { roleId: { in: roleIds } },
            }),
            this.prisma.rolePrivilege.findMany({
                where: { roleId: { in: roleIds }, isActive: true },
                include: { privilege: true },
            }),
        ]);
        const membersByRole = new Map(memberCounts.map((r) => [r.roleId ?? '', r._count._all]));
        const privilegesByRole = new Map();
        for (const rp of rps) {
            if (!rp.privilege?.name)
                continue;
            const arr = privilegesByRole.get(rp.roleId) ?? [];
            arr.push(rp.privilege.name);
            privilegesByRole.set(rp.roleId, arr);
        }
        return roles.map((role) => ({
            id: role.id,
            name: role.name,
            description: role.description ?? undefined,
            isSystem: role.isSystem,
            members: membersByRole.get(role.id) ?? 0,
            privileges: privilegesByRole.get(role.id) ?? [],
            createdAt: role.createdAt,
            updatedAt: role.updatedAt,
        }));
    }
    async findById(id) {
        const role = await this.prisma.role.findUnique({
            where: { id },
        });
        if (!role)
            throw new common_1.NotFoundException('Role not found');
        return {
            id: role.id,
            name: role.name,
            description: role.description ?? undefined,
            isSystem: role.isSystem,
            createdAt: role.createdAt,
            updatedAt: role.updatedAt,
        };
    }
    async findByName(name) {
        return this.prisma.role.findUnique({ where: { name } });
    }
    async create(dto) {
        const existing = await this.prisma.role.findUnique({
            where: { name: dto.name },
        });
        if (existing)
            throw new common_1.BadRequestException('Role name already exists');
        const saved = await this.prisma.role.create({ data: dto });
        return this.findById(saved.id);
    }
    async update(id, dto) {
        const role = await this.prisma.role.findUnique({ where: { id } });
        if (!role)
            throw new common_1.NotFoundException('Role not found');
        const updateData = { ...dto };
        if (role.isSystem)
            delete updateData.name;
        await this.prisma.role.update({
            where: { id },
            data: updateData,
        });
        return this.findById(id);
    }
    async delete(id) {
        const role = await this.findById(id);
        if (role.isSystem) {
            throw new common_1.BadRequestException(`Cannot delete system role "${role.name}"`);
        }
        await this.prisma.role.delete({ where: { id } });
        return { message: 'Role deleted' };
    }
    async getAllPrivileges() {
        const privileges = await this.prisma.privilege.findMany({
            orderBy: [{ module: 'asc' }, { name: 'asc' }],
        });
        return privileges.map((p) => ({
            id: p.id,
            name: p.name,
            module: p.module,
            description: p.description ?? undefined,
        }));
    }
    async getPrivilegesByModule(module) {
        return this.prisma.privilege.findMany({
            where: { module },
            orderBy: { name: 'asc' },
        });
    }
    async getPrivilegesForRole(roleId) {
        await this.findById(roleId);
        return this.prisma.rolePrivilege.findMany({
            where: { roleId },
            include: { privilege: true },
            orderBy: { privilegeId: 'asc' },
        });
    }
    async updatePrivilegeForRole(roleId, dto) {
        await this.findById(roleId);
        const rp = await this.prisma.rolePrivilege.findFirst({
            where: { roleId, privilegeId: dto.privilegeId },
        });
        if (rp) {
            return this.prisma.rolePrivilege.update({
                where: { id: rp.id },
                data: { isActive: dto.isActive },
            });
        }
        return this.prisma.rolePrivilege.create({
            data: {
                roleId,
                privilegeId: dto.privilegeId,
                isActive: dto.isActive,
            },
        });
    }
    async bulkSetPrivileges(roleId, privilegeIds) {
        await this.findById(roleId);
        await this.prisma.rolePrivilege.deleteMany({ where: { roleId } });
        if (privilegeIds.length === 0)
            return [];
        await this.prisma.rolePrivilege.createMany({
            data: privilegeIds.map((privilegeId) => ({
                roleId,
                privilegeId,
                isActive: true,
            })),
        });
        return this.getPrivilegesForRole(roleId);
    }
};
exports.RolesService = RolesService;
exports.RolesService = RolesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RolesService);
//# sourceMappingURL=roles.service.js.map