"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const roles_service_1 = require("./roles.service");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const create_role_dto_1 = require("./dto/create-role.dto");
const update_role_dto_1 = require("./dto/update-role.dto");
const update_privilege_dto_1 = require("./dto/update-privilege.dto");
let RolesController = class RolesController {
    rolesService;
    constructor(rolesService) {
        this.rolesService = rolesService;
    }
    findAll() {
        return this.rolesService.findAll();
    }
    getAllPrivileges() {
        return this.rolesService.getAllPrivileges();
    }
    getPrivilegesForRole(roleId) {
        return this.rolesService.getPrivilegesForRole(roleId);
    }
    updatePrivilegeForRole(roleId, dto) {
        return this.rolesService.updatePrivilegeForRole(roleId, dto);
    }
    bulkSetPrivileges(roleId, body) {
        return this.rolesService.bulkSetPrivileges(roleId, body.privilegeIds);
    }
    findOne(id) {
        return this.rolesService.findById(id);
    }
    create(dto) {
        return this.rolesService.create(dto);
    }
    update(id, dto) {
        return this.rolesService.update(id, dto);
    }
    delete(id) {
        return this.rolesService.delete(id);
    }
};
exports.RolesController = RolesController;
__decorate([
    (0, common_1.Get)('all'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all roles' }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/role-response.dto").RoleResponseDto] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('privilege/all'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all privileges' }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/privilege-response.dto").PrivilegeResponseDto] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "getAllPrivileges", null);
__decorate([
    (0, common_1.Get)('privilege/:roleId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get privileges for a role' }),
    openapi.ApiResponse({ status: 200, type: [Object] }),
    __param(0, (0, common_1.Param)('roleId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "getPrivilegesForRole", null);
__decorate([
    (0, common_1.Put)('privilege/:roleId'),
    (0, swagger_1.ApiOperation)({ summary: 'Update privilege for a role' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('roleId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_privilege_dto_1.UpdatePrivilegeDto]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "updatePrivilegeForRole", null);
__decorate([
    (0, common_1.Put)('privilege/bulk/:roleId'),
    (0, swagger_1.ApiOperation)({ summary: 'Bulk-set privileges for a role' }),
    openapi.ApiResponse({ status: 200, type: [Object] }),
    __param(0, (0, common_1.Param)('roleId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "bulkSetPrivileges", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get role by ID' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/role-response.dto").RoleResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)('add'),
    (0, swagger_1.ApiOperation)({ summary: 'Create role' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/role-response.dto").RoleResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_role_dto_1.CreateRoleDto]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('update/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update role' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/role-response.dto").RoleResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_role_dto_1.UpdateRoleDto]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)('delete/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete role' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], RolesController.prototype, "delete", null);
exports.RolesController = RolesController = __decorate([
    (0, swagger_1.ApiTags)('Roles'),
    (0, common_1.Controller)('roles'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    __metadata("design:paramtypes", [roles_service_1.RolesService])
], RolesController);
//# sourceMappingURL=roles.controller.js.map