import { RolesService } from './roles.service';
import { CreateRoleDto } from './dto/create-role.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
import { UpdatePrivilegeDto } from './dto/update-privilege.dto';
export declare class RolesController {
    private readonly rolesService;
    constructor(rolesService: RolesService);
    findAll(): Promise<import("./dto/role-response.dto").RoleResponseDto[]>;
    getAllPrivileges(): Promise<import("./dto/privilege-response.dto").PrivilegeResponseDto[]>;
    getPrivilegesForRole(roleId: string): Promise<({
        privilege: {
            id: string;
            name: string;
            description: string | null;
            module: string;
        };
    } & {
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    })[]>;
    updatePrivilegeForRole(roleId: string, dto: UpdatePrivilegeDto): Promise<{
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    }>;
    bulkSetPrivileges(roleId: string, body: {
        privilegeIds: string[];
    }): Promise<({
        privilege: {
            id: string;
            name: string;
            description: string | null;
            module: string;
        };
    } & {
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    })[]>;
    findOne(id: string): Promise<import("./dto/role-response.dto").RoleResponseDto>;
    create(dto: CreateRoleDto): Promise<import("./dto/role-response.dto").RoleResponseDto>;
    update(id: string, dto: UpdateRoleDto): Promise<import("./dto/role-response.dto").RoleResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
