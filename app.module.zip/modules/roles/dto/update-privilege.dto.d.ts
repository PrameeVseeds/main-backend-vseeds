export declare class UpdatePrivilegeDto {
    privilegeId: string;
    isActive: boolean;
}
