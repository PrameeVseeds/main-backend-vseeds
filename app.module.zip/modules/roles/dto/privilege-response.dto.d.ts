export declare class PrivilegeResponseDto {
    id: string;
    name: string;
    module: string;
    description?: string;
}
