export declare class RolePrivilegeResponseDto {
    id: string;
    roleId: string;
    privilegeId: string;
    isActive: boolean;
    privilegeName?: string;
    privilegeModule?: string;
}
