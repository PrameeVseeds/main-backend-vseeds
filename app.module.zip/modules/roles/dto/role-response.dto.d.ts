export declare class RoleResponseDto {
    id: string;
    name: string;
    description?: string;
    isSystem: boolean;
    members?: number;
    privileges?: string[];
    createdAt?: Date;
    updatedAt?: Date;
}
