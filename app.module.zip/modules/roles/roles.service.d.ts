import { PrismaService } from '../../prisma/prisma.service';
import { CreateRoleDto } from './dto/create-role.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
import { UpdatePrivilegeDto } from './dto/update-privilege.dto';
import { RoleResponseDto } from './dto/role-response.dto';
import { PrivilegeResponseDto } from './dto/privilege-response.dto';
export declare class RolesService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findAll(): Promise<RoleResponseDto[]>;
    findById(id: string): Promise<RoleResponseDto>;
    findByName(name: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        description: string | null;
        isSystem: boolean;
    } | null>;
    create(dto: CreateRoleDto): Promise<RoleResponseDto>;
    update(id: string, dto: UpdateRoleDto): Promise<RoleResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    getAllPrivileges(): Promise<PrivilegeResponseDto[]>;
    getPrivilegesByModule(module: string): Promise<{
        id: string;
        name: string;
        description: string | null;
        module: string;
    }[]>;
    getPrivilegesForRole(roleId: string): Promise<({
        privilege: {
            id: string;
            name: string;
            description: string | null;
            module: string;
        };
    } & {
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    })[]>;
    updatePrivilegeForRole(roleId: string, dto: UpdatePrivilegeDto): Promise<{
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    }>;
    bulkSetPrivileges(roleId: string, privilegeIds: string[]): Promise<({
        privilege: {
            id: string;
            name: string;
            description: string | null;
            module: string;
        };
    } & {
        id: string;
        roleId: string;
        isActive: boolean;
        privilegeId: string;
    })[]>;
}
