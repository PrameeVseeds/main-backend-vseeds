import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { CreateQuoteDto } from './dto/create-quote.dto';
import { UpdateQuoteStatusDto } from './dto/update-quote-status.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { EmailQueueService } from '../email/email-queue.service';
import { Prisma } from '@prisma/client';
export declare class QuotesService {
    private readonly prisma;
    private readonly emailQueueService;
    private readonly encryptionService;
    constructor(prisma: PrismaService, emailQueueService: EmailQueueService, encryptionService: EncryptionService);
    create(dto: CreateQuoteDto, userId?: string): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: Prisma.Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: Prisma.JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    findByQuoteNumber(quoteNumber: string, user?: {
        email: string;
        role: string;
        type: string;
    }): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: Prisma.Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: Prisma.JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    findById(id: string, user?: {
        email: string;
        role: string;
        type: string;
    }): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: Prisma.Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: Prisma.JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    findByUserEmail(email: string, pagination?: PaginationDto): Promise<{
        quotes: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        quotes: {
            customerEmail: string;
            id: string;
            createdAt: Date;
            status: string;
            totalPrice: Prisma.Decimal | null;
            customerName: string;
            customerPhone: string | null;
            quoteNumber: string;
            serviceType: string;
            customerCompany: string | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    updateStatus(id: string, dto: UpdateQuoteStatusDto): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: Prisma.Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: Prisma.JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    private generateQuoteNumber;
}
