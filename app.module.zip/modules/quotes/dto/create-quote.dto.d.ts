export declare class CreateQuoteDto {
    serviceType: string;
    details: any;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    customerCompany?: string;
}
