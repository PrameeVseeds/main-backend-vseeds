export declare class UpdateQuoteStatusDto {
    status: string;
    totalPrice?: number;
    serviceLevel?: string;
    estimatedBuildTime?: string;
    adminNotes?: string;
}
