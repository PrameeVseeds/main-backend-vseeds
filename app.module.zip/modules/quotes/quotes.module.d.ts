export declare class QuotesModule {
}
