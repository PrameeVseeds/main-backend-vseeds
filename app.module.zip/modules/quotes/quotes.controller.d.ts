import { QuotesService } from './quotes.service';
import { CreateQuoteDto } from './dto/create-quote.dto';
import { UpdateQuoteStatusDto } from './dto/update-quote-status.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class QuotesController {
    private readonly quotesService;
    constructor(quotesService: QuotesService);
    create(dto: CreateQuoteDto): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: import("@prisma/client/runtime/library").Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: import("@prisma/client/runtime/library").JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    findByUserEmail(email: string, query: {
        page?: number;
        limit?: number;
    }, user: {
        email: string;
        role: string;
        type: string;
    }): Promise<{
        quotes: any[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string, user: {
        email: string;
        role: string;
        type: string;
    }): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: import("@prisma/client/runtime/library").Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: import("@prisma/client/runtime/library").JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        quotes: {
            customerEmail: string;
            id: string;
            createdAt: Date;
            status: string;
            totalPrice: import("@prisma/client/runtime/library").Decimal | null;
            customerName: string;
            customerPhone: string | null;
            quoteNumber: string;
            serviceType: string;
            customerCompany: string | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    updateStatus(id: string, dto: UpdateQuoteStatusDto): Promise<{
        id: string;
        userId: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        adminNotes: string | null;
        totalPrice: import("@prisma/client/runtime/library").Decimal | null;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        quoteNumber: string;
        serviceType: string;
        customerCompany: string | null;
        details: import("@prisma/client/runtime/library").JsonValue;
        serviceLevel: string | null;
        estimatedBuildTime: string | null;
    }>;
}
