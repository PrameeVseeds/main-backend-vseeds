"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuotesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const email_queue_service_1 = require("../email/email-queue.service");
const TERMINAL_QUOTE_STATUSES = ['completed', 'rejected', 'expired'];
let QuotesService = class QuotesService {
    prisma;
    emailQueueService;
    encryptionService;
    constructor(prisma, emailQueueService, encryptionService) {
        this.prisma = prisma;
        this.emailQueueService = emailQueueService;
        this.encryptionService = encryptionService;
    }
    async create(dto, userId) {
        const quoteNumber = await this.generateQuoteNumber();
        return this.prisma.quote.create({
            data: {
                ...dto,
                details: (dto.details ?? {}),
                quoteNumber,
                userId: userId || null,
                status: 'pending',
            },
        });
    }
    async findByQuoteNumber(quoteNumber, user) {
        const quote = await this.prisma.quote.findUnique({
            where: { quoteNumber },
        });
        if (!quote)
            throw new common_1.NotFoundException('Quote not found');
        if (user && user.type !== 'admin' && quote.customerEmail !== user.email) {
            throw new common_1.ForbiddenException('You can only view your own quotes');
        }
        return quote;
    }
    async findById(id, user) {
        const quote = await this.prisma.quote.findUnique({ where: { id } });
        if (!quote)
            throw new common_1.NotFoundException('Quote not found');
        if (user && user.type !== 'admin' && quote.customerEmail !== user.email) {
            throw new common_1.ForbiddenException('You can only view your own quotes');
        }
        return quote;
    }
    async findByUserEmail(email, pagination) {
        const page = pagination?.page ?? 1;
        const limit = Math.min(pagination?.limit ?? 50, 100);
        const [quotes, total] = await Promise.all([
            this.prisma.quote.findMany({
                where: { customerEmail: email },
                select: {
                    id: true,
                    quoteNumber: true,
                    customerName: true,
                    customerEmail: true,
                    customerPhone: true,
                    customerCompany: true,
                    serviceType: true,
                    totalPrice: true,
                    status: true,
                    createdAt: true,
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.quote.count({
                where: { customerEmail: email },
            }),
        ]);
        const decryptedQuotes = quotes.map(quote => ({
            ...quote,
            customerEmail: this.encryptionService.decrypt(quote.customerEmail),
        }));
        return { quotes: decryptedQuotes, total, totalPages: Math.ceil(total / limit), page };
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const [quotes, total] = await Promise.all([
            this.prisma.quote.findMany({
                select: {
                    id: true,
                    quoteNumber: true,
                    customerName: true,
                    customerEmail: true,
                    customerPhone: true,
                    customerCompany: true,
                    serviceType: true,
                    totalPrice: true,
                    status: true,
                    createdAt: true,
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.quote.count(),
        ]);
        const decryptedQuotes = quotes.map(quote => ({
            ...quote,
            customerEmail: this.encryptionService.decrypt(quote.customerEmail),
        }));
        return { quotes: decryptedQuotes, total, totalPages: Math.ceil(total / limit), page };
    }
    async updateStatus(id, dto) {
        const quote = await this.findById(id);
        if (TERMINAL_QUOTE_STATUSES.includes(quote.status)) {
            throw new common_1.BadRequestException(`Cannot change status of a quote that is already ${quote.status}`);
        }
        const update = { status: dto.status };
        if (dto.totalPrice !== undefined)
            update.totalPrice = dto.totalPrice;
        if (dto.serviceLevel !== undefined)
            update.serviceLevel = dto.serviceLevel;
        if (dto.estimatedBuildTime !== undefined)
            update.estimatedBuildTime = dto.estimatedBuildTime;
        if (dto.adminNotes !== undefined)
            update.adminNotes = dto.adminNotes;
        await this.prisma.quote.update({
            where: { id },
            data: update,
        });
        const updated = await this.findById(id);
        const statusLabel = dto.status.charAt(0).toUpperCase() + dto.status.slice(1);
        await this.emailQueueService.enqueue('quote-status-update', quote.customerEmail, {
            username: quote.customerName || 'Customer',
            quoteNumber: quote.quoteNumber,
            status: statusLabel,
            adminNotes: dto.adminNotes || '',
        });
        return updated;
    }
    async generateQuoteNumber() {
        for (let attempt = 0; attempt < 5; attempt++) {
            const now = new Date();
            const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
            const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const count = await this.prisma.quote.count({
                where: {
                    createdAt: {
                        gte: todayStart,
                    },
                },
            });
            const candidate = `QT-${dateStr}-${String(count + 1 + attempt).padStart(4, '0')}`;
            const exists = await this.prisma.quote.findUnique({
                where: { quoteNumber: candidate },
            });
            if (!exists)
                return candidate;
        }
        return `QT-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    }
};
exports.QuotesService = QuotesService;
exports.QuotesService = QuotesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        email_queue_service_1.EmailQueueService,
        encryption_service_1.EncryptionService])
], QuotesService);
//# sourceMappingURL=quotes.service.js.map