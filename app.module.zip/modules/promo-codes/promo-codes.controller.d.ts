import { PromoCodesService } from './promo-codes.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreatePromoCodeDto } from './dto/create-promo-code.dto';
import { UpdatePromoCodeDto } from './dto/update-promo-code.dto';
import { ValidatePromoCodeDto } from './dto/validate-promo-code.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class PromoCodesController {
    private readonly promoCodesService;
    constructor(promoCodesService: PromoCodesService);
    validate(user: JwtPayload, dto: ValidatePromoCodeDto): Promise<{
        valid: boolean;
        promoCodeId: string;
        code: string;
        discountType: import(".prisma/client").$Enums.DiscountType;
        discountValue: number;
        discountAmount: number;
        applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
        description: string | null;
    }>;
    create(dto: CreatePromoCodeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        isActive: boolean;
        code: string;
        codeLookup: string;
        discountType: import(".prisma/client").$Enums.DiscountType;
        discountValue: import("@prisma/client/runtime/library").Decimal;
        applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
        minimumOrderAmount: import("@prisma/client/runtime/library").Decimal;
        maximumDiscountAmount: import("@prisma/client/runtime/library").Decimal | null;
        usageLimit: number;
        usedCount: number;
        perUserLimit: number;
        startDate: Date | null;
        expiryDate: Date | null;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        promoCodes: {
            code: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            description: string | null;
            isActive: boolean;
            codeLookup: string;
            discountType: import(".prisma/client").$Enums.DiscountType;
            discountValue: import("@prisma/client/runtime/library").Decimal;
            applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
            minimumOrderAmount: import("@prisma/client/runtime/library").Decimal;
            maximumDiscountAmount: import("@prisma/client/runtime/library").Decimal | null;
            usageLimit: number;
            usedCount: number;
            perUserLimit: number;
            startDate: Date | null;
            expiryDate: Date | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        total: number;
        active: number;
        inactive: number;
        expired: number;
    }>;
    findById(id: string): Promise<import("./dto/promo-code-response.dto").PromoCodeResponseDto>;
    update(id: string, dto: UpdatePromoCodeDto): Promise<import("./dto/promo-code-response.dto").PromoCodeResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
