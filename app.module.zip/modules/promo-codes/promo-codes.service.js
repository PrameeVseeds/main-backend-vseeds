"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromoCodesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const client_1 = require("@prisma/client");
const lookup_hash_util_1 = require("../../common/utils/lookup-hash.util");
let PromoCodesService = class PromoCodesService {
    prisma;
    encryptionService;
    constructor(prisma, encryptionService) {
        this.prisma = prisma;
        this.encryptionService = encryptionService;
    }
    async create(dto) {
        const existing = await this.prisma.promoCode.findUnique({
            where: { codeLookup: (0, lookup_hash_util_1.createLookupHash)(dto.code, 'promo_code') },
        });
        if (existing) {
            throw new common_1.BadRequestException(`Promo code "${dto.code}" already exists`);
        }
        return this.prisma.promoCode.create({
            data: {
                code: dto.code.toUpperCase(),
                codeLookup: (0, lookup_hash_util_1.createLookupHash)(dto.code, 'promo_code'),
                description: dto.description,
                discountType: dto.discountType,
                discountValue: new client_1.Prisma.Decimal(dto.discountValue),
                applicableSite: (dto.applicableSite || 'both'),
                minimumOrderAmount: dto.minimumOrderAmount != null
                    ? new client_1.Prisma.Decimal(dto.minimumOrderAmount)
                    : undefined,
                maximumDiscountAmount: dto.maximumDiscountAmount != null
                    ? new client_1.Prisma.Decimal(dto.maximumDiscountAmount)
                    : undefined,
                usageLimit: dto.usageLimit,
                perUserLimit: dto.perUserLimit,
                startDate: dto.startDate ? new Date(dto.startDate) : undefined,
                expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
                isActive: dto.isActive,
            },
        });
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const skip = (page - 1) * limit;
        const [promoCodes, total] = await this.prisma.$transaction([
            this.prisma.promoCode.findMany({
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.promoCode.count(),
        ]);
        const decryptedPromoCodes = promoCodes.map(promo => ({
            ...promo,
            code: this.encryptionService.decrypt(promo.code),
        }));
        return { promoCodes: decryptedPromoCodes, total, totalPages: Math.ceil(total / limit), page };
    }
    async findById(id) {
        const promo = await this.prisma.promoCode.findUnique({ where: { id } });
        if (!promo)
            throw new common_1.NotFoundException('Promo code not found');
        return this.toPromoCodeResponseDto(promo);
    }
    toPromoCodeResponseDto(p) {
        return {
            id: p.id,
            code: this.encryptionService.decrypt(p.code),
            description: p.description ?? undefined,
            discountType: p.discountType,
            discountValue: Number(p.discountValue),
            applicableSite: p.applicableSite,
            minimumOrderAmount: Number(p.minimumOrderAmount),
            maximumDiscountAmount: p.maximumDiscountAmount != null
                ? Number(p.maximumDiscountAmount)
                : undefined,
            usageLimit: p.usageLimit,
            usedCount: p.usedCount,
            perUserLimit: p.perUserLimit,
            startDate: p.startDate?.toISOString(),
            expiryDate: p.expiryDate?.toISOString(),
            isActive: p.isActive,
            createdAt: p.createdAt.toISOString(),
            updatedAt: p.updatedAt.toISOString(),
        };
    }
    async update(id, dto) {
        await this.findById(id);
        const data = {};
        if (dto.code !== undefined)
            data.code = dto.code.toUpperCase();
        if (dto.description !== undefined)
            data.description = dto.description;
        if (dto.discountType !== undefined) {
            data.discountType = dto.discountType;
        }
        if (dto.discountValue !== undefined) {
            data.discountValue = new client_1.Prisma.Decimal(dto.discountValue);
        }
        if (dto.applicableSite !== undefined) {
            data.applicableSite = dto.applicableSite;
        }
        if (dto.minimumOrderAmount !== undefined) {
            data.minimumOrderAmount = new client_1.Prisma.Decimal(dto.minimumOrderAmount);
        }
        if (dto.maximumDiscountAmount !== undefined) {
            data.maximumDiscountAmount =
                dto.maximumDiscountAmount != null
                    ? new client_1.Prisma.Decimal(dto.maximumDiscountAmount)
                    : null;
        }
        if (dto.usageLimit !== undefined)
            data.usageLimit = dto.usageLimit;
        if (dto.perUserLimit !== undefined)
            data.perUserLimit = dto.perUserLimit;
        if (dto.startDate !== undefined) {
            data.startDate = dto.startDate ? new Date(dto.startDate) : null;
        }
        if (dto.expiryDate !== undefined) {
            data.expiryDate = dto.expiryDate ? new Date(dto.expiryDate) : null;
        }
        if (dto.isActive !== undefined)
            data.isActive = dto.isActive;
        await this.prisma.promoCode.update({
            where: { id },
            data,
        });
        return this.findById(id);
    }
    async delete(id) {
        await this.findById(id);
        await this.prisma.promoCode.delete({
            where: { id },
        });
        return { message: 'Promo code deleted' };
    }
    async validate(dto, userId) {
        if (userId) {
        }
        const promo = await this.prisma.promoCode.findUnique({
            where: { codeLookup: (0, lookup_hash_util_1.createLookupHash)(dto.code, 'promo_code') },
        });
        if (!promo) {
            throw new common_1.BadRequestException('Invalid promo code');
        }
        if (!promo.isActive) {
            throw new common_1.BadRequestException('This promo code is no longer active');
        }
        const now = new Date();
        if (promo.startDate && now < new Date(promo.startDate)) {
            throw new common_1.BadRequestException('This promo code is not yet valid');
        }
        if (promo.expiryDate && now > new Date(promo.expiryDate)) {
            throw new common_1.BadRequestException('This promo code has expired');
        }
        if (promo.usageLimit > 0 && promo.usedCount >= promo.usageLimit) {
            throw new common_1.BadRequestException('This promo code has reached its usage limit');
        }
        const site = dto.site || 'electronics';
        if (promo.applicableSite !== 'both' && promo.applicableSite !== site) {
            const siteLabel = promo.applicableSite === 'electronics'
                ? 'Electronics store'
                : 'Embedded / PCB store';
            throw new common_1.BadRequestException(`This promo code is only valid for the ${siteLabel}`);
        }
        if (+promo.minimumOrderAmount > 0 &&
            dto.subtotal < +promo.minimumOrderAmount) {
            throw new common_1.BadRequestException(`Minimum order amount of Rs. ${(+promo.minimumOrderAmount).toFixed(2)} required`);
        }
        let discountAmount;
        if (promo.discountType === 'percentage') {
            discountAmount = +(dto.subtotal * (+promo.discountValue / 100)).toFixed(2);
            if (promo.maximumDiscountAmount &&
                discountAmount > +promo.maximumDiscountAmount) {
                discountAmount = +promo.maximumDiscountAmount;
            }
        }
        else {
            discountAmount = +promo.discountValue;
        }
        if (discountAmount > dto.subtotal) {
            discountAmount = dto.subtotal;
        }
        return {
            valid: true,
            promoCodeId: promo.id,
            code: promo.code,
            discountType: promo.discountType,
            discountValue: +promo.discountValue,
            discountAmount,
            applicableSite: promo.applicableSite,
            description: promo.description,
        };
    }
    async incrementUsage(promoCodeId) {
        await this.prisma.promoCode.update({
            where: { id: promoCodeId },
            data: {
                usedCount: { increment: 1 },
            },
        });
    }
    async count() {
        const total = await this.prisma.promoCode.count();
        const active = await this.prisma.promoCode.count({
            where: { isActive: true },
        });
        const expired = await this.prisma.promoCode.count({
            where: {
                expiryDate: {
                    not: null,
                    lt: new Date(),
                },
            },
        });
        return { total, active, inactive: total - active, expired };
    }
};
exports.PromoCodesService = PromoCodesService;
exports.PromoCodesService = PromoCodesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService])
], PromoCodesService);
//# sourceMappingURL=promo-codes.service.js.map