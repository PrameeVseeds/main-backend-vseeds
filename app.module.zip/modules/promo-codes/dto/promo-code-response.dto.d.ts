export declare class PromoCodeResponseDto {
    id: string;
    code: string;
    description?: string;
    discountType: string;
    discountValue: number;
    applicableSite: string;
    minimumOrderAmount: number;
    maximumDiscountAmount?: number;
    usageLimit: number;
    usedCount: number;
    perUserLimit: number;
    startDate?: string;
    expiryDate?: string;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}
