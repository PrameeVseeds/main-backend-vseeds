export declare class CreatePromoCodeDto {
    code: string;
    description?: string;
    discountType: string;
    discountValue: number;
    applicableSite?: string;
    minimumOrderAmount?: number;
    maximumDiscountAmount?: number;
    usageLimit?: number;
    perUserLimit?: number;
    startDate?: string;
    expiryDate?: string;
    isActive?: boolean;
}
