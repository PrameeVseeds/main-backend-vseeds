export declare class ValidatePromoCodeDto {
    code: string;
    subtotal: number;
    site?: string;
}
