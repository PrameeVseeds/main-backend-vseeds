export declare class PromoCodesModule {
}
