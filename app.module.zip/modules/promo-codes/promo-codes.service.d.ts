import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { CreatePromoCodeDto } from './dto/create-promo-code.dto';
import { UpdatePromoCodeDto } from './dto/update-promo-code.dto';
import { ValidatePromoCodeDto } from './dto/validate-promo-code.dto';
import { PromoCodeResponseDto } from './dto/promo-code-response.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { Prisma } from '@prisma/client';
export declare class PromoCodesService {
    private readonly prisma;
    private readonly encryptionService;
    constructor(prisma: PrismaService, encryptionService: EncryptionService);
    create(dto: CreatePromoCodeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        isActive: boolean;
        code: string;
        codeLookup: string;
        discountType: import(".prisma/client").$Enums.DiscountType;
        discountValue: Prisma.Decimal;
        applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
        minimumOrderAmount: Prisma.Decimal;
        maximumDiscountAmount: Prisma.Decimal | null;
        usageLimit: number;
        usedCount: number;
        perUserLimit: number;
        startDate: Date | null;
        expiryDate: Date | null;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        promoCodes: {
            code: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            description: string | null;
            isActive: boolean;
            codeLookup: string;
            discountType: import(".prisma/client").$Enums.DiscountType;
            discountValue: Prisma.Decimal;
            applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
            minimumOrderAmount: Prisma.Decimal;
            maximumDiscountAmount: Prisma.Decimal | null;
            usageLimit: number;
            usedCount: number;
            perUserLimit: number;
            startDate: Date | null;
            expiryDate: Date | null;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<PromoCodeResponseDto>;
    private toPromoCodeResponseDto;
    update(id: string, dto: UpdatePromoCodeDto): Promise<PromoCodeResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    validate(dto: ValidatePromoCodeDto, userId?: string): Promise<{
        valid: boolean;
        promoCodeId: string;
        code: string;
        discountType: import(".prisma/client").$Enums.DiscountType;
        discountValue: number;
        discountAmount: number;
        applicableSite: import(".prisma/client").$Enums.PromoCodeSite;
        description: string | null;
    }>;
    incrementUsage(promoCodeId: string): Promise<void>;
    count(): Promise<{
        total: number;
        active: number;
        inactive: number;
        expired: number;
    }>;
}
