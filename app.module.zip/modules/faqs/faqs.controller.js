"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FaqsController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const faqs_service_1 = require("./faqs.service");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const create_faq_dto_1 = require("./dto/create-faq.dto");
const update_faq_dto_1 = require("./dto/update-faq.dto");
const reorder_faq_dto_1 = require("./dto/reorder-faq.dto");
let FaqsController = class FaqsController {
    faqsService;
    constructor(faqsService) {
        this.faqsService = faqsService;
    }
    findActive(site) {
        return this.faqsService.findActive(site);
    }
    findByCategory(category, site) {
        return this.faqsService.findByCategory(category, site);
    }
    getCategories(site) {
        return this.faqsService.getCategories(site);
    }
    findAll(query) {
        return this.faqsService.findAll(query);
    }
    findById(id) {
        return this.faqsService.findById(id);
    }
    create(dto) {
        return this.faqsService.create(dto);
    }
    update(id, dto) {
        return this.faqsService.update(id, dto);
    }
    delete(id) {
        return this.faqsService.softDelete(id);
    }
    reorder(dto) {
        return this.faqsService.reorder(dto.ids);
    }
};
exports.FaqsController = FaqsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: 'Get active FAQs (public)' }),
    (0, swagger_1.ApiQuery)({
        name: 'site',
        required: false,
        enum: ['electronics', 'embedded'],
    }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/faq-response.dto").FaqResponseDto] }),
    __param(0, (0, common_1.Query)('site')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "findActive", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('category/:category'),
    (0, swagger_1.ApiOperation)({ summary: 'Get FAQs by category (public)' }),
    (0, swagger_1.ApiQuery)({
        name: 'site',
        required: false,
        enum: ['electronics', 'embedded'],
    }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/faq-response.dto").FaqResponseDto] }),
    __param(0, (0, common_1.Param)('category')),
    __param(1, (0, common_1.Query)('site')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "findByCategory", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('categories'),
    (0, swagger_1.ApiOperation)({ summary: 'Get FAQ categories (public)' }),
    (0, swagger_1.ApiQuery)({
        name: 'site',
        required: false,
        enum: ['electronics', 'embedded'],
    }),
    openapi.ApiResponse({ status: 200, type: [Object] }),
    __param(0, (0, common_1.Query)('site')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "getCategories", null);
__decorate([
    (0, common_1.Get)('all'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all FAQs (admin) with optional pagination' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get FAQ by ID (admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/faq-response.dto").FaqResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "findById", null);
__decorate([
    (0, common_1.Post)('add'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Create FAQ' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/faq-response.dto").FaqResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_faq_dto_1.CreateFaqDto]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('update/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Update FAQ' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/faq-response.dto").FaqResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_faq_dto_1.UpdateFaqDto]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)('delete/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete FAQ (soft)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "delete", null);
__decorate([
    (0, common_1.Put)('reorder'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Reorder FAQs' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [reorder_faq_dto_1.ReorderFaqDto]),
    __metadata("design:returntype", void 0)
], FaqsController.prototype, "reorder", null);
exports.FaqsController = FaqsController = __decorate([
    (0, swagger_1.ApiTags)('FAQs'),
    (0, common_1.Controller)('faqs'),
    __metadata("design:paramtypes", [faqs_service_1.FaqsService])
], FaqsController);
//# sourceMappingURL=faqs.controller.js.map