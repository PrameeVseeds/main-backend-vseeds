import { PrismaService } from '../../prisma/prisma.service';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';
import { FaqResponseDto } from './dto/faq-response.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class FaqsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private siteFilter;
    private toResponseDto;
    findActive(site?: string): Promise<FaqResponseDto[]>;
    findByCategory(category: string, site?: string): Promise<FaqResponseDto[]>;
    getCategories(site?: string): Promise<(string | null)[]>;
    findAll(pagination?: PaginationDto): Promise<{
        faqs: FaqResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<FaqResponseDto>;
    create(dto: CreateFaqDto): Promise<FaqResponseDto>;
    update(id: string, dto: UpdateFaqDto): Promise<FaqResponseDto>;
    softDelete(id: string): Promise<{
        message: string;
    }>;
    reorder(ids: string[]): Promise<{
        message: string;
    }>;
}
