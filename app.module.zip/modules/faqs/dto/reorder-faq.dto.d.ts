export declare class ReorderFaqDto {
    ids: string[];
}
