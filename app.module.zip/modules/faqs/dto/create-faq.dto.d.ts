import { FAQSite } from '@prisma/client';
export declare class CreateFaqDto {
    question: string;
    answer: string;
    category?: string;
    site?: FAQSite;
    displayOrder?: number;
    isActive?: boolean;
}
