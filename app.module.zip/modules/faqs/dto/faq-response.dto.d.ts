export declare class FaqResponseDto {
    id: string;
    question: string;
    answer: string;
    category?: string;
    site: string;
    displayOrder: number;
    isActive: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}
