"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FaqsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let FaqsService = class FaqsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    siteFilter(site) {
        if (site === 'electronics')
            return ['electronics', 'both'];
        if (site === 'embedded')
            return ['embedded', 'both'];
        return ['electronics', 'embedded', 'both'];
    }
    toResponseDto(faq) {
        return {
            id: faq.id,
            question: faq.question,
            answer: faq.answer,
            category: faq.category ?? undefined,
            site: faq.site,
            displayOrder: faq.displayOrder,
            isActive: faq.isActive,
            createdAt: faq.createdAt,
            updatedAt: faq.updatedAt,
        };
    }
    async findActive(site) {
        const faqs = await this.prisma.fAQ.findMany({
            where: {
                isActive: true,
                site: { in: this.siteFilter(site) },
            },
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'asc' }],
        });
        return faqs.map((f) => this.toResponseDto(f));
    }
    async findByCategory(category, site) {
        const faqs = await this.prisma.fAQ.findMany({
            where: {
                category,
                isActive: true,
                site: { in: this.siteFilter(site) },
            },
            orderBy: { displayOrder: 'asc' },
        });
        return faqs.map((f) => this.toResponseDto(f));
    }
    async getCategories(site) {
        const result = await this.prisma.fAQ.findMany({
            where: {
                category: { not: null },
                site: site ? { in: this.siteFilter(site) } : undefined,
            },
            select: {
                category: true,
            },
            distinct: ['category'],
        });
        return result.map((r) => r.category).filter(Boolean);
    }
    async findAll(pagination) {
        const page = pagination?.page ?? 1;
        const limit = Math.min(pagination?.limit ?? 50, 100);
        const skip = (page - 1) * limit;
        const [faqs, total] = await this.prisma.$transaction([
            this.prisma.fAQ.findMany({
                orderBy: [{ displayOrder: 'asc' }, { createdAt: 'asc' }],
                skip,
                take: limit,
            }),
            this.prisma.fAQ.count(),
        ]);
        return {
            faqs: faqs.map((f) => this.toResponseDto(f)),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async findById(id) {
        const faq = await this.prisma.fAQ.findUnique({
            where: { id },
        });
        if (!faq)
            throw new common_1.NotFoundException('FAQ not found');
        return this.toResponseDto(faq);
    }
    async create(dto) {
        const saved = await this.prisma.fAQ.create({
            data: dto,
        });
        return this.toResponseDto(saved);
    }
    async update(id, dto) {
        await this.findById(id);
        const saved = await this.prisma.fAQ.update({
            where: { id },
            data: dto,
        });
        return this.toResponseDto(saved);
    }
    async softDelete(id) {
        await this.findById(id);
        await this.prisma.fAQ.delete({
            where: { id },
        });
        return { message: 'FAQ deleted' };
    }
    async reorder(ids) {
        for (let i = 0; i < ids.length; i++) {
            await this.prisma.fAQ.update({
                where: { id: ids[i] },
                data: { displayOrder: i },
            });
        }
        return { message: 'FAQs reordered' };
    }
};
exports.FaqsService = FaqsService;
exports.FaqsService = FaqsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], FaqsService);
//# sourceMappingURL=faqs.service.js.map