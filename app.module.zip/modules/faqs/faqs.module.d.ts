export declare class FaqsModule {
}
