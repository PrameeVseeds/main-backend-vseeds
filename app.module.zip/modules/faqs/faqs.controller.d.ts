import { FaqsService } from './faqs.service';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';
import { ReorderFaqDto } from './dto/reorder-faq.dto';
export declare class FaqsController {
    private readonly faqsService;
    constructor(faqsService: FaqsService);
    findActive(site?: string): Promise<import("./dto/faq-response.dto").FaqResponseDto[]>;
    findByCategory(category: string, site?: string): Promise<import("./dto/faq-response.dto").FaqResponseDto[]>;
    getCategories(site?: string): Promise<(string | null)[]>;
    findAll(query: {
        page?: number;
        limit?: number;
    }): Promise<{
        faqs: import("./dto/faq-response.dto").FaqResponseDto[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<import("./dto/faq-response.dto").FaqResponseDto>;
    create(dto: CreateFaqDto): Promise<import("./dto/faq-response.dto").FaqResponseDto>;
    update(id: string, dto: UpdateFaqDto): Promise<import("./dto/faq-response.dto").FaqResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    reorder(dto: ReorderFaqDto): Promise<{
        message: string;
    }>;
}
