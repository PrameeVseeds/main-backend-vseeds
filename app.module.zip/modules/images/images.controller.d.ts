import { ImagesService } from './images.service';
import { GalleryQueryDto } from './dto/gallery-query.dto';
import { BulkDeleteDto } from './dto/bulk-delete.dto';
export declare class ImagesController {
    private readonly imagesService;
    constructor(imagesService: ImagesService);
    getThumbnail(productId: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    } | null>;
    getProductImages(productId: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }[]>;
    addThumbnail(productId: string, file: Express.Multer.File, name?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }>;
    updateThumbnail(productId: string, file: Express.Multer.File, name?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    } | null>;
    addImages(productId: string, files: Express.Multer.File[], name?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }[]>;
    uploadGeneric(file: Express.Multer.File, name?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }>;
    deleteMedia(mediaId: string): Promise<{
        message: string;
    }>;
    deleteThumbnail(mediaId: string): Promise<{
        message: string;
    }>;
    deleteProductMedia(mediaId: string): Promise<{
        message: string;
    }>;
    getGallery(query: GalleryQueryDto): Promise<{
        images: {
            id: string;
            filename: string;
            originalName: string;
            url: string;
            mimeType: string;
            fileSize: number;
            altText: string | null;
            createdAt: Date;
            productId: string;
            isThumbnail: boolean;
            displayOrder: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    getCounts(): Promise<{
        typeCounts: Record<string, number>;
        folderCounts: Record<string, number>;
        total: number;
    }>;
    bulkDelete(dto: BulkDeleteDto): Promise<{
        message: string;
    }>;
}
