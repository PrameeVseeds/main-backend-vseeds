import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { Media } from '@prisma/client';
import { GalleryQueryDto } from './dto/gallery-query.dto';
export declare class ImagesService {
    private readonly prisma;
    private readonly configService;
    private readonly logger;
    constructor(prisma: PrismaService, configService: ConfigService);
    private get uploadDir();
    get baseUrl(): string;
    getThumbnail(productId: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    } | null>;
    getProductImages(productId: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }[]>;
    addThumbnail(productId: string, file: Express.Multer.File, customName?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }>;
    updateThumbnail(productId: string, file: Express.Multer.File, customName?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    } | null>;
    addImages(productId: string, files: Express.Multer.File[], customName?: string, folder?: string, startOrder?: number): Promise<Media[]>;
    deleteMedia(mediaId: string): Promise<{
        message: string;
    }>;
    bulkDelete(ids: string[]): Promise<{
        message: string;
    }>;
    uploadGeneric(file: Express.Multer.File, customName?: string, folder?: string): Promise<{
        deletedAt: Date | null;
        id: string;
        createdAt: Date;
        filename: string;
        originalName: string;
        url: string;
        mimeType: string;
        fileSize: number;
        altText: string | null;
    }>;
    getGallery(query: GalleryQueryDto): Promise<{
        images: {
            id: string;
            filename: string;
            originalName: string;
            url: string;
            mimeType: string;
            fileSize: number;
            altText: string | null;
            createdAt: Date;
            productId: string;
            isThumbnail: boolean;
            displayOrder: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    getCounts(): Promise<{
        typeCounts: Record<string, number>;
        folderCounts: Record<string, number>;
        total: number;
    }>;
    private writeToDisk;
    private saveMedia;
    private uploadToCloud;
    deleteFileFromDisk(url: string): void;
}
