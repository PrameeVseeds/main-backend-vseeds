"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ImagesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImagesService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const file_upload_validation_1 = require("../../common/utils/file-upload-validation");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let ImagesService = ImagesService_1 = class ImagesService {
    prisma;
    configService;
    logger = new common_1.Logger(ImagesService_1.name);
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
    }
    get uploadDir() {
        const dir = this.configService.get('UPLOAD_DIR');
        if (dir) {
            if (dir.startsWith('./') || dir.startsWith('../')) {
                return path.resolve(dir);
            }
            return dir;
        }
        const fallback = path.resolve(__dirname, '../../../../public_html/upload_vseeds/images');
        this.logger.warn(`UPLOAD_DIR not set. Falling back to: ${fallback}. Set UPLOAD_DIR in your .env file.`);
        return fallback;
    }
    get baseUrl() {
        return this.configService.get('CDN_URL') || 'https://cdn.vseeds.lk';
    }
    async getThumbnail(productId) {
        const pm = await this.prisma.productMedia.findFirst({
            where: { productId, isThumbnail: true },
            include: { media: true },
        });
        return pm?.media || null;
    }
    async getProductImages(productId) {
        const items = await this.prisma.productMedia.findMany({
            where: { productId, isThumbnail: false },
            include: { media: true },
            orderBy: [{ displayOrder: 'asc' }, { id: 'asc' }],
        });
        return items.map((pm) => pm.media);
    }
    async addThumbnail(productId, file, customName, folder = 'products') {
        const media = await this.saveMedia(file, customName, folder);
        await this.prisma.productMedia.create({
            data: {
                productId,
                mediaId: media.id,
                isThumbnail: true,
            },
        });
        return media;
    }
    async updateThumbnail(productId, file, customName, folder = 'products') {
        const existing = await this.prisma.productMedia.findFirst({
            where: { productId, isThumbnail: true },
            include: { media: true },
        });
        if (existing) {
            const validation = (0, file_upload_validation_1.validateImageUpload)(file.buffer, file.mimetype, {
                maxSize: file_upload_validation_1.FILE_UPLOAD_LIMITS.image,
            });
            if (!validation.valid) {
                throw new common_1.BadRequestException(validation.error);
            }
            if (validation.detectedMime &&
                file.mimetype !== validation.detectedMime) {
                file.mimetype = validation.detectedMime;
            }
            if (existing.media.filename) {
                const filepath = path.join(this.uploadDir, existing.media.filename);
                if (fs.existsSync(filepath)) {
                    fs.unlinkSync(filepath);
                }
            }
            const folderName = folder ? `vseeds-${folder}` : 'vseeds-general';
            const cloudResponse = await this.uploadToCloud(file, folderName);
            await this.prisma.media.update({
                where: { id: existing.mediaId },
                data: {
                    filename: cloudResponse.filename,
                    url: cloudResponse.url,
                    originalName: file.originalname,
                    mimeType: file.mimetype,
                    fileSize: file.size,
                },
            });
            return this.prisma.media.findUnique({ where: { id: existing.mediaId } });
        }
        return this.addThumbnail(productId, file, customName, folder);
    }
    async addImages(productId, files, customName, folder = 'products', startOrder = 0) {
        const results = [];
        for (let i = 0; i < files.length; i++) {
            const media = await this.saveMedia(files[i], customName, folder);
            await this.prisma.productMedia.create({
                data: {
                    productId,
                    mediaId: media.id,
                    isThumbnail: false,
                    displayOrder: startOrder + i,
                },
            });
            results.push(media);
        }
        return results;
    }
    async deleteMedia(mediaId) {
        const media = await this.prisma.media.findUnique({
            where: { id: mediaId },
        });
        if (!media)
            throw new common_1.NotFoundException('Media not found');
        await this.prisma.productMedia.deleteMany({ where: { mediaId } });
        await this.prisma.media.delete({ where: { id: mediaId } });
        if (media.filename) {
            const filepath = path.join(this.uploadDir, media.filename);
            if (fs.existsSync(filepath)) {
                fs.unlinkSync(filepath);
            }
        }
        return { message: 'Media deleted' };
    }
    async bulkDelete(ids) {
        const items = await this.prisma.media.findMany({
            where: { id: { in: ids } },
        });
        await this.prisma.productMedia.deleteMany({
            where: {
                mediaId: { in: ids },
            },
        });
        await this.prisma.media.deleteMany({
            where: {
                id: { in: ids },
            },
        });
        for (const item of items) {
            if (item.filename) {
                const filepath = path.join(this.uploadDir, item.filename);
                if (fs.existsSync(filepath)) {
                    fs.unlinkSync(filepath);
                }
            }
        }
        return { message: `${items.length} media items deleted` };
    }
    async uploadGeneric(file, customName, folder = 'general') {
        return this.saveMedia(file, customName, folder);
    }
    async getGallery(query) {
        const { page = 1, limit = 20, filter, categoryId } = query;
        const where = {};
        if (filter === 'used') {
            where.productMedia = { some: {} };
        }
        else if (filter === 'orphaned') {
            where.productMedia = { none: {} };
        }
        else if (filter === 'thumbnail') {
            where.productMedia = { some: { isThumbnail: true } };
        }
        if (categoryId) {
            if (filter === 'thumbnail') {
                where.productMedia = {
                    some: {
                        isThumbnail: true,
                        product: {
                            categoryId,
                        },
                    },
                };
            }
            else {
                where.productMedia = {
                    some: {
                        product: {
                            categoryId,
                        },
                    },
                };
            }
        }
        const [mediaItems, total] = await Promise.all([
            this.prisma.media.findMany({
                where,
                include: {
                    productMedia: {
                        include: {
                            product: true,
                        },
                    },
                },
                orderBy: {
                    createdAt: 'desc',
                },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.media.count({ where }),
        ]);
        const images = mediaItems.map((m) => {
            const pm = m.productMedia[0];
            return {
                id: m.id,
                filename: m.filename,
                originalName: m.originalName,
                url: m.url,
                mimeType: m.mimeType,
                fileSize: m.fileSize,
                altText: m.altText,
                createdAt: m.createdAt,
                productId: pm?.productId ?? null,
                isThumbnail: pm?.isThumbnail ?? null,
                displayOrder: pm?.displayOrder ?? null,
            };
        });
        return { images, total, totalPages: Math.ceil(total / limit), page };
    }
    async getCounts() {
        const allMedia = await this.prisma.media.findMany({
            select: {
                filename: true,
                mimeType: true,
            },
        });
        const typeCounts = {
            PNG: 0,
            JPG: 0,
            WEBP: 0,
        };
        const folderCounts = {
            Products: 0,
            Banners: 0,
            Blog: 0,
            Categories: 0,
            General: 0,
        };
        allMedia.forEach((media) => {
            const type = media.mimeType ? media.mimeType.split('/')[1].toUpperCase() : 'IMG';
            if (typeCounts[type] !== undefined) {
                typeCounts[type]++;
            }
            let folder = 'General';
            if (media.filename.includes('vseeds-')) {
                const parts = media.filename.split('-');
                if (parts.length >= 2) {
                    folder = parts[1].charAt(0).toUpperCase() + parts[1].slice(1);
                }
            }
            else if (media.filename.includes('thumbnail_') || media.filename.includes('images_')) {
                folder = 'Products';
            }
            if (folderCounts[folder] !== undefined) {
                folderCounts[folder]++;
            }
        });
        return {
            typeCounts,
            folderCounts,
            total: allMedia.length,
        };
    }
    writeToDisk(filename, buffer) {
        const dir = this.uploadDir;
        const fullPath = path.join(dir, filename);
        const targetDir = path.dirname(fullPath);
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        fs.writeFileSync(fullPath, buffer);
    }
    async saveMedia(file, _customName, folder) {
        const validation = (0, file_upload_validation_1.validateImageUpload)(file.buffer, file.mimetype, {
            maxSize: file_upload_validation_1.FILE_UPLOAD_LIMITS.image,
        });
        if (!validation.valid) {
            throw new common_1.BadRequestException(validation.error);
        }
        if (validation.detectedMime && file.mimetype !== validation.detectedMime) {
            file.mimetype = validation.detectedMime;
        }
        const folderName = folder ? `vseeds-${folder}` : 'vseeds-general';
        const cloudResponse = await this.uploadToCloud(file, folderName);
        return this.prisma.media.create({
            data: {
                filename: cloudResponse.filename,
                url: cloudResponse.url,
                originalName: file.originalname,
                mimeType: file.mimetype,
                fileSize: file.size,
            },
        });
    }
    async uploadToCloud(file, folderName) {
        const crypto = require('crypto');
        const extension = path.extname(file.originalname);
        const filename = `${folderName}-${crypto.randomUUID()}${extension}`;
        this.writeToDisk(filename, file.buffer);
        const url = `${this.baseUrl}/${filename}`;
        return {
            filename: filename,
            url: url,
        };
    }
    deleteFileFromDisk(url) {
        try {
            const relativePath = url.replace(`${this.baseUrl}/`, '');
            if (relativePath && relativePath !== url) {
                const filepath = path.join(this.uploadDir, relativePath);
                if (fs.existsSync(filepath)) {
                    fs.unlinkSync(filepath);
                }
            }
        }
        catch {
        }
    }
};
exports.ImagesService = ImagesService;
exports.ImagesService = ImagesService = ImagesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], ImagesService);
//# sourceMappingURL=images.service.js.map