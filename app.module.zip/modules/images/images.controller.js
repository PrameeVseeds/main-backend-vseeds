"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImagesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const images_service_1 = require("./images.service");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const image_file_filter_1 = require("../../common/utils/image-file-filter");
const gallery_query_dto_1 = require("./dto/gallery-query.dto");
const bulk_delete_dto_1 = require("./dto/bulk-delete.dto");
let ImagesController = class ImagesController {
    imagesService;
    constructor(imagesService) {
        this.imagesService = imagesService;
    }
    getThumbnail(productId) {
        return this.imagesService.getThumbnail(productId);
    }
    getProductImages(productId) {
        return this.imagesService.getProductImages(productId);
    }
    addThumbnail(productId, file, name, folder) {
        return this.imagesService.addThumbnail(productId, file, name, folder);
    }
    updateThumbnail(productId, file, name, folder) {
        return this.imagesService.updateThumbnail(productId, file, name, folder);
    }
    addImages(productId, files, name, folder) {
        return this.imagesService.addImages(productId, files, name, folder);
    }
    uploadGeneric(file, name, folder) {
        return this.imagesService.uploadGeneric(file, name, folder);
    }
    deleteMedia(mediaId) {
        return this.imagesService.deleteMedia(mediaId);
    }
    deleteThumbnail(mediaId) {
        return this.imagesService.deleteMedia(mediaId);
    }
    deleteProductMedia(mediaId) {
        return this.imagesService.deleteMedia(mediaId);
    }
    getGallery(query) {
        return this.imagesService.getGallery(query);
    }
    getCounts() {
        return this.imagesService.getCounts();
    }
    bulkDelete(dto) {
        return this.imagesService.bulkDelete(dto.ids);
    }
};
exports.ImagesController = ImagesController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('thumbnail/:productId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product thumbnail' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)('productId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "getThumbnail", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('images/:productId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get product images' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('productId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "getProductImages", null);
__decorate([
    (0, common_1.Post)('thumbnail/:productId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image', { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Upload thumbnail' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('productId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, common_1.Body)('name')),
    __param(3, (0, common_1.Body)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String, String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "addThumbnail", null);
__decorate([
    (0, common_1.Put)('thumbnail/:productId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image', { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Update thumbnail' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)('productId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, common_1.Body)('name')),
    __param(3, (0, common_1.Body)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String, String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "updateThumbnail", null);
__decorate([
    (0, common_1.Post)('images/:productId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FilesInterceptor)('images', 10, { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Upload product images' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)('productId', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.UploadedFiles)()),
    __param(2, (0, common_1.Body)('name')),
    __param(3, (0, common_1.Body)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array, String, String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "addImages", null);
__decorate([
    (0, common_1.Post)('upload'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Upload a standalone image' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('name')),
    __param(2, (0, common_1.Body)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "uploadGeneric", null);
__decorate([
    (0, common_1.Delete)('delete/:mediaId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete media by ID' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('mediaId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "deleteMedia", null);
__decorate([
    (0, common_1.Delete)('thumbnail/:mediaId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete thumbnail' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('mediaId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "deleteThumbnail", null);
__decorate([
    (0, common_1.Delete)('images/:mediaId'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete product image' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('mediaId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "deleteProductMedia", null);
__decorate([
    (0, common_1.Get)('gallery'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get media gallery with filters' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [gallery_query_dto_1.GalleryQueryDto]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "getGallery", null);
__decorate([
    (0, common_1.Get)('counts'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get image counts by type and folder' }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "getCounts", null);
__decorate([
    (0, common_1.Post)('bulk-delete'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Bulk delete media' }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_delete_dto_1.BulkDeleteDto]),
    __metadata("design:returntype", void 0)
], ImagesController.prototype, "bulkDelete", null);
exports.ImagesController = ImagesController = __decorate([
    (0, swagger_1.ApiTags)('Images'),
    (0, common_1.Controller)('images'),
    __metadata("design:paramtypes", [images_service_1.ImagesService])
], ImagesController);
//# sourceMappingURL=images.controller.js.map