import { PaginationDto } from '../../../common/dto/pagination.dto';
export declare class GalleryQueryDto extends PaginationDto {
    filter?: string;
    categoryId?: string;
}
