"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GalleryQueryDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const pagination_dto_1 = require("../../../common/dto/pagination.dto");
class GalleryQueryDto extends pagination_dto_1.PaginationDto {
    filter;
    categoryId;
    static _OPENAPI_METADATA_FACTORY() {
        return { filter: { required: false, type: () => String, enum: ['all', 'used', 'orphaned', 'thumbnail'] }, categoryId: { required: false, type: () => String } };
    }
}
exports.GalleryQueryDto = GalleryQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['all', 'used', 'orphaned', 'thumbnail'] }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(['all', 'used', 'orphaned', 'thumbnail']),
    __metadata("design:type", String)
], GalleryQueryDto.prototype, "filter", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], GalleryQueryDto.prototype, "categoryId", void 0);
//# sourceMappingURL=gallery-query.dto.js.map