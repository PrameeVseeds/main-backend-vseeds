export declare class ImagesModule {
}
