export declare class ContactsModule {
}
