import { ContactsService } from './contacts.service';
import { CreateContactDto } from './dto/create-contact.dto';
import { ReplyContactDto } from './dto/reply-contact.dto';
import { UpdateContactStatusDto } from './dto/update-contact-status.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
export declare class ContactsController {
    private readonly contactsService;
    constructor(contactsService: ContactsService);
    create(dto: CreateContactDto): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.ContactStatus;
        name: string;
        subject: string;
        message: string;
        source: import(".prisma/client").$Enums.ContactSource;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        contacts: {
            deletedAt: Date | null;
            id: string;
            email: string;
            phone: string | null;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.ContactStatus;
            name: string;
            subject: string;
            message: string;
            source: import(".prisma/client").$Enums.ContactSource;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    search(search: string, pagination: PaginationDto): Promise<{
        contacts: {
            deletedAt: Date | null;
            id: string;
            email: string;
            phone: string | null;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.ContactStatus;
            name: string;
            subject: string;
            message: string;
            source: import(".prisma/client").$Enums.ContactSource;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<import("./dto/contact-detail-response.dto").ContactDetailResponseDto>;
    updateStatus(id: string, dto: UpdateContactStatusDto): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.ContactStatus;
        name: string;
        subject: string;
        message: string;
        source: import(".prisma/client").$Enums.ContactSource;
    }>;
    delete(id: string): Promise<{
        message: string;
    }>;
    reply(id: string, dto: ReplyContactDto, user: JwtPayload): Promise<{
        message: string;
        reply: {
            id: string;
            createdAt: Date;
            message: string;
            adminId: string;
            contactId: string;
        };
    }>;
}
