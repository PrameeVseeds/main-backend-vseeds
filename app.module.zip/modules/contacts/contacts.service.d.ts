import { PrismaService } from '../../prisma/prisma.service';
import { CreateContactDto } from './dto/create-contact.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { ContactDetailResponseDto } from './dto/contact-detail-response.dto';
export declare class ContactsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(dto: CreateContactDto): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.ContactStatus;
        name: string;
        subject: string;
        message: string;
        source: import(".prisma/client").$Enums.ContactSource;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        contacts: {
            deletedAt: Date | null;
            id: string;
            email: string;
            phone: string | null;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.ContactStatus;
            name: string;
            subject: string;
            message: string;
            source: import(".prisma/client").$Enums.ContactSource;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    search(query: string, pagination: PaginationDto): Promise<{
        contacts: {
            deletedAt: Date | null;
            id: string;
            email: string;
            phone: string | null;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.ContactStatus;
            name: string;
            subject: string;
            message: string;
            source: import(".prisma/client").$Enums.ContactSource;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<ContactDetailResponseDto>;
    updateStatus(id: string, status: string): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.ContactStatus;
        name: string;
        subject: string;
        message: string;
        source: import(".prisma/client").$Enums.ContactSource;
    }>;
    softDelete(id: string): Promise<{
        message: string;
    }>;
    reply(id: string, message: string, adminId: string): Promise<{
        message: string;
        reply: {
            id: string;
            createdAt: Date;
            message: string;
            adminId: string;
            contactId: string;
        };
    }>;
}
