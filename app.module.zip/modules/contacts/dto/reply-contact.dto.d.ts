export declare class ReplyContactDto {
    message: string;
}
