export declare class ContactReplyResponseDto {
    id: string;
    message: string;
    createdAt?: Date;
}
export declare class ContactDetailResponseDto {
    id: string;
    name: string;
    email: string;
    phone?: string;
    subject?: string;
    message: string;
    source: string;
    status: string;
    createdAt?: Date;
    replies: ContactReplyResponseDto[];
}
