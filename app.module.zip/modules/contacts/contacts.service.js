"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let ContactsService = class ContactsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto) {
        return this.prisma.contact.create({
            data: {
                name: dto.name,
                email: dto.email,
                phone: dto.phone,
                subject: dto.subject || '',
                message: dto.message,
                source: dto.source,
                status: 'new',
            },
        });
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const skip = (page - 1) * limit;
        const [contacts, total] = await this.prisma.$transaction([
            this.prisma.contact.findMany({
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.contact.count(),
        ]);
        return { contacts, total, totalPages: Math.ceil(total / limit), page };
    }
    async search(query, pagination) {
        const { page = 1, limit = 10 } = pagination;
        const skip = (page - 1) * limit;
        const [contacts, total] = await this.prisma.$transaction([
            this.prisma.contact.findMany({
                where: {
                    OR: [{ name: { contains: query } }],
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.contact.count({
                where: {
                    OR: [{ name: { contains: query } }],
                },
            }),
        ]);
        return { contacts, total, totalPages: Math.ceil(total / limit), page };
    }
    async findById(id) {
        const contact = await this.prisma.contact.findUnique({
            where: { id },
            include: {
                replies: {
                    orderBy: { createdAt: 'asc' },
                },
            },
        });
        if (!contact)
            throw new common_1.NotFoundException('Contact not found');
        return {
            id: contact.id,
            name: contact.name,
            email: contact.email,
            phone: contact.phone ?? undefined,
            subject: contact.subject,
            message: contact.message,
            source: contact.source,
            status: contact.status,
            createdAt: contact.createdAt,
            replies: contact.replies.map((r) => ({
                id: r.id,
                message: r.message,
                createdAt: r.createdAt,
            })),
        };
    }
    async updateStatus(id, status) {
        const contact = await this.prisma.contact.findUnique({ where: { id } });
        if (!contact)
            throw new common_1.NotFoundException('Contact not found');
        const updated = await this.prisma.contact.update({
            where: { id },
            data: { status: status },
        });
        return updated;
    }
    async softDelete(id) {
        await this.findById(id);
        await this.prisma.contact.delete({
            where: { id },
        });
        return { message: 'Contact deleted' };
    }
    async reply(id, message, adminId) {
        const contact = await this.prisma.contact.findUnique({ where: { id } });
        if (!contact)
            throw new common_1.NotFoundException('Contact not found');
        const reply = await this.prisma.contactReply.create({
            data: {
                contactId: id,
                message,
                adminId,
            },
        });
        await this.prisma.contact.update({
            where: { id },
            data: { status: 'replied' },
        });
        return { message: 'Reply sent', reply };
    }
};
exports.ContactsService = ContactsService;
exports.ContactsService = ContactsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ContactsService);
//# sourceMappingURL=contacts.service.js.map