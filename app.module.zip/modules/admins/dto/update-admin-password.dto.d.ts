export declare class UpdateAdminPasswordDto {
    currentPassword: string;
    newPassword: string;
}
