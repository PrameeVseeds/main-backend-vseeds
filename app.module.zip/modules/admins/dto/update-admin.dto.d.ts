export declare class UpdateAdminDto {
    username?: string;
    password?: string;
    roleId?: string;
    phone?: string;
    status?: string;
}
