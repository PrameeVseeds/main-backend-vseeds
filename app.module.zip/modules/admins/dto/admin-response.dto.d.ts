export declare class AdminResponseDto {
    id: string;
    username: string;
    email: string;
    roleId?: string;
    role?: string;
    status: string;
    phone?: string;
    avatarUrl?: string;
    twoFactorEnabled?: boolean;
    lastLoginAt?: Date;
    createdAt?: Date;
    updatedAt?: Date;
}
