export declare class CreateAdminDto {
    username: string;
    email: string;
    password: string;
    roleId: string;
    phone?: string;
}
