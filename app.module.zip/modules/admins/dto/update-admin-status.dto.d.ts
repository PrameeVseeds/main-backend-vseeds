export declare class UpdateAdminStatusDto {
    status: string;
}
