export declare class AdminsModule {
}
