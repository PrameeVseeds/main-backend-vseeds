import { PrismaService } from '../../prisma/prisma.service';
import { CreateAdminDto } from './dto/create-admin.dto';
import { UpdateAdminDto } from './dto/update-admin.dto';
import { UpdateAdminStatusDto } from './dto/update-admin-status.dto';
import { UpdateAdminPasswordDto } from './dto/update-admin-password.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { EmailQueueService } from '../email/email-queue.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { AdminResponseDto } from './dto/admin-response.dto';
export declare class AdminsService {
    private readonly prisma;
    private readonly encryptionService;
    private readonly emailQueueService;
    constructor(prisma: PrismaService, encryptionService: EncryptionService, emailQueueService: EmailQueueService);
    create(dto: CreateAdminDto): Promise<AdminResponseDto>;
    findAll(pagination: PaginationDto, type?: string): Promise<{
        admins: {
            id: string;
            username: string;
            email: string;
            roleId: string | null;
            role: string | undefined;
            status: import(".prisma/client").$Enums.AdminStatus;
            phone: string | null;
            avatarUrl: string | null;
            twoFactorEnabled: boolean;
            lastLoginAt: Date | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        count: number;
    }>;
    search(query: string, pagination: PaginationDto): Promise<{
        admins: {
            id: string;
            username: string;
            email: string;
            role: string | undefined;
            status: import(".prisma/client").$Enums.AdminStatus;
            avatarUrl: string | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<AdminResponseDto>;
    findByEmail(email: string): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        emailLookup: string;
        passwordHash: string;
        status: import(".prisma/client").$Enums.AdminStatus;
        twoFactorSecret: string | null;
        twoFactorEnabled: boolean;
        lastLoginAt: Date | null;
        refreshToken: string | null;
        resetToken: string | null;
        username: string;
        usernameLookup: string;
        roleId: string | null;
        address: string | null;
        avatarUrl: string | null;
        failedLoginCount: number;
        lockedUntil: Date | null;
    } | null>;
    update(id: string, dto: UpdateAdminDto): Promise<AdminResponseDto>;
    updateStatus(id: string, dto: UpdateAdminStatusDto): Promise<AdminResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    updateOwnPassword(adminId: string, dto: UpdateAdminPasswordDto): Promise<{
        message: string;
    }>;
    unlockAdmin(id: string): Promise<{
        message: string;
    }>;
}
