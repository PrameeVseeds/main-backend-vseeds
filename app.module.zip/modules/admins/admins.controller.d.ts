import { AdminsService } from './admins.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { CreateAdminDto } from './dto/create-admin.dto';
import { UpdateAdminDto } from './dto/update-admin.dto';
import { UpdateAdminStatusDto } from './dto/update-admin-status.dto';
import { UpdateAdminPasswordDto } from './dto/update-admin-password.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class AdminsController {
    private readonly adminsService;
    constructor(adminsService: AdminsService);
    create(dto: CreateAdminDto): Promise<import("./dto/admin-response.dto").AdminResponseDto>;
    findAll(pagination: PaginationDto, type?: string): Promise<{
        admins: {
            id: string;
            username: string;
            email: string;
            roleId: string | null;
            role: string | undefined;
            status: import(".prisma/client").$Enums.AdminStatus;
            phone: string | null;
            avatarUrl: string | null;
            twoFactorEnabled: boolean;
            lastLoginAt: Date | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        count: number;
    }>;
    search(query: string, pagination: PaginationDto): Promise<{
        admins: {
            id: string;
            username: string;
            email: string;
            role: string | undefined;
            status: import(".prisma/client").$Enums.AdminStatus;
            avatarUrl: string | null;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findOne(id: string): Promise<import("./dto/admin-response.dto").AdminResponseDto>;
    update(id: string, dto: UpdateAdminDto): Promise<import("./dto/admin-response.dto").AdminResponseDto>;
    updateStatus(id: string, dto: UpdateAdminStatusDto): Promise<import("./dto/admin-response.dto").AdminResponseDto>;
    delete(id: string): Promise<{
        message: string;
    }>;
    updateOwnPassword(user: JwtPayload, dto: UpdateAdminPasswordDto): Promise<{
        message: string;
    }>;
    unlockAdmin(id: string): Promise<{
        message: string;
    }>;
}
