"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const bcrypt = __importStar(require("bcryptjs"));
const email_queue_service_1 = require("../email/email-queue.service");
const encryption_service_1 = require("../../common/services/encryption.service");
const lookup_hash_util_1 = require("../../common/utils/lookup-hash.util");
let AdminsService = class AdminsService {
    prisma;
    encryptionService;
    emailQueueService;
    constructor(prisma, encryptionService, emailQueueService) {
        this.prisma = prisma;
        this.encryptionService = encryptionService;
        this.emailQueueService = emailQueueService;
    }
    async create(dto) {
        const existing = await this.prisma.admin.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email') },
        });
        if (existing)
            throw new common_1.BadRequestException('An admin with this email already exists');
        const existingUsername = await this.prisma.admin.findUnique({
            where: { usernameLookup: (0, lookup_hash_util_1.createLookupHash)(dto.username, 'username') },
        });
        if (existingUsername) {
            throw new common_1.BadRequestException('An admin with this username already exists');
        }
        const hashed = await bcrypt.hash(dto.password, 10);
        const saved = await this.prisma.admin.create({
            data: {
                username: dto.username,
                usernameLookup: (0, lookup_hash_util_1.createLookupHash)(dto.username, 'username'),
                email: dto.email,
                emailLookup: (0, lookup_hash_util_1.createLookupHash)(dto.email, 'email'),
                passwordHash: hashed,
                roleId: dto.roleId,
                phone: dto.phone,
            },
        });
        await this.emailQueueService.enqueue('admin-registration', saved.email, {
            username: saved.username,
            email: saved.email,
            password: dto.password,
        });
        return this.findById(saved.id);
    }
    async findAll(pagination, type) {
        const { page = 1, limit = 10 } = pagination;
        const where = {};
        if (type && type !== 'all') {
            where.role = { name: type };
        }
        const [admins, total] = await Promise.all([
            this.prisma.admin.findMany({
                where,
                include: { role: true },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.admin.count({ where }),
        ]);
        return {
            admins: admins.map((a) => ({
                id: a.id,
                username: this.encryptionService.decrypt(a.username),
                email: this.encryptionService.decrypt(a.email),
                roleId: a.roleId,
                role: a.role?.name,
                status: a.status,
                phone: a.phone,
                avatarUrl: a.avatarUrl,
                twoFactorEnabled: a.twoFactorEnabled,
                lastLoginAt: a.lastLoginAt,
                createdAt: a.createdAt,
            })),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async count() {
        const total = await this.prisma.admin.count();
        return { count: total };
    }
    async search(query, pagination) {
        const { page = 1, limit = 10 } = pagination;
        const or = [];
        if ((0, lookup_hash_util_1.isLikelyEmail)(query)) {
            or.push({ emailLookup: (0, lookup_hash_util_1.createLookupHash)(query, 'email') });
        }
        else {
            or.push({ usernameLookup: (0, lookup_hash_util_1.createLookupHash)(query, 'username') });
        }
        const where = { OR: or };
        const [admins, total] = await Promise.all([
            this.prisma.admin.findMany({
                where,
                include: { role: true },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.admin.count({ where }),
        ]);
        return {
            admins: admins.map((a) => ({
                id: a.id,
                username: this.encryptionService.decrypt(a.username),
                email: this.encryptionService.decrypt(a.email),
                role: a.role?.name,
                status: a.status,
                avatarUrl: a.avatarUrl,
                createdAt: a.createdAt,
            })),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async findById(id) {
        const admin = await this.prisma.admin.findUnique({
            where: { id },
            include: { role: true },
        });
        if (!admin)
            throw new common_1.NotFoundException('Admin not found');
        return {
            id: admin.id,
            username: this.encryptionService.decrypt(admin.username),
            email: this.encryptionService.decrypt(admin.email),
            roleId: admin.roleId ?? undefined,
            role: admin.role?.name,
            status: admin.status,
            phone: admin.phone ?? undefined,
            avatarUrl: admin.avatarUrl ?? undefined,
            twoFactorEnabled: admin.twoFactorEnabled,
            lastLoginAt: admin.lastLoginAt ?? undefined,
            createdAt: admin.createdAt,
            updatedAt: admin.updatedAt,
        };
    }
    async findByEmail(email) {
        return this.prisma.admin.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(email, 'email') },
        });
    }
    async update(id, dto) {
        await this.findById(id);
        const updateData = {};
        if (dto.username) {
            updateData.username = this.encryptionService.encrypt(dto.username);
            updateData.usernameLookup = (0, lookup_hash_util_1.createLookupHash)(dto.username, 'username');
        }
        if (dto.roleId) {
            updateData.role = { connect: { id: dto.roleId } };
        }
        if (dto.phone !== undefined)
            updateData.phone = dto.phone;
        if (dto.status)
            updateData.status = dto.status;
        if (dto.password) {
            updateData.passwordHash = await bcrypt.hash(dto.password, 12);
        }
        await this.prisma.admin.update({
            where: { id },
            data: updateData,
        });
        return this.findById(id);
    }
    async updateStatus(id, dto) {
        const admin = await this.findById(id);
        await this.prisma.admin.update({
            where: { id },
            data: { status: dto.status },
        });
        const template = dto.status === 'active'
            ? 'admin-account-activated'
            : 'admin-account-deactivated';
        await this.emailQueueService.enqueue(template, admin.email, {
            username: admin.username,
        });
        return this.findById(id);
    }
    async delete(id) {
        const admin = await this.prisma.admin.findUnique({
            where: { id },
            include: { role: true },
        });
        if (!admin)
            throw new common_1.NotFoundException('Admin not found');
        if (admin.role?.name === 'super admin') {
            throw new common_1.BadRequestException('Cannot delete a super admin');
        }
        const email = admin.email;
        const username = admin.username;
        await this.prisma.admin.delete({ where: { id } });
        await this.emailQueueService.enqueue('admin-account-deleted', email, {
            username,
        });
        return { message: 'Admin deleted' };
    }
    async updateOwnPassword(adminId, dto) {
        const admin = await this.prisma.admin.findUnique({
            where: { id: adminId },
        });
        if (!admin)
            throw new common_1.NotFoundException('Admin not found');
        const valid = await bcrypt.compare(dto.currentPassword, admin.passwordHash);
        if (!valid)
            throw new common_1.UnauthorizedException('Current password is incorrect');
        const hashed = await bcrypt.hash(dto.newPassword, 10);
        await this.prisma.admin.update({
            where: { id: adminId },
            data: { passwordHash: hashed },
        });
        return { message: 'Password updated successfully' };
    }
    async unlockAdmin(id) {
        const admin = await this.prisma.admin.findUnique({ where: { id } });
        if (!admin)
            throw new common_1.NotFoundException('Admin not found');
        await this.prisma.admin.update({
            where: { id },
            data: {
                lockedUntil: null,
                failedLoginCount: 0,
            },
        });
        return { message: 'Admin account unlocked successfully' };
    }
};
exports.AdminsService = AdminsService;
exports.AdminsService = AdminsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService,
        email_queue_service_1.EmailQueueService])
], AdminsService);
//# sourceMappingURL=admins.service.js.map