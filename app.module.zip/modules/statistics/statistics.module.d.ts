export declare class StatisticsModule {
}
