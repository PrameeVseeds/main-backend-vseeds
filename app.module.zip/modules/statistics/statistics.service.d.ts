import { PrismaService } from '../../prisma/prisma.service';
export declare class StatisticsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getBasicStats(): Promise<{
        categories: number;
        products: number;
        activeProducts: number;
        lowStock: number;
        outOfStock: number;
    }>;
    getDetailedStats(): Promise<{
        totalRevenue: number;
        totalQuotes: number;
        pendingQuotes: number;
        totalUsers: number;
        newUsersThisMonth: number;
        totalOrders: number;
        pendingOrders: number;
        processingOrders: number;
        deliveredOrders: number;
        categories: number;
        products: number;
        activeProducts: number;
        lowStock: number;
        outOfStock: number;
    }>;
    getCategoryStats(): Promise<unknown[]>;
    getProductsByCategory(): Promise<unknown[]>;
    getInventoryInsights(): Promise<{
        totalInventoryValue: number;
        averageProductPrice: number;
        totalUnits: number;
        topCategories: unknown[];
        lowStockProducts: unknown[];
    }>;
    getTrends(period?: string): Promise<{
        period: string;
        days: number;
        newProducts: number;
        newCategories: number;
        newOrders: number;
        newUsers: number;
    }>;
    getPriceRanges(): Promise<unknown[]>;
    private getOrderStats;
    private getUserStats;
    private getQuoteStats;
    private getRevenueStats;
    private count;
    private parsePeriod;
}
