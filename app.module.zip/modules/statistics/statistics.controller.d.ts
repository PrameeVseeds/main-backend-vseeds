import { StatisticsService } from './statistics.service';
import { TrendsQueryDto } from './dto/trends-query.dto';
export declare class StatisticsController {
    private readonly statisticsService;
    constructor(statisticsService: StatisticsService);
    getBasicStats(): Promise<{
        categories: number;
        products: number;
        activeProducts: number;
        lowStock: number;
        outOfStock: number;
    }>;
    getDetailedStats(): Promise<{
        totalRevenue: number;
        totalQuotes: number;
        pendingQuotes: number;
        totalUsers: number;
        newUsersThisMonth: number;
        totalOrders: number;
        pendingOrders: number;
        processingOrders: number;
        deliveredOrders: number;
        categories: number;
        products: number;
        activeProducts: number;
        lowStock: number;
        outOfStock: number;
    }>;
    getCategoryStats(): Promise<unknown[]>;
    getProductsByCategory(): Promise<unknown[]>;
    getInventoryInsights(): Promise<{
        totalInventoryValue: number;
        averageProductPrice: number;
        totalUnits: number;
        topCategories: unknown[];
        lowStockProducts: unknown[];
    }>;
    getTrends(query: TrendsQueryDto): Promise<{
        period: string;
        days: number;
        newProducts: number;
        newCategories: number;
        newOrders: number;
        newUsers: number;
    }>;
    getPriceRanges(): Promise<unknown[]>;
}
