"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendsQueryDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class TrendsQueryDto {
    period;
    static _OPENAPI_METADATA_FACTORY() {
        return { period: { required: false, type: () => String, enum: ['7d', '30d', '90d', '1y'] } };
    }
}
exports.TrendsQueryDto = TrendsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['7d', '30d', '90d', '1y'] }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(['7d', '30d', '90d', '1y']),
    __metadata("design:type", String)
], TrendsQueryDto.prototype, "period", void 0);
//# sourceMappingURL=trends-query.dto.js.map