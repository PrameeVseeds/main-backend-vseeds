export declare class TrendsQueryDto {
    period?: string;
}
