import { BanksService } from './banks.service';
import { CreateBankDto } from './dto/create-bank.dto';
import { UpdateBankDto } from './dto/update-bank.dto';
export declare class BanksController {
    private readonly banksService;
    constructor(banksService: BanksService);
    create(createBankDto: CreateBankDto): Promise<import("./dto/bank-response.dto").BankResponseDto>;
    findAll(): Promise<import("./dto/bank-response.dto").BankResponseDto[]>;
    findActive(): Promise<import("./dto/bank-response.dto").BankResponseDto[]>;
    findOne(id: string): Promise<import("./dto/bank-response.dto").BankResponseDto>;
    update(id: string, updateBankDto: UpdateBankDto): Promise<import("./dto/bank-response.dto").BankResponseDto>;
    remove(id: string): Promise<void>;
}
