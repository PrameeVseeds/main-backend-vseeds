export declare class CreateBankDto {
    bankName: string;
    branch: string;
    accountNumber: string;
    accountName: string;
    isActive?: boolean;
    displayOrder?: number;
}
