export declare class BankResponseDto {
    id: string;
    bankName: string;
    branch: string;
    accountNumber: string;
    accountName: string;
    isActive: boolean;
    displayOrder: number;
    createdAt?: Date;
    updatedAt?: Date;
}
