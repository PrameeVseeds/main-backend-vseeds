"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BanksService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../../common/services/encryption.service");
let BanksService = class BanksService {
    prisma;
    encryptionService;
    constructor(prisma, encryptionService) {
        this.prisma = prisma;
        this.encryptionService = encryptionService;
    }
    async onModuleInit() {
        const count = await this.prisma.bank.count();
        if (count === 0) {
            await this.prisma.bank.createMany({
                data: [
                    {
                        bankName: 'Sampath Bank',
                        branch: 'Negombo',
                        accountNumber: 'xxxxxxxxxx',
                        accountName: 'SEEDS (PVT) LTD',
                        isActive: true,
                        displayOrder: 1,
                    },
                    {
                        bankName: 'Bank of Ceylon',
                        branch: 'Negombo',
                        accountNumber: 'xxxxxxxxxx',
                        accountName: 'SEEDS (PVT) LTD',
                        isActive: true,
                        displayOrder: 2,
                    },
                ],
            });
        }
    }
    toResponseDto(bank) {
        return {
            id: bank.id,
            bankName: this.encryptionService.decrypt(bank.bankName),
            branch: this.encryptionService.decrypt(bank.branch),
            accountNumber: this.encryptionService.decrypt(bank.accountNumber),
            accountName: this.encryptionService.decrypt(bank.accountName),
            isActive: bank.isActive,
            displayOrder: bank.displayOrder,
            createdAt: bank.createdAt,
            updatedAt: bank.updatedAt,
        };
    }
    async create(dto) {
        const saved = await this.prisma.bank.create({
            data: dto,
        });
        return this.toResponseDto(saved);
    }
    async findAll() {
        const banks = await this.prisma.bank.findMany({
            orderBy: [{ displayOrder: 'asc' }, { bankName: 'asc' }],
        });
        return banks.map((b) => this.toResponseDto(b));
    }
    async findActive() {
        const banks = await this.prisma.bank.findMany({
            where: { isActive: true },
            orderBy: [{ displayOrder: 'asc' }, { bankName: 'asc' }],
        });
        return banks.map((b) => this.toResponseDto(b));
    }
    async findOne(id) {
        const bank = await this.prisma.bank.findUnique({
            where: { id },
        });
        if (!bank) {
            throw new common_1.NotFoundException(`Bank with ID ${id} not found`);
        }
        return this.toResponseDto(bank);
    }
    async update(id, dto) {
        await this.findOne(id);
        const saved = await this.prisma.bank.update({
            where: { id },
            data: dto,
        });
        return this.toResponseDto(saved);
    }
    async remove(id) {
        await this.findOne(id);
        await this.prisma.bank.delete({
            where: { id },
        });
    }
};
exports.BanksService = BanksService;
exports.BanksService = BanksService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService])
], BanksService);
//# sourceMappingURL=banks.service.js.map