import { OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { CreateBankDto } from './dto/create-bank.dto';
import { UpdateBankDto } from './dto/update-bank.dto';
import { BankResponseDto } from './dto/bank-response.dto';
export declare class BanksService implements OnModuleInit {
    private readonly prisma;
    private readonly encryptionService;
    constructor(prisma: PrismaService, encryptionService: EncryptionService);
    onModuleInit(): Promise<void>;
    private toResponseDto;
    create(dto: CreateBankDto): Promise<BankResponseDto>;
    findAll(): Promise<BankResponseDto[]>;
    findActive(): Promise<BankResponseDto[]>;
    findOne(id: string): Promise<BankResponseDto>;
    update(id: string, dto: UpdateBankDto): Promise<BankResponseDto>;
    remove(id: string): Promise<void>;
}
