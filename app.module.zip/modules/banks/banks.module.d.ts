export declare class BanksModule {
}
