"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BannersController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const config_1 = require("@nestjs/config");
const banners_service_1 = require("./banners.service");
const public_decorator_1 = require("../../common/decorators/public.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const image_file_filter_1 = require("../../common/utils/image-file-filter");
const create_banner_dto_1 = require("./dto/create-banner.dto");
const banner_query_dto_1 = require("./dto/banner-query.dto");
const file_upload_validation_1 = require("../../common/utils/file-upload-validation");
let BannersController = class BannersController {
    bannersService;
    configService;
    constructor(bannersService, configService) {
        this.bannersService = bannersService;
        this.configService = configService;
    }
    findAll(query) {
        return this.bannersService.findAll(query);
    }
    findById(id) {
        return this.bannersService.findById(id);
    }
    async create(file, dto) {
        if (!file)
            throw new common_1.BadRequestException('Image file is required');
        const validation = (0, file_upload_validation_1.validateImageUpload)(file.buffer, file.mimetype, {
            maxSize: file_upload_validation_1.FILE_UPLOAD_LIMITS.banner,
        });
        if (!validation.valid) {
            throw new common_1.BadRequestException(validation.error);
        }
        if (validation.detectedMime && file.mimetype !== validation.detectedMime) {
            file.mimetype = validation.detectedMime;
        }
        const fs = require('fs');
        const path = require('path');
        const crypto = require('crypto');
        const uploadDir = process.env.UPLOAD_DIR || './uploads/images';
        const extension = path.extname(file.originalname);
        const filename = `banner-${crypto.randomUUID()}${extension}`;
        const filepath = path.join(uploadDir, filename);
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        fs.writeFileSync(filepath, file.buffer);
        const cdnUrl = this.configService.get('CDN_URL', 'https://www.vseeds.lk/upload_vseeds/images');
        const imageUrl = `${cdnUrl}/${filename}`;
        return this.bannersService.create(imageUrl, dto.deviceType, dto.isActive !== false, dto.title, dto.linkUrl, dto.displayOrder, dto.startsAt ? new Date(dto.startsAt) : undefined, dto.endsAt ? new Date(dto.endsAt) : undefined);
    }
    async update(id, file, dto) {
        const existingBanner = await this.bannersService.findById(id);
        let imageUrl = existingBanner.imageUrl;
        if (file) {
            const validation = (0, file_upload_validation_1.validateImageUpload)(file.buffer, file.mimetype, {
                maxSize: file_upload_validation_1.FILE_UPLOAD_LIMITS.banner,
            });
            if (!validation.valid) {
                throw new common_1.BadRequestException(validation.error);
            }
            if (validation.detectedMime &&
                file.mimetype !== validation.detectedMime) {
                file.mimetype = validation.detectedMime;
            }
            if (existingBanner.imageUrl) {
                const fs = require('fs');
                const path = require('path');
                const uploadDir = process.env.UPLOAD_DIR || './uploads/images';
                const filename = existingBanner.imageUrl.split('/').pop();
                const filepath = path.join(uploadDir, filename);
                if (fs.existsSync(filepath)) {
                    fs.unlinkSync(filepath);
                }
            }
            const fs = require('fs');
            const path = require('path');
            const crypto = require('crypto');
            const uploadDir = process.env.UPLOAD_DIR || './uploads/images';
            const extension = path.extname(file.originalname);
            const filename = `banner-${crypto.randomUUID()}${extension}`;
            const filepath = path.join(uploadDir, filename);
            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }
            fs.writeFileSync(filepath, file.buffer);
            const cdnUrl = this.configService.get('CDN_URL', 'https://www.vseeds.lk/upload_vseeds/images');
            imageUrl = `${cdnUrl}/${filename}`;
        }
        const updateData = {};
        if (imageUrl)
            updateData.imageUrl = imageUrl;
        if (dto.title !== undefined)
            updateData.title = dto.title;
        if (dto.deviceType !== undefined) {
            updateData.deviceType = dto.deviceType;
        }
        if (dto.linkUrl !== undefined)
            updateData.linkUrl = dto.linkUrl;
        if (dto.displayOrder !== undefined) {
            updateData.displayOrder = Number(dto.displayOrder);
        }
        if (dto.isActive !== undefined)
            updateData.isActive = String(dto.isActive) !== 'false';
        if (dto.startsAt)
            updateData.startsAt = new Date(dto.startsAt);
        else if (dto.startsAt === '')
            updateData.startsAt = null;
        if (dto.endsAt)
            updateData.endsAt = new Date(dto.endsAt);
        else if (dto.endsAt === '')
            updateData.endsAt = null;
        return this.bannersService.update(id, updateData);
    }
    updateStatus(id, active) {
        return this.bannersService.updateStatus(id, active);
    }
    async remove(id) {
        return this.bannersService.remove(id);
    }
};
exports.BannersController = BannersController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get banners (public, filterable)' }),
    openapi.ApiResponse({ status: 200, type: [require("./dto/banner-response.dto").BannerResponseDto] }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [banner_query_dto_1.BannerQueryDto]),
    __metadata("design:returntype", void 0)
], BannersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get banner by ID' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/banner-response.dto").BannerResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], BannersController.prototype, "findById", null);
__decorate([
    (0, common_1.Post)('add'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image', { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Add banner with image (admin)' }),
    openapi.ApiResponse({ status: 201, type: require("./dto/banner-response.dto").BannerResponseDto }),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, create_banner_dto_1.CreateBannerDto]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('update/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image', { fileFilter: image_file_filter_1.imageFileFilter })),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Update an existing banner (admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/banner-response.dto").BannerResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "update", null);
__decorate([
    (0, common_1.Put)('status/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Toggle banner status (admin)' }),
    openapi.ApiResponse({ status: 200, type: require("./dto/banner-response.dto").BannerResponseDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)('active')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean]),
    __metadata("design:returntype", void 0)
], BannersController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)('delete/:id'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete banner (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "remove", null);
exports.BannersController = BannersController = __decorate([
    (0, swagger_1.ApiTags)('Banners'),
    (0, common_1.Controller)('banner'),
    __metadata("design:paramtypes", [banners_service_1.BannersService,
        config_1.ConfigService])
], BannersController);
//# sourceMappingURL=banners.controller.js.map