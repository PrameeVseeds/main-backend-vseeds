export declare class BannerQueryDto {
    device_type?: string;
    is_active?: string;
}
