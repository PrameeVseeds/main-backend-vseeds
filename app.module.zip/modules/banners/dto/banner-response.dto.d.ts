export declare class BannerResponseDto {
    id: string;
    title?: string;
    imageUrl: string;
    linkUrl?: string;
    deviceType: string;
    displayOrder: number;
    isActive: boolean;
    startsAt?: Date;
    endsAt?: Date;
    createdAt?: Date;
    updatedAt?: Date;
}
