import { DeviceType } from '@prisma/client';
export declare class CreateBannerDto {
    title?: string;
    deviceType: DeviceType;
    linkUrl?: string;
    displayOrder?: number;
    isActive?: boolean;
    startsAt?: string;
    endsAt?: string;
}
