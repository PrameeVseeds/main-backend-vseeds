"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BannersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let BannersService = class BannersService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async deleteBannerImage(imageUrl) {
        if (!imageUrl)
            return;
        const fs = require('fs');
        const path = require('path');
        const uploadDir = process.env.UPLOAD_DIR || './uploads/images';
        const filename = imageUrl.split('/').pop();
        const filepath = path.join(uploadDir, filename);
        if (fs.existsSync(filepath)) {
            try {
                fs.unlinkSync(filepath);
            }
            catch (err) {
                console.error('Failed to delete banner from server:', err);
            }
        }
    }
    toResponseDto(banner) {
        return {
            id: banner.id,
            title: banner.title ?? undefined,
            imageUrl: banner.imageUrl,
            linkUrl: banner.linkUrl ?? undefined,
            deviceType: banner.deviceType,
            displayOrder: banner.displayOrder,
            isActive: banner.isActive,
            startsAt: banner.startsAt ?? undefined,
            endsAt: banner.endsAt ?? undefined,
            createdAt: banner.createdAt,
            updatedAt: banner.updatedAt,
        };
    }
    async findAll(query) {
        const where = {};
        if (query.device_type) {
            where.deviceType = query.device_type;
        }
        if (query.is_active !== undefined) {
            where.isActive = query.is_active === 'true';
        }
        const banners = await this.prisma.banner.findMany({
            where,
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'desc' }],
        });
        return banners.map((b) => this.toResponseDto(b));
    }
    async findById(id) {
        const banner = await this.prisma.banner.findUnique({
            where: { id },
        });
        if (!banner)
            throw new common_1.NotFoundException('Banner not found');
        return this.toResponseDto(banner);
    }
    async create(imageUrl, deviceType, isActive = true, title, linkUrl, displayOrder, startsAt, endsAt) {
        const saved = await this.prisma.banner.create({
            data: {
                imageUrl,
                deviceType: deviceType,
                isActive,
                title: title || '',
                linkUrl,
                displayOrder: displayOrder ?? 0,
                startsAt,
                endsAt,
            },
        });
        return this.toResponseDto(saved);
    }
    async updateStatus(id, isActive) {
        await this.findById(id);
        const updated = await this.prisma.banner.update({
            where: { id },
            data: { isActive },
        });
        return this.toResponseDto(updated);
    }
    async update(id, data) {
        await this.findById(id);
        const updated = await this.prisma.banner.update({
            where: { id },
            data,
        });
        return this.toResponseDto(updated);
    }
    async remove(id) {
        const banner = await this.prisma.banner.findUnique({ where: { id } });
        if (!banner)
            throw new common_1.NotFoundException('Banner not found');
        if (banner.imageUrl) {
            await this.deleteBannerImage(banner.imageUrl);
        }
        await this.prisma.banner.delete({
            where: { id },
        });
        return { message: 'Banner deleted' };
    }
};
exports.BannersService = BannersService;
exports.BannersService = BannersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], BannersService);
//# sourceMappingURL=banners.service.js.map