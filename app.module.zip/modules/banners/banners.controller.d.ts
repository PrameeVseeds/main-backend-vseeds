import { ConfigService } from '@nestjs/config';
import { BannersService } from './banners.service';
import { CreateBannerDto } from './dto/create-banner.dto';
import { BannerQueryDto } from './dto/banner-query.dto';
interface UpdateBannerRequest {
    title?: string;
    deviceType?: string;
    linkUrl?: string;
    displayOrder?: string | number;
    isActive?: string | boolean;
    startsAt?: string | null;
    endsAt?: string | null;
}
export declare class BannersController {
    private readonly bannersService;
    private readonly configService;
    constructor(bannersService: BannersService, configService: ConfigService);
    findAll(query: BannerQueryDto): Promise<import("./dto/banner-response.dto").BannerResponseDto[]>;
    findById(id: string): Promise<import("./dto/banner-response.dto").BannerResponseDto>;
    create(file: Express.Multer.File, dto: CreateBannerDto): Promise<import("./dto/banner-response.dto").BannerResponseDto>;
    update(id: string, file: Express.Multer.File | undefined, dto: UpdateBannerRequest): Promise<import("./dto/banner-response.dto").BannerResponseDto>;
    updateStatus(id: string, active: boolean): Promise<import("./dto/banner-response.dto").BannerResponseDto>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
export {};
