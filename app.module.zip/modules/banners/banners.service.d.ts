import { PrismaService } from '../../prisma/prisma.service';
import { BannerQueryDto } from './dto/banner-query.dto';
import { BannerResponseDto } from './dto/banner-response.dto';
import { DeviceType, Prisma } from '@prisma/client';
export declare class BannersService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    deleteBannerImage(imageUrl: string): Promise<void>;
    private toResponseDto;
    findAll(query: BannerQueryDto): Promise<BannerResponseDto[]>;
    findById(id: string): Promise<BannerResponseDto>;
    create(imageUrl: string, deviceType: DeviceType, isActive?: boolean, title?: string, linkUrl?: string, displayOrder?: number, startsAt?: Date, endsAt?: Date): Promise<BannerResponseDto>;
    updateStatus(id: string, isActive: boolean): Promise<BannerResponseDto>;
    update(id: string, data: Prisma.BannerUpdateInput): Promise<BannerResponseDto>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
