"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const bcrypt = __importStar(require("bcryptjs"));
const encryption_service_1 = require("../../common/services/encryption.service");
const lookup_hash_util_1 = require("../../common/utils/lookup-hash.util");
const SALT_ROUNDS = 12;
let UsersService = class UsersService {
    prisma;
    encryptionService;
    constructor(prisma, encryptionService) {
        this.prisma = prisma;
        this.encryptionService = encryptionService;
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const [users, total] = await Promise.all([
            this.prisma.user.findMany({
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.user.count(),
        ]);
        const userIds = users.map((u) => u.id);
        let orderStatsMap = {};
        if (userIds.length > 0) {
            const orderStats = await this.prisma.order.groupBy({
                by: ['userId'],
                _count: { _all: true },
                _sum: { totalAmount: true },
                where: {
                    userId: { in: userIds },
                    deletedAt: null,
                },
            });
            orderStatsMap = orderStats.reduce((acc, row) => {
                acc[row.userId ?? ''] = {
                    orderCount: row._count._all || 0,
                    totalSpent: Number(row._sum.totalAmount) || 0,
                };
                return acc;
            }, {});
        }
        return {
            users: users.map((u) => {
                const stats = orderStatsMap[u.id] || { orderCount: 0, totalSpent: 0 };
                return {
                    id: u.id,
                    email: this.encryptionService.decrypt(u.email),
                    firstName: u.firstName,
                    lastName: u.lastName,
                    phone: u.phone,
                    status: u.status,
                    isActive: u.status === 'active',
                    createdAt: u.createdAt,
                    orderCount: stats.orderCount,
                    totalSpent: stats.totalSpent,
                };
            }),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async count() {
        const [total, active, inactive] = await this.prisma.$transaction([
            this.prisma.user.count(),
            this.prisma.user.count({ where: { status: 'active' } }),
            this.prisma.user.count({ where: { status: 'inactive' } }),
        ]);
        return { total, active, inactive };
    }
    async search(query, pagination) {
        const { page = 1, limit = 10 } = pagination;
        const or = [
            { firstName: { contains: query } },
            { lastName: { contains: query } },
        ];
        if ((0, lookup_hash_util_1.isLikelyEmail)(query)) {
            or.push({ emailLookup: (0, lookup_hash_util_1.createLookupHash)(query, 'email') });
        }
        const where = { OR: or };
        const [users, total] = await Promise.all([
            this.prisma.user.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.user.count({ where }),
        ]);
        return {
            users: users.map((u) => ({
                id: u.id,
                email: this.encryptionService.decrypt(u.email),
                firstName: u.firstName,
                lastName: u.lastName,
                phone: u.phone,
                status: u.status,
                createdAt: u.createdAt,
            })),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async findById(id) {
        return this.prisma.user.findUnique({
            where: { id },
            include: { addresses: true },
        });
    }
    async findByEmail(email) {
        return this.prisma.user.findUnique({
            where: { emailLookup: (0, lookup_hash_util_1.createLookupHash)(email, 'email') },
        });
    }
    async getProfile(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            include: { addresses: true },
        });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        return {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            phone: user.phone,
            twoFactorEnabled: user.twoFactorEnabled,
            status: user.status,
            isActive: user.status === 'active',
            createdAt: user.createdAt,
        };
    }
    async updateProfile(userId, dto) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        const updateData = {};
        if (dto.firstName !== undefined)
            updateData.firstName = dto.firstName;
        if (dto.lastName !== undefined)
            updateData.lastName = dto.lastName;
        if (dto.phone !== undefined)
            updateData.phone = dto.phone;
        await this.prisma.user.update({
            where: { id: userId },
            data: updateData,
        });
        return this.getProfile(userId);
    }
    async updateStatus(userId, dto) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        await this.prisma.user.update({
            where: { id: userId },
            data: { status: dto.status },
        });
        return {
            message: `User status successfully updated to ${dto.status}`,
            status: dto.status,
        };
    }
    async updatePassword(userId, dto) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        const valid = await bcrypt.compare(dto.currentPassword, user.passwordHash);
        if (!valid)
            throw new common_1.UnauthorizedException('Current password is incorrect');
        const hashed = await bcrypt.hash(dto.newPassword, SALT_ROUNDS);
        await this.prisma.user.update({
            where: { id: userId },
            data: { passwordHash: hashed },
        });
        return { message: 'Password updated successfully' };
    }
    async getAddresses(userId) {
        const list = await this.prisma.userAddress.findMany({
            where: { userId },
            orderBy: { id: 'desc' },
        });
        return list.map((a) => this.toAddressResponseDto(a));
    }
    toAddressResponseDto(a) {
        return {
            id: a.id,
            label: a.label ? this.encryptionService.decrypt(a.label) : undefined,
            fullName: this.encryptionService.decrypt(a.fullName ?? ''),
            email: a.email ? this.encryptionService.decrypt(a.email) : undefined,
            phone: this.encryptionService.decrypt(a.phone ?? ''),
            addressLine1: this.encryptionService.decrypt(a.addressLine1 ?? ''),
            addressLine2: a.addressLine2 ? this.encryptionService.decrypt(a.addressLine2) : undefined,
            city: a.city ? this.encryptionService.decrypt(a.city) : undefined,
            district: this.encryptionService.decrypt(a.district ?? ''),
            province: this.encryptionService.decrypt(a.province ?? ''),
            postalCode: this.encryptionService.decrypt(a.postalCode ?? ''),
            isDefault: a.isDefault,
            createdAt: a.createdAt.toISOString(),
            updatedAt: a.updatedAt.toISOString(),
        };
    }
    async createAddress(userId, dto) {
        const saved = await this.prisma.userAddress.create({
            data: { userId, ...dto },
        });
        return this.toAddressResponseDto(saved);
    }
    async updateAddress(userId, addressId, dto) {
        const address = await this.prisma.userAddress.findFirst({
            where: { id: addressId, userId },
        });
        if (!address)
            throw new common_1.NotFoundException('Address not found');
        const saved = await this.prisma.userAddress.update({
            where: { id: addressId },
            data: dto,
        });
        return this.toAddressResponseDto(saved);
    }
    async deleteAddress(userId, addressId) {
        const address = await this.prisma.userAddress.findFirst({
            where: { id: addressId, userId },
        });
        if (!address)
            throw new common_1.NotFoundException('Address not found');
        await this.prisma.userAddress.delete({
            where: { id: addressId },
        });
        return { message: 'Address deleted' };
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService])
], UsersService);
//# sourceMappingURL=users.service.js.map