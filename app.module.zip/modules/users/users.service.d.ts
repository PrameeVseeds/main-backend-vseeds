import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../../common/services/encryption.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UpdatePasswordDto } from './dto/update-password.dto';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
import { AddressResponseDto } from './dto/address-response.dto';
import { UpdateUserStatusDto } from './dto/update-user-status.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class UsersService {
    private readonly prisma;
    private readonly encryptionService;
    constructor(prisma: PrismaService, encryptionService: EncryptionService);
    findAll(pagination: PaginationDto): Promise<{
        users: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            phone: string | null;
            status: import(".prisma/client").$Enums.UserStatus;
            isActive: boolean;
            createdAt: Date;
            orderCount: number;
            totalSpent: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    count(): Promise<{
        total: number;
        active: number;
        inactive: number;
    }>;
    search(query: string, pagination: PaginationDto): Promise<{
        users: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            phone: string | null;
            status: import(".prisma/client").$Enums.UserStatus;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    findById(id: string): Promise<({
        addresses: {
            deletedAt: Date | null;
            id: string;
            userId: string;
            label: string | null;
            fullName: string;
            email: string | null;
            phone: string;
            addressLine1: string;
            addressLine2: string | null;
            city: string | null;
            district: string;
            province: string;
            postalCode: string;
            country: string;
            isDefault: boolean;
            createdAt: Date;
            updatedAt: Date;
        }[];
    } & {
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        firstName: string;
        lastName: string;
        emailLookup: string;
        passwordHash: string;
        status: import(".prisma/client").$Enums.UserStatus;
        twoFactorSecret: string | null;
        twoFactorEnabled: boolean;
        lastLoginAt: Date | null;
        refreshToken: string | null;
        resetToken: string | null;
    }) | null>;
    findByEmail(email: string): Promise<{
        deletedAt: Date | null;
        id: string;
        email: string;
        phone: string | null;
        createdAt: Date;
        updatedAt: Date;
        firstName: string;
        lastName: string;
        emailLookup: string;
        passwordHash: string;
        status: import(".prisma/client").$Enums.UserStatus;
        twoFactorSecret: string | null;
        twoFactorEnabled: boolean;
        lastLoginAt: Date | null;
        refreshToken: string | null;
        resetToken: string | null;
    } | null>;
    getProfile(userId: string): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        twoFactorEnabled: boolean;
        status: import(".prisma/client").$Enums.UserStatus;
        isActive: boolean;
        createdAt: Date;
    }>;
    updateProfile(userId: string, dto: UpdateProfileDto): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        twoFactorEnabled: boolean;
        status: import(".prisma/client").$Enums.UserStatus;
        isActive: boolean;
        createdAt: Date;
    }>;
    updateStatus(userId: string, dto: UpdateUserStatusDto): Promise<{
        message: string;
        status: string;
    }>;
    updatePassword(userId: string, dto: UpdatePasswordDto): Promise<{
        message: string;
    }>;
    getAddresses(userId: string): Promise<AddressResponseDto[]>;
    private toAddressResponseDto;
    createAddress(userId: string, dto: CreateAddressDto): Promise<AddressResponseDto>;
    updateAddress(userId: string, addressId: string, dto: UpdateAddressDto): Promise<AddressResponseDto>;
    deleteAddress(userId: string, addressId: string): Promise<{
        message: string;
    }>;
}
