import { UsersService } from './users.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UpdatePasswordDto } from './dto/update-password.dto';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
import { UpdateUserStatusDto } from './dto/update-user-status.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    findAll(pagination: PaginationDto): Promise<{
        users: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            phone: string | null;
            status: import(".prisma/client").$Enums.UserStatus;
            isActive: boolean;
            createdAt: Date;
            orderCount: number;
            totalSpent: number;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    search(query: string, pagination: PaginationDto): Promise<{
        users: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            phone: string | null;
            status: import(".prisma/client").$Enums.UserStatus;
            createdAt: Date;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    updateStatus(id: string, dto: UpdateUserStatusDto): Promise<{
        message: string;
        status: string;
    }>;
    count(): Promise<{
        total: number;
        active: number;
        inactive: number;
    }>;
    getProfile(user: JwtPayload): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        twoFactorEnabled: boolean;
        status: import(".prisma/client").$Enums.UserStatus;
        isActive: boolean;
        createdAt: Date;
    }>;
    updateProfile(user: JwtPayload, dto: UpdateProfileDto): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        twoFactorEnabled: boolean;
        status: import(".prisma/client").$Enums.UserStatus;
        isActive: boolean;
        createdAt: Date;
    }>;
    updatePassword(user: JwtPayload, dto: UpdatePasswordDto): Promise<{
        message: string;
    }>;
    getAddresses(user: JwtPayload): Promise<import("./dto/address-response.dto").AddressResponseDto[]>;
    createAddress(user: JwtPayload, dto: CreateAddressDto): Promise<import("./dto/address-response.dto").AddressResponseDto>;
    updateAddress(user: JwtPayload, id: string, dto: UpdateAddressDto): Promise<import("./dto/address-response.dto").AddressResponseDto>;
    deleteAddress(user: JwtPayload, id: string): Promise<{
        message: string;
    }>;
}
