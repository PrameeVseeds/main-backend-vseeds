export declare class CreateAddressDto {
    label?: string;
    fullName: string;
    email?: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city?: string;
    district: string;
    province: string;
    postalCode: string;
    country?: string;
    isDefault?: boolean;
}
