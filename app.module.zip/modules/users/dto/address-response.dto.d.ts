export declare class AddressResponseDto {
    id: string;
    label?: string;
    fullName: string;
    email?: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city?: string;
    district: string;
    province: string;
    postalCode: string;
    isDefault?: boolean;
    createdAt: string;
    updatedAt: string;
}
