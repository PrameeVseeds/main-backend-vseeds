import { DeliveriesService } from './deliveries.service';
import type { JwtPayload } from '../auth/strategies/jwt.strategy';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class DeliveriesController {
    private readonly deliveriesService;
    constructor(deliveriesService: DeliveriesService);
    findByTracking(trackingNumber: string): Promise<import("./dto/shipment-response.dto").ShipmentResponseDto>;
    findByOrderId(orderId: string, user: JwtPayload): Promise<{
        order: {
            deletedAt: Date | null;
            promoCode: string | null;
            id: string;
            userId: string;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.OrderStatus;
            orderNumber: string;
            shippingAddressId: string | null;
            orderType: import(".prisma/client").$Enums.OrderType;
            quoteId: string | null;
            subtotal: import("@prisma/client/runtime/library").Decimal;
            shippingFee: import("@prisma/client/runtime/library").Decimal;
            taxAmount: import("@prisma/client/runtime/library").Decimal;
            discountAmount: import("@prisma/client/runtime/library").Decimal;
            promoCodeId: string | null;
            totalAmount: import("@prisma/client/runtime/library").Decimal;
            customerNotes: string | null;
            adminNotes: string | null;
            version: number;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        shippingFee: import("@prisma/client/runtime/library").Decimal;
        orderId: string;
        trackingNumber: string | null;
        carrier: string | null;
        shippedAt: Date | null;
        expectedDeliveryAt: Date | null;
        deliveredAt: Date | null;
    }>;
    getDeliveryAddress(orderId: string): Promise<{
        address_line1: string;
        address_line2: string | null;
        city: string | null;
        district: string;
        province: string;
        postal_code: string;
        country: string;
        phone: string;
        email: string;
        firstName: string;
        lastName: string;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        shipments: {
            id: string;
            orderId: string;
            orderNumber: string;
            trackingNumber: string | null;
            carrier: string | null;
            shippedAt: Date | null;
            expectedDeliveryAt: Date | null;
            deliveredAt: Date | null;
            shippingFee: import("@prisma/client/runtime/library").Decimal;
            orderStatus: import(".prisma/client").$Enums.OrderStatus;
            userEmail: string;
            firstName: string;
            lastName: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    getOrdersReadyForShipping(pagination: PaginationDto): Promise<{
        orders: {
            id: string;
            orderNumber: string;
            createdAt: Date;
            totalAmount: import("@prisma/client/runtime/library").Decimal;
            status: import(".prisma/client").$Enums.OrderStatus;
            userEmail: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
}
