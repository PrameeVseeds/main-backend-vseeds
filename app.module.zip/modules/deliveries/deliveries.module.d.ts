export declare class DeliveriesModule {
}
