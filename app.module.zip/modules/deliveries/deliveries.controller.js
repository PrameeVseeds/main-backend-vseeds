"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeliveriesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const deliveries_service_1 = require("./deliveries.service");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const pagination_dto_1 = require("../../common/dto/pagination.dto");
let DeliveriesController = class DeliveriesController {
    deliveriesService;
    constructor(deliveriesService) {
        this.deliveriesService = deliveriesService;
    }
    findByTracking(trackingNumber) {
        return this.deliveriesService.findByTracking(trackingNumber);
    }
    findByOrderId(orderId, user) {
        return this.deliveriesService.findByOrderId(orderId, user.id);
    }
    getDeliveryAddress(orderId) {
        return this.deliveriesService.getDeliveryAddress(orderId);
    }
    findAll(pagination) {
        return this.deliveriesService.findAll(pagination);
    }
    getOrdersReadyForShipping(pagination) {
        return this.deliveriesService.getOrdersReadyForShipping(pagination);
    }
};
exports.DeliveriesController = DeliveriesController;
__decorate([
    (0, common_1.Get)('tracking'),
    (0, swagger_1.ApiOperation)({ summary: 'Get delivery by tracking number' }),
    (0, swagger_1.ApiQuery)({ name: 'number', required: true }),
    openapi.ApiResponse({ status: 200, type: require("./dto/shipment-response.dto").ShipmentResponseDto }),
    __param(0, (0, common_1.Query)('number')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], DeliveriesController.prototype, "findByTracking", null);
__decorate([
    (0, common_1.Get)('order_id/:orderId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get delivery by order ID' }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], DeliveriesController.prototype, "findByOrderId", null);
__decorate([
    (0, common_1.Get)('address/:orderId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get delivery address for order' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('orderId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], DeliveriesController.prototype, "getDeliveryAddress", null);
__decorate([
    (0, common_1.Get)('all'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all deliveries (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pagination_dto_1.PaginationDto]),
    __metadata("design:returntype", void 0)
], DeliveriesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('orders'),
    (0, roles_decorator_1.Roles)('admin', 'super admin'),
    (0, swagger_1.ApiOperation)({ summary: 'Get orders ready for shipping (admin)' }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pagination_dto_1.PaginationDto]),
    __metadata("design:returntype", void 0)
], DeliveriesController.prototype, "getOrdersReadyForShipping", null);
exports.DeliveriesController = DeliveriesController = __decorate([
    (0, swagger_1.ApiTags)('Deliveries'),
    (0, common_1.Controller)('delivery'),
    __metadata("design:paramtypes", [deliveries_service_1.DeliveriesService])
], DeliveriesController);
//# sourceMappingURL=deliveries.controller.js.map