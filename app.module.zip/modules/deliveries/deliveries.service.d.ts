import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { ShipmentResponseDto } from './dto/shipment-response.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class DeliveriesService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findByTracking(trackingNumber: string): Promise<ShipmentResponseDto>;
    findByOrderId(orderId: string, userId?: string): Promise<{
        order: {
            deletedAt: Date | null;
            promoCode: string | null;
            id: string;
            userId: string;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.OrderStatus;
            orderNumber: string;
            shippingAddressId: string | null;
            orderType: import(".prisma/client").$Enums.OrderType;
            quoteId: string | null;
            subtotal: Prisma.Decimal;
            shippingFee: Prisma.Decimal;
            taxAmount: Prisma.Decimal;
            discountAmount: Prisma.Decimal;
            promoCodeId: string | null;
            totalAmount: Prisma.Decimal;
            customerNotes: string | null;
            adminNotes: string | null;
            version: number;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        shippingFee: Prisma.Decimal;
        orderId: string;
        trackingNumber: string | null;
        carrier: string | null;
        shippedAt: Date | null;
        expectedDeliveryAt: Date | null;
        deliveredAt: Date | null;
    }>;
    getDeliveryAddress(orderId: string): Promise<{
        address_line1: string;
        address_line2: string | null;
        city: string | null;
        district: string;
        province: string;
        postal_code: string;
        country: string;
        phone: string;
        email: string;
        firstName: string;
        lastName: string;
    }>;
    findAll(pagination: PaginationDto): Promise<{
        shipments: {
            id: string;
            orderId: string;
            orderNumber: string;
            trackingNumber: string | null;
            carrier: string | null;
            shippedAt: Date | null;
            expectedDeliveryAt: Date | null;
            deliveredAt: Date | null;
            shippingFee: Prisma.Decimal;
            orderStatus: import(".prisma/client").$Enums.OrderStatus;
            userEmail: string;
            firstName: string;
            lastName: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
    getOrdersReadyForShipping(pagination: PaginationDto): Promise<{
        orders: {
            id: string;
            orderNumber: string;
            createdAt: Date;
            totalAmount: Prisma.Decimal;
            status: import(".prisma/client").$Enums.OrderStatus;
            userEmail: string;
        }[];
        total: number;
        totalPages: number;
        page: number;
    }>;
}
