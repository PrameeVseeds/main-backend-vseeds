"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeliveriesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let DeliveriesService = class DeliveriesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findByTracking(trackingNumber) {
        const shipment = await this.prisma.shipment.findFirst({
            where: { trackingNumber },
            include: { order: true },
        });
        if (!shipment)
            throw new common_1.NotFoundException('Shipment not found');
        return {
            id: shipment.id,
            orderId: shipment.orderId,
            orderNumber: shipment.order?.orderNumber,
            trackingNumber: shipment.trackingNumber ?? undefined,
            carrier: shipment.carrier ?? undefined,
            shippedAt: shipment.shippedAt?.toISOString(),
            expectedDeliveryAt: shipment.expectedDeliveryAt?.toISOString(),
            deliveredAt: shipment.deliveredAt?.toISOString(),
            shippingFee: Number(shipment.shippingFee),
            createdAt: shipment.createdAt.toISOString(),
            updatedAt: shipment.updatedAt.toISOString(),
        };
    }
    async findByOrderId(orderId, userId) {
        const where = { orderId };
        if (userId) {
            where.order = { userId };
        }
        const shipment = await this.prisma.shipment.findFirst({
            where,
            include: { order: true },
        });
        if (!shipment)
            throw new common_1.NotFoundException('Shipment not found for this order');
        return shipment;
    }
    async getDeliveryAddress(orderId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: {
                user: true,
                shippingAddress: true,
            },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        const addr = order.shippingAddress;
        if (!addr)
            throw new common_1.NotFoundException('Delivery address not found');
        return {
            address_line1: addr.addressLine1,
            address_line2: addr.addressLine2,
            city: addr.city,
            district: addr.district,
            province: addr.province,
            postal_code: addr.postalCode,
            country: addr.country,
            phone: addr.phone,
            email: order.user?.email,
            firstName: order.user?.firstName,
            lastName: order.user?.lastName,
        };
    }
    async findAll(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const [shipments, total] = await Promise.all([
            this.prisma.shipment.findMany({
                include: {
                    order: {
                        include: {
                            user: true,
                        },
                    },
                },
                orderBy: {
                    shippedAt: 'desc',
                },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.shipment.count(),
        ]);
        return {
            shipments: shipments.map((s) => ({
                id: s.id,
                orderId: s.orderId,
                orderNumber: s.order?.orderNumber,
                trackingNumber: s.trackingNumber,
                carrier: s.carrier,
                shippedAt: s.shippedAt,
                expectedDeliveryAt: s.expectedDeliveryAt,
                deliveredAt: s.deliveredAt,
                shippingFee: s.shippingFee,
                orderStatus: s.order?.status,
                userEmail: s.order?.user?.email,
                firstName: s.order?.user?.firstName,
                lastName: s.order?.user?.lastName,
            })),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
    async getOrdersReadyForShipping(pagination) {
        const { page = 1, limit = 10 } = pagination;
        const [orders, total] = await Promise.all([
            this.prisma.order.findMany({
                where: {
                    status: 'processing',
                    payments: {
                        some: {
                            status: 'completed',
                        },
                    },
                    deletedAt: null,
                },
                include: {
                    user: true,
                },
                orderBy: {
                    createdAt: 'desc',
                },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.order.count({
                where: {
                    status: 'processing',
                    payments: {
                        some: {
                            status: 'completed',
                        },
                    },
                    deletedAt: null,
                },
            }),
        ]);
        return {
            orders: orders.map((o) => ({
                id: o.id,
                orderNumber: o.orderNumber,
                createdAt: o.createdAt,
                totalAmount: o.totalAmount,
                status: o.status,
                userEmail: o.user?.email,
            })),
            total,
            totalPages: Math.ceil(total / limit),
            page,
        };
    }
};
exports.DeliveriesService = DeliveriesService;
exports.DeliveriesService = DeliveriesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DeliveriesService);
//# sourceMappingURL=deliveries.service.js.map