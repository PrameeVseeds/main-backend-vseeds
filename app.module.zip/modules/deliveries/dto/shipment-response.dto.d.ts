export declare class ShipmentResponseDto {
    id: string;
    orderId: string;
    orderNumber?: string;
    trackingNumber?: string;
    carrier?: string;
    shippedAt?: string;
    expectedDeliveryAt?: string;
    deliveredAt?: string;
    shippingFee: number;
    createdAt: string;
    updatedAt: string;
}
