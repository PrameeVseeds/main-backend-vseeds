export declare class EncryptionModule {
}
