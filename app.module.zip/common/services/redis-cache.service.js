"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RedisCacheService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisCacheService = void 0;
const common_1 = require("@nestjs/common");
let RedisCacheService = RedisCacheService_1 = class RedisCacheService {
    logger = new common_1.Logger(RedisCacheService_1.name);
    cache = new Map();
    defaultTTL = 3600;
    constructor() {
        this.logger.log('RedisCacheService initialized (In-Memory Cache fallback)');
    }
    onModuleInit() {
        this.logger.log('In-memory cache ready');
    }
    onModuleDestroy() {
        this.cache.clear();
        this.logger.log('In-memory cache cleared');
    }
    get(key) {
        const cached = this.cache.get(key);
        if (!cached)
            return Promise.resolve(null);
        if (Date.now() > cached.expiry) {
            this.cache.delete(key);
            return Promise.resolve(null);
        }
        return Promise.resolve(cached.data);
    }
    set(key, data, ttlMs) {
        const ttl = ttlMs ?? this.defaultTTL;
        const expiry = Date.now() + ttl;
        this.cache.set(key, { data, expiry });
        return Promise.resolve();
    }
    delete(key) {
        this.cache.delete(key);
        return Promise.resolve();
    }
    clear() {
        this.cache.clear();
        return Promise.resolve();
    }
    deletePattern(pattern) {
        const regexPattern = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
        for (const key of this.cache.keys()) {
            if (regexPattern.test(key)) {
                this.cache.delete(key);
            }
        }
        return Promise.resolve();
    }
    exists(key) {
        const cached = this.cache.get(key);
        if (!cached)
            return Promise.resolve(false);
        if (Date.now() > cached.expiry) {
            this.cache.delete(key);
            return Promise.resolve(false);
        }
        return Promise.resolve(true);
    }
    setMany(entries) {
        for (const entry of entries) {
            this.cache.set(entry.key, {
                data: entry.data,
                expiry: Date.now() + (entry.ttl ?? this.defaultTTL),
            });
        }
        return Promise.resolve();
    }
    getMany(keys) {
        const result = new Map();
        for (const key of keys) {
            const cached = this.cache.get(key);
            if (cached && Date.now() <= cached.expiry) {
                result.set(key, cached.data);
            }
        }
        return Promise.resolve(result);
    }
};
exports.RedisCacheService = RedisCacheService;
exports.RedisCacheService = RedisCacheService = RedisCacheService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], RedisCacheService);
//# sourceMappingURL=redis-cache.service.js.map