"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenBlacklistService = void 0;
const common_1 = require("@nestjs/common");
let TokenBlacklistService = class TokenBlacklistService {
    blacklist = new Map();
    onModuleInit() {
        setInterval(() => this.cleanup(), 15 * 60_000);
    }
    revoke(token, expiresInMs = 3 * 60 * 60_000) {
        this.blacklist.set(token, Date.now() + expiresInMs);
    }
    isRevoked(token) {
        const expiry = this.blacklist.get(token);
        if (expiry === undefined)
            return false;
        if (Date.now() > expiry) {
            this.blacklist.delete(token);
            return false;
        }
        return true;
    }
    cleanup() {
        const now = Date.now();
        for (const [token, expiry] of this.blacklist) {
            if (now > expiry)
                this.blacklist.delete(token);
        }
    }
};
exports.TokenBlacklistService = TokenBlacklistService;
exports.TokenBlacklistService = TokenBlacklistService = __decorate([
    (0, common_1.Injectable)()
], TokenBlacklistService);
//# sourceMappingURL=token-blacklist.service.js.map