export declare class MemoryCacheModule {
}
