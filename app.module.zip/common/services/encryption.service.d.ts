import { ConfigService } from '@nestjs/config';
export interface EncryptedData {
    keyId: string;
    iv: string;
    authTag: string;
    data: string;
}
export declare class EncryptionService {
    private readonly configService;
    private readonly logger;
    private readonly algorithm;
    private readonly ivLength;
    private readonly authTagLength;
    private readonly keyId;
    private readonly encryptionKey;
    constructor(configService: ConfigService);
    encrypt(plainText: string): string;
    private decryptLegacyCbc;
    decrypt(cipherText: string): string;
    isEncrypted(value: string): boolean;
    static generateKey(): string;
}
