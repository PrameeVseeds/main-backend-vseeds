import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
export declare class RedisCacheService implements OnModuleInit, OnModuleDestroy {
    private readonly logger;
    private cache;
    private defaultTTL;
    constructor();
    onModuleInit(): void;
    onModuleDestroy(): void;
    get<T>(key: string): Promise<T | null>;
    set<T>(key: string, data: T, ttlMs?: number): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): Promise<void>;
    deletePattern(pattern: string): Promise<void>;
    exists(key: string): Promise<boolean>;
    setMany<T>(entries: Array<{
        key: string;
        data: T;
        ttl?: number;
    }>): Promise<void>;
    getMany<T>(keys: string[]): Promise<Map<string, T>>;
}
