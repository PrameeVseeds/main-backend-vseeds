export declare class RedisCacheModule {
}
