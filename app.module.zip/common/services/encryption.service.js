"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EncryptionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EncryptionService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
let EncryptionService = EncryptionService_1 = class EncryptionService {
    configService;
    logger = new common_1.Logger(EncryptionService_1.name);
    algorithm = 'aes-256-gcm';
    ivLength = 16;
    authTagLength = 16;
    keyId;
    encryptionKey;
    constructor(configService) {
        this.configService = configService;
        const keyBase64 = this.configService.get('ENCRYPTION_KEY');
        this.keyId = this.configService.get('ENCRYPTION_KEY_ID', 'v1');
        if (!keyBase64) {
            this.logger.error('ENCRYPTION_KEY not configured in environment variables');
            throw new Error('Encryption key not configured');
        }
        try {
            this.encryptionKey = Buffer.from(keyBase64, 'base64');
            if (this.encryptionKey.length !== 32) {
                throw new Error(`Invalid key length: ${this.encryptionKey.length} bytes, expected 32 bytes`);
            }
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error('Failed to initialize encryption key', errMsg);
            throw new Error('Invalid encryption key format');
        }
        this.logger.log(`EncryptionService initialized with keyId: ${this.keyId}`);
    }
    encrypt(plainText) {
        if (!plainText) {
            return plainText;
        }
        try {
            const iv = (0, crypto_1.randomBytes)(this.ivLength);
            const cipher = (0, crypto_1.createCipheriv)(this.algorithm, this.encryptionKey, iv);
            let encrypted = cipher.update(plainText, 'utf8', 'base64');
            encrypted += cipher.final('base64');
            const authTag = cipher.getAuthTag();
            const encryptedData = {
                keyId: this.keyId,
                iv: iv.toString('base64'),
                authTag: authTag.toString('base64'),
                data: encrypted,
            };
            return `ENC:${encryptedData.keyId}:${encryptedData.iv}:${encryptedData.authTag}:${encryptedData.data}`;
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error('Encryption failed', errMsg);
            throw new Error('Failed to encrypt data');
        }
    }
    decryptLegacyCbc(ivBase64, data) {
        const iv = Buffer.from(ivBase64, 'base64');
        if (iv.length !== this.ivLength) {
            throw new Error(`Invalid IV length: ${iv.length} bytes`);
        }
        const decipher = (0, crypto_1.createDecipheriv)('aes-256-cbc', this.encryptionKey, iv);
        let decrypted = decipher.update(data, 'base64', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }
    decrypt(cipherText) {
        if (!cipherText || !this.isEncrypted(cipherText)) {
            return cipherText;
        }
        try {
            const parts = cipherText.split(':');
            if (parts.length === 5) {
                const [, keyId, ivBase64, authTagBase64, data] = parts;
                if (keyId !== this.keyId) {
                    this.logger.warn(`Key ID mismatch: expected ${this.keyId}, got ${keyId}`);
                }
                const iv = Buffer.from(ivBase64, 'base64');
                const authTag = Buffer.from(authTagBase64, 'base64');
                if (iv.length !== this.ivLength) {
                    throw new Error(`Invalid IV length: ${iv.length} bytes`);
                }
                if (authTag.length !== this.authTagLength) {
                    throw new Error(`Invalid auth tag length: ${authTag.length} bytes`);
                }
                const decipher = (0, crypto_1.createDecipheriv)(this.algorithm, this.encryptionKey, iv);
                decipher.setAuthTag(authTag);
                let decrypted = decipher.update(data, 'base64', 'utf8');
                decrypted += decipher.final('utf8');
                return decrypted;
            }
            else if (parts.length === 4) {
                const [, , ivBase64, data] = parts;
                return this.decryptLegacyCbc(ivBase64, data);
            }
            else {
                this.logger.error('Invalid encrypted data format');
                throw new Error('Invalid encrypted data format');
            }
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : String(error);
            this.logger.error('Decryption failed', errMsg);
            throw new Error('Failed to decrypt data');
        }
    }
    isEncrypted(value) {
        return typeof value === 'string' && value.startsWith('ENC:');
    }
    static generateKey() {
        return (0, crypto_1.randomBytes)(32).toString('base64');
    }
};
exports.EncryptionService = EncryptionService;
exports.EncryptionService = EncryptionService = EncryptionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], EncryptionService);
//# sourceMappingURL=encryption.service.js.map