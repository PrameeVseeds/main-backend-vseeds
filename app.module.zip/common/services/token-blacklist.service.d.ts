import { OnModuleInit } from '@nestjs/common';
export declare class TokenBlacklistService implements OnModuleInit {
    private readonly blacklist;
    onModuleInit(): void;
    revoke(token: string, expiresInMs?: number): void;
    isRevoked(token: string): boolean;
    private cleanup;
}
