export declare class TokenBlacklistModule {
}
