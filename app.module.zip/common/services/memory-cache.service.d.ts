export declare class MemoryCacheService {
    private cache;
    get<T>(key: string): T | null;
    set<T>(key: string, data: T, ttlMs: number): void;
    delete(key: string): void;
    clear(): void;
}
