"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SanitizationPipe = void 0;
const common_1 = require("@nestjs/common");
let SanitizationPipe = class SanitizationPipe {
    transform(value, metadata) {
        if (metadata.type === 'body' && value && typeof value === 'object') {
            return this.sanitizeObject(value);
        }
        return value;
    }
    sanitizeObject(obj) {
        if (Array.isArray(obj)) {
            return obj.map((item) => this.sanitizeObject(item));
        }
        if (obj && typeof obj === 'object') {
            const record = obj;
            const sanitized = {};
            for (const key of Object.keys(record)) {
                const val = record[key];
                if (typeof val === 'string') {
                    sanitized[key] = this.sanitizeString(key, val);
                }
                else if (typeof val === 'object' && val !== null) {
                    sanitized[key] = this.sanitizeObject(val);
                }
                else {
                    sanitized[key] = val;
                }
            }
            return sanitized;
        }
        return obj;
    }
    sanitizeString(key, val) {
        const richTextFields = [
            'content',
            'htmlBody',
            'html',
            'description',
            'specifications',
        ];
        if (richTextFields.includes(key)) {
            return val
                .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/on\w+\s*=\s*(['"])(.*?)\1/gi, '');
        }
        return val.replace(/<[^>]*>/g, '');
    }
};
exports.SanitizationPipe = SanitizationPipe;
exports.SanitizationPipe = SanitizationPipe = __decorate([
    (0, common_1.Injectable)()
], SanitizationPipe);
//# sourceMappingURL=sanitization.pipe.js.map