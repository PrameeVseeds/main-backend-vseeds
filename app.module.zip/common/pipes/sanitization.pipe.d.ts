import { PipeTransform, ArgumentMetadata } from '@nestjs/common';
export declare class SanitizationPipe implements PipeTransform {
    transform(value: unknown, metadata: ArgumentMetadata): unknown;
    private sanitizeObject;
    private sanitizeString;
}
