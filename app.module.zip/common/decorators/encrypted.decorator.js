"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENCRYPTED_METADATA_KEY = void 0;
exports.Encrypted = Encrypted;
exports.getEncryptedFields = getEncryptedFields;
exports.isEncryptedField = isEncryptedField;
require("reflect-metadata");
exports.ENCRYPTED_METADATA_KEY = 'encrypted:fields';
function Encrypted() {
    return (target, propertyKey) => {
        const existingFields = Reflect.getMetadata(exports.ENCRYPTED_METADATA_KEY, target) || [];
        const fields = [...existingFields, propertyKey];
        Reflect.defineMetadata(exports.ENCRYPTED_METADATA_KEY, fields, target);
    };
}
function getEncryptedFields(target) {
    return (Reflect.getMetadata(exports.ENCRYPTED_METADATA_KEY, target) || []);
}
function isEncryptedField(target, propertyKey) {
    const fields = getEncryptedFields(target);
    return fields.includes(propertyKey);
}
//# sourceMappingURL=encrypted.decorator.js.map