"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Privileges = exports.PRIVILEGES_KEY = void 0;
const common_1 = require("@nestjs/common");
exports.PRIVILEGES_KEY = 'privileges';
const Privileges = (...privileges) => (0, common_1.SetMetadata)(exports.PRIVILEGES_KEY, privileges);
exports.Privileges = Privileges;
//# sourceMappingURL=privileges.decorator.js.map