import 'reflect-metadata';
export declare const ENCRYPTED_METADATA_KEY = "encrypted:fields";
export declare function Encrypted(): PropertyDecorator;
export declare function getEncryptedFields(target: object): string[];
export declare function isEncryptedField(target: object, propertyKey: string | symbol): boolean;
