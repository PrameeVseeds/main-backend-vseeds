export declare const PRIVILEGES_KEY = "privileges";
export declare const Privileges: (...privileges: string[]) => import("@nestjs/common").CustomDecorator<string>;
