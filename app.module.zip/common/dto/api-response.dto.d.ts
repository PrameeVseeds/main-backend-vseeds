export declare class ApiResponseDto<T = any> {
    statusCode: number;
    message: string;
    data?: T;
    timestamp: string;
}
export declare class ApiErrorResponseDto {
    statusCode: number;
    message: string;
    errors?: string[];
    timestamp: string;
}
