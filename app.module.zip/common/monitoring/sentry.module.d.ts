export declare class SentryModule {
    constructor();
}
