export interface FileValidationResult {
    valid: boolean;
    error?: string;
    detectedMime?: string;
}
export declare function validateImageUpload(buffer: Buffer, mimetype: string | undefined, options?: {
    maxSize?: number;
}): FileValidationResult;
export declare const FILE_UPLOAD_LIMITS: {
    readonly image: number;
    readonly banner: number;
};
