export type LookupFieldKind = 'email' | 'username' | 'promo_code';
export declare function createLookupHash(value: string, kind: LookupFieldKind): string;
export declare function isLikelyEmail(query: string): boolean;
