"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createLookupHash = createLookupHash;
exports.isLikelyEmail = isLikelyEmail;
const crypto_1 = require("crypto");
function normalizeForLookup(value, kind) {
    const trimmed = value.trim();
    switch (kind) {
        case 'email':
            return trimmed.toLowerCase();
        case 'username':
            return trimmed.toLowerCase();
        case 'promo_code':
            return trimmed.toUpperCase();
        default:
            return trimmed;
    }
}
function createLookupHash(value, kind) {
    if (!value) {
        throw new Error(`Cannot create lookup hash for empty ${kind}`);
    }
    const normalized = normalizeForLookup(value, kind);
    return (0, crypto_1.createHash)('sha256').update(normalized, 'utf8').digest('hex');
}
function isLikelyEmail(query) {
    return query.includes('@');
}
//# sourceMappingURL=lookup-hash.util.js.map