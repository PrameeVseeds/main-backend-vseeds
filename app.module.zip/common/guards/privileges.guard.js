"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrivilegesGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const prisma_service_1 = require("../../prisma/prisma.service");
const privileges_decorator_1 = require("../decorators/privileges.decorator");
let PrivilegesGuard = class PrivilegesGuard {
    reflector;
    prisma;
    constructor(reflector, prisma) {
        this.reflector = reflector;
        this.prisma = prisma;
    }
    async canActivate(context) {
        const required = this.reflector.getAllAndOverride(privileges_decorator_1.PRIVILEGES_KEY, [context.getHandler(), context.getClass()]);
        if (!required || required.length === 0) {
            return true;
        }
        const request = context
            .switchToHttp()
            .getRequest();
        const user = request.user;
        if (!user?.role)
            return false;
        const role = await this.prisma.role.findUnique({
            where: { name: user.role },
        });
        if (!role)
            return false;
        const rolePrivileges = await this.prisma.rolePrivilege.findMany({
            where: { roleId: role.id, isActive: true },
            include: { privilege: true },
        });
        const userPrivileges = rolePrivileges.map((rp) => rp.privilege.name);
        return required.some((p) => userPrivileges.includes(p));
    }
};
exports.PrivilegesGuard = PrivilegesGuard;
exports.PrivilegesGuard = PrivilegesGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector,
        prisma_service_1.PrismaService])
], PrivilegesGuard);
//# sourceMappingURL=privileges.guard.js.map