export { UserType, UserStatus, AdminStatus } from './user-type.enum';
export declare enum RoleName {
    USER = "user",
    ADMIN = "admin",
    SUPER_ADMIN = "super admin",
    EMPLOYEE = "employee"
}
