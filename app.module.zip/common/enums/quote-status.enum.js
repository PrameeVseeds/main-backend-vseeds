"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceType = exports.QuoteStatus = void 0;
var QuoteStatus;
(function (QuoteStatus) {
    QuoteStatus["PENDING"] = "pending";
    QuoteStatus["QUOTED"] = "quoted";
    QuoteStatus["APPROVED"] = "approved";
    QuoteStatus["DECLINED"] = "declined";
    QuoteStatus["PAID"] = "paid";
    QuoteStatus["CANCELLED"] = "cancelled";
})(QuoteStatus || (exports.QuoteStatus = QuoteStatus = {}));
var ServiceType;
(function (ServiceType) {
    ServiceType["STANDARD_PCB"] = "standard_pcb";
    ServiceType["ADVANCED_PCB"] = "advanced_pcb";
    ServiceType["FPC_RIGID_FLEX"] = "fpc_rigid_flex";
    ServiceType["PCB_ASSEMBLY"] = "pcb_assembly";
    ServiceType["SMD_STENCIL"] = "smd_stencil";
})(ServiceType || (exports.ServiceType = ServiceType = {}));
//# sourceMappingURL=quote-status.enum.js.map