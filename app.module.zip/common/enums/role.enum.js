"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleName = exports.AdminStatus = exports.UserStatus = exports.UserType = void 0;
var user_type_enum_1 = require("./user-type.enum");
Object.defineProperty(exports, "UserType", { enumerable: true, get: function () { return user_type_enum_1.UserType; } });
Object.defineProperty(exports, "UserStatus", { enumerable: true, get: function () { return user_type_enum_1.UserStatus; } });
Object.defineProperty(exports, "AdminStatus", { enumerable: true, get: function () { return user_type_enum_1.AdminStatus; } });
var RoleName;
(function (RoleName) {
    RoleName["USER"] = "user";
    RoleName["ADMIN"] = "admin";
    RoleName["SUPER_ADMIN"] = "super admin";
    RoleName["EMPLOYEE"] = "employee";
})(RoleName || (exports.RoleName = RoleName = {}));
//# sourceMappingURL=role.enum.js.map