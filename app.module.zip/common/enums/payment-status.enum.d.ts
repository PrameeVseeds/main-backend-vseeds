export declare enum PaymentStatus {
    PENDING = "pending",
    COMPLETED = "completed",
    FAILED = "failed",
    REFUNDED = "refunded"
}
export declare enum PaymentMethod {
    BANK_TRANSFER = "bank_transfer",
    CASH = "cash",
    ONLINE = "online"
}
