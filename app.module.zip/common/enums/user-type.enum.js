"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminStatus = exports.UserStatus = exports.UserType = void 0;
var UserType;
(function (UserType) {
    UserType["USER"] = "user";
    UserType["ADMIN"] = "admin";
    UserType["SYSTEM"] = "system";
})(UserType || (exports.UserType = UserType = {}));
var UserStatus;
(function (UserStatus) {
    UserStatus["ACTIVE"] = "active";
    UserStatus["INACTIVE"] = "inactive";
    UserStatus["SUSPENDED"] = "suspended";
})(UserStatus || (exports.UserStatus = UserStatus = {}));
var AdminStatus;
(function (AdminStatus) {
    AdminStatus["ACTIVE"] = "active";
    AdminStatus["INACTIVE"] = "inactive";
    AdminStatus["SUSPENDED"] = "suspended";
})(AdminStatus || (exports.AdminStatus = AdminStatus = {}));
//# sourceMappingURL=user-type.enum.js.map