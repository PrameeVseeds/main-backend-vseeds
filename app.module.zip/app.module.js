"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const schedule_1 = require("@nestjs/schedule");
const throttler_1 = require("@nestjs/throttler");
const env_validation_1 = require("./config/env.validation");
const jwt_auth_guard_1 = require("./common/guards/jwt-auth.guard");
const roles_guard_1 = require("./common/guards/roles.guard");
const privileges_guard_1 = require("./common/guards/privileges.guard");
const http_exception_filter_1 = require("./common/filters/http-exception.filter");
const response_interceptor_1 = require("./common/interceptors/response.interceptor");
const request_id_interceptor_1 = require("./common/interceptors/request-id.interceptor");
const activity_logging_interceptor_1 = require("./modules/activity-logs/activity-logging.interceptor");
const auth_module_1 = require("./modules/auth/auth.module");
const users_module_1 = require("./modules/users/users.module");
const admins_module_1 = require("./modules/admins/admins.module");
const roles_module_1 = require("./modules/roles/roles.module");
const health_module_1 = require("./modules/health/health.module");
const categories_module_1 = require("./modules/categories/categories.module");
const products_module_1 = require("./modules/products/products.module");
const images_module_1 = require("./modules/images/images.module");
const orders_module_1 = require("./modules/orders/orders.module");
const payments_module_1 = require("./modules/payments/payments.module");
const invoices_module_1 = require("./modules/invoices/invoices.module");
const invoice_templates_module_1 = require("./modules/invoice-templates/invoice-templates.module");
const deliveries_module_1 = require("./modules/deliveries/deliveries.module");
const wishlists_module_1 = require("./modules/wishlists/wishlists.module");
const reviews_module_1 = require("./modules/reviews/reviews.module");
const quotes_module_1 = require("./modules/quotes/quotes.module");
const contacts_module_1 = require("./modules/contacts/contacts.module");
const blogs_module_1 = require("./modules/blogs/blogs.module");
const faqs_module_1 = require("./modules/faqs/faqs.module");
const banners_module_1 = require("./modules/banners/banners.module");
const projects_module_1 = require("./modules/projects/projects.module");
const statistics_module_1 = require("./modules/statistics/statistics.module");
const activity_logs_module_1 = require("./modules/activity-logs/activity-logs.module");
const email_templates_module_1 = require("./modules/email-templates/email-templates.module");
const settings_module_1 = require("./modules/settings/settings.module");
const database_module_1 = require("./modules/database/database.module");
const email_module_1 = require("./modules/email/email.module");
const token_blacklist_module_1 = require("./common/services/token-blacklist.module");
const redis_cache_module_1 = require("./common/services/redis-cache.module");
const banks_module_1 = require("./modules/banks/banks.module");
const promo_codes_module_1 = require("./modules/promo-codes/promo-codes.module");
const encryption_module_1 = require("./common/modules/encryption.module");
const sentry_module_1 = require("./common/monitoring/sentry.module");
const prisma_module_1 = require("./prisma/prisma.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                validate: env_validation_1.validate,
            }),
            schedule_1.ScheduleModule.forRoot(),
            throttler_1.ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            admins_module_1.AdminsModule,
            roles_module_1.RolesModule,
            categories_module_1.CategoriesModule,
            products_module_1.ProductsModule,
            images_module_1.ImagesModule,
            orders_module_1.OrdersModule,
            payments_module_1.PaymentsModule,
            invoices_module_1.InvoicesModule,
            invoice_templates_module_1.InvoiceTemplatesModule,
            deliveries_module_1.DeliveriesModule,
            wishlists_module_1.WishlistsModule,
            reviews_module_1.ReviewsModule,
            quotes_module_1.QuotesModule,
            contacts_module_1.ContactsModule,
            blogs_module_1.BlogsModule,
            faqs_module_1.FaqsModule,
            banners_module_1.BannersModule,
            projects_module_1.ProjectsModule,
            statistics_module_1.StatisticsModule,
            activity_logs_module_1.ActivityLogsModule,
            email_templates_module_1.EmailTemplatesModule,
            settings_module_1.SettingsModule,
            database_module_1.DatabaseModule,
            email_module_1.EmailModule,
            health_module_1.HealthModule,
            token_blacklist_module_1.TokenBlacklistModule,
            redis_cache_module_1.RedisCacheModule,
            banks_module_1.BanksModule,
            promo_codes_module_1.PromoCodesModule,
            encryption_module_1.EncryptionModule,
            sentry_module_1.SentryModule,
            prisma_module_1.PrismaModule,
        ],
        providers: [
            { provide: core_1.APP_GUARD, useClass: jwt_auth_guard_1.JwtAuthGuard },
            { provide: core_1.APP_GUARD, useClass: roles_guard_1.RolesGuard },
            { provide: core_1.APP_GUARD, useClass: privileges_guard_1.PrivilegesGuard },
            { provide: core_1.APP_GUARD, useClass: throttler_1.ThrottlerGuard },
            { provide: core_1.APP_FILTER, useClass: http_exception_filter_1.HttpExceptionFilter },
            { provide: core_1.APP_INTERCEPTOR, useClass: request_id_interceptor_1.RequestIdInterceptor },
            { provide: core_1.APP_INTERCEPTOR, useClass: response_interceptor_1.ResponseInterceptor },
            { provide: core_1.APP_INTERCEPTOR, useClass: activity_logging_interceptor_1.ActivityLoggingInterceptor },
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map