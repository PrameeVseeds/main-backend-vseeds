"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.historyExtension = void 0;
const client_1 = require("@prisma/client");
const HISTORY_CLIENT_MAP = {
    User: { historyDelegate: 'userHistory', sourceIdField: 'userId' },
    Admin: { historyDelegate: 'adminHistory', sourceIdField: 'adminId' },
    PromoCode: {
        historyDelegate: 'promoCodeHistory',
        sourceIdField: 'promoCodeId',
    },
    Contact: { historyDelegate: 'contactHistory', sourceIdField: 'contactId' },
};
const SENSITIVE_FIELDS = new Set([
    'passwordHash',
    'twoFactorSecret',
    'refreshToken',
]);
function sanitizeSnapshot(record) {
    const copy = {};
    for (const [key, value] of Object.entries(record)) {
        if (SENSITIVE_FIELDS.has(key))
            continue;
        copy[key] = value;
    }
    return copy;
}
function getRecordId(record) {
    const id = record.id;
    return typeof id === 'string' ? id : null;
}
async function writeHistory(baseClient, model, action, record, changedBy) {
    const config = HISTORY_CLIENT_MAP[model];
    if (!config)
        return;
    const recordId = getRecordId(record);
    if (!recordId)
        return;
    const delegate = baseClient[config.historyDelegate];
    if (!delegate?.create)
        return;
    await delegate.create({
        data: {
            [config.sourceIdField]: recordId,
            action,
            snapshot: sanitizeSnapshot(record),
            changedBy: changedBy ?? null,
        },
    });
}
function extractIdFromWhere(where) {
    if (!where || typeof where !== 'object')
        return null;
    const id = where.id;
    return typeof id === 'string' ? id : null;
}
const historyExtension = (baseClient) => {
    return client_1.Prisma.defineExtension({
        name: 'history',
        query: {
            $allModels: {
                async $allOperations({ model, operation, args, query }) {
                    const config = HISTORY_CLIENT_MAP[model];
                    let previous = null;
                    if (config &&
                        (operation === 'update' ||
                            operation === 'delete' ||
                            operation === 'upsert')) {
                        const recordId = extractIdFromWhere(args?.where);
                        if (recordId) {
                            const camel = model.charAt(0).toLowerCase() + model.slice(1);
                            const modelDelegate = baseClient[camel];
                            if (modelDelegate?.findUnique) {
                                previous = await modelDelegate.findUnique({
                                    where: { id: recordId },
                                });
                            }
                        }
                    }
                    const result = await query(args);
                    if (!config) {
                        return result;
                    }
                    if (operation === 'create' && result && typeof result === 'object') {
                        await writeHistory(baseClient, model, 'INSERT', result);
                    }
                    else if (operation === 'update' &&
                        result &&
                        typeof result === 'object') {
                        await writeHistory(baseClient, model, 'UPDATE', result);
                    }
                    else if (operation === 'delete' && previous) {
                        await writeHistory(baseClient, model, 'DELETE', previous);
                    }
                    else if (operation === 'upsert' &&
                        result &&
                        typeof result === 'object') {
                        await writeHistory(baseClient, model, previous ? 'UPDATE' : 'INSERT', result);
                    }
                    return result;
                },
            },
        },
    });
};
exports.historyExtension = historyExtension;
//# sourceMappingURL=prisma-history.extension.js.map