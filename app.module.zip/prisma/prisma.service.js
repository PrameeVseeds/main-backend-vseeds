"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PrismaService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_soft_delete_extension_1 = require("./prisma-soft-delete.extension");
const prisma_encryption_extension_1 = require("./prisma-encryption.extension");
const prisma_history_extension_1 = require("./prisma-history.extension");
const encryption_service_1 = require("../common/services/encryption.service");
let PrismaService = PrismaService_1 = class PrismaService extends client_1.PrismaClient {
    encryptionService;
    logger = new common_1.Logger(PrismaService_1.name);
    _client;
    _baseClient;
    constructor(encryptionService) {
        super({
            log: [
                { emit: 'event', level: 'error' },
                { emit: 'event', level: 'warn' },
            ],
        });
        this.encryptionService = encryptionService;
        this._baseClient = new client_1.PrismaClient({
            log: [
                { emit: 'event', level: 'error' },
                { emit: 'event', level: 'warn' },
            ],
        });
        this._client = this._baseClient
            .$extends(prisma_soft_delete_extension_1.softDeleteExtension)
            .$extends((0, prisma_encryption_extension_1.encryptionExtension)(this.encryptionService))
            .$extends((0, prisma_history_extension_1.historyExtension)(this._baseClient));
        return new Proxy(this, {
            get: (target, prop) => {
                if (prop in target && !(prop in target._client)) {
                    const val = target[prop];
                    if (typeof val === 'function') {
                        return val.bind(target);
                    }
                    return val;
                }
                const val = target._client[prop];
                if (typeof val === 'function') {
                    return val.bind(target._client);
                }
                return val;
            },
        });
    }
    async onModuleInit() {
        await this._baseClient.$connect();
        await this.$connect();
        this.logger.log('Prisma connected to database (with soft-delete, encryption & history)');
    }
    async onModuleDestroy() {
        await this.$disconnect();
        await this._baseClient.$disconnect();
        this.logger.log('Prisma disconnected from database');
    }
};
exports.PrismaService = PrismaService;
exports.PrismaService = PrismaService = PrismaService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [encryption_service_1.EncryptionService])
], PrismaService);
//# sourceMappingURL=prisma.service.js.map