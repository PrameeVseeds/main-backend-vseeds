export declare const softDeleteExtension: (client: any) => {
    $extends: {
        extArgs: {
            result: {};
            model: {
                $allModels: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                user: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                admin: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                productMedia: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                media: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                userAddress: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                role: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                privilege: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                rolePrivilege: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                activityLog: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                userHistory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                adminHistory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                category: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                subCategory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                product: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                attribute: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                productAttribute: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                productPriceTier: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                order: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                orderItem: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                orderStatusHistory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                orderComment: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                payment: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                shipment: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                invoice: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                invoiceItem: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                invoiceTemplate: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                wishlist: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                productReview: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                quote: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                promoCode: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                promoCodeHistory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                bank: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                blog: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                banner: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                fAQ: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                contact: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                contactHistory: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                contactReply: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                setting: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                project: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
                emailTemplate: {
                    softDelete: () => <T>(this: T, id: string) => Promise<unknown>;
                    restore: () => <T>(this: T, id: string) => Promise<unknown>;
                };
            };
            query: {};
            client: {};
        };
    };
};
