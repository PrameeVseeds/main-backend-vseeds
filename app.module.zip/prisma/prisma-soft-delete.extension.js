"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.softDeleteExtension = void 0;
const client_1 = require("@prisma/client");
const SOFT_DELETE_MODELS = [
    'User',
    'UserAddress',
    'Admin',
    'Category',
    'Product',
    'Order',
    'ProductReview',
    'Media',
    'EmailTemplate',
    'FAQ',
    'Contact',
    'Blog',
];
const SOFT_DELETE_RELATIONS = [
    'addresses',
    'orders',
    'products',
    'children',
    'parent',
    'reviews',
    'replies',
];
const MEDIA_JOIN_RELATIONS = ['productMedia'];
function injectSoftDeleteFilter(args) {
    if (!args || typeof args !== 'object')
        return;
    const anyArgs = args;
    if (anyArgs.include && typeof anyArgs.include === 'object') {
        const include = anyArgs.include;
        for (const key of Object.keys(include)) {
            const val = include[key];
            if (val === true) {
                if (MEDIA_JOIN_RELATIONS.includes(key)) {
                    include[key] = { where: { media: { deletedAt: null } } };
                }
                else if (SOFT_DELETE_RELATIONS.includes(key)) {
                    include[key] = { where: { deletedAt: null } };
                }
            }
            else if (val && typeof val === 'object') {
                const objVal = val;
                if (MEDIA_JOIN_RELATIONS.includes(key)) {
                    const where = (objVal.where || {});
                    if (!where.media) {
                        where.media = { deletedAt: null };
                    }
                    objVal.where = where;
                }
                else if (SOFT_DELETE_RELATIONS.includes(key)) {
                    const where = (objVal.where || {});
                    objVal.where = where;
                    if (where.deletedAt === undefined) {
                        where.deletedAt = null;
                    }
                }
                injectSoftDeleteFilter(val);
            }
        }
    }
    if (anyArgs.select && typeof anyArgs.select === 'object') {
        const select = anyArgs.select;
        for (const key of Object.keys(select)) {
            const val = select[key];
            if (val && typeof val === 'object') {
                const objVal = val;
                if (SOFT_DELETE_RELATIONS.includes(key)) {
                    const where = (objVal.where || {});
                    objVal.where = where;
                    if (where.deletedAt === undefined) {
                        where.deletedAt = null;
                    }
                }
                injectSoftDeleteFilter(val);
            }
        }
    }
}
exports.softDeleteExtension = client_1.Prisma.defineExtension((client) => {
    return client.$extends({
        name: 'soft-delete',
        model: {
            $allModels: {
                async softDelete(id) {
                    const context = client_1.Prisma.getExtensionContext(this);
                    return await context.update({
                        where: { id },
                        data: { deletedAt: new Date() },
                    });
                },
                async restore(id) {
                    const context = client_1.Prisma.getExtensionContext(this);
                    return await context.update({
                        where: { id },
                        data: { deletedAt: null },
                    });
                },
            },
        },
        query: {
            $allModels: {
                async $allOperations({ model, operation, args, query }) {
                    const anyArgs = args;
                    const readOperations = [
                        'findMany',
                        'findFirst',
                        'findFirstOrThrow',
                        'count',
                        'aggregate',
                        'groupBy',
                    ];
                    if (SOFT_DELETE_MODELS.includes(model)) {
                        if (readOperations.includes(operation)) {
                            const where = (anyArgs.where || {});
                            anyArgs.where = where;
                            if (where.deletedAt === undefined) {
                                where.deletedAt = null;
                            }
                        }
                    }
                    injectSoftDeleteFilter(anyArgs);
                    if (SOFT_DELETE_MODELS.includes(model)) {
                        if (operation === 'findUnique') {
                            const select = anyArgs.select;
                            const hadDeletedAt = select?.deletedAt === true;
                            if (select && !hadDeletedAt) {
                                select.deletedAt = true;
                            }
                            const result = await query(args);
                            const resultObj = result;
                            if (resultObj &&
                                resultObj.deletedAt !== null &&
                                resultObj.deletedAt !== undefined) {
                                return null;
                            }
                            if (resultObj && select && !hadDeletedAt) {
                                delete resultObj.deletedAt;
                            }
                            return result;
                        }
                        if (operation === 'findUniqueOrThrow') {
                            const select = anyArgs.select;
                            const hadDeletedAt = select?.deletedAt === true;
                            if (select && !hadDeletedAt) {
                                select.deletedAt = true;
                            }
                            const result = await query(args);
                            const resultObj = result;
                            if (resultObj &&
                                resultObj.deletedAt !== null &&
                                resultObj.deletedAt !== undefined) {
                                throw new client_1.Prisma.PrismaClientKnownRequestError('An operation failed because it depends on one or more records that were required but not found.', {
                                    code: 'P2025',
                                    clientVersion: client_1.Prisma.prismaVersion.client,
                                });
                            }
                            if (resultObj && select && !hadDeletedAt) {
                                delete resultObj.deletedAt;
                            }
                            return result;
                        }
                        if (operation === 'delete') {
                            const modelContext = client_1.Prisma.getExtensionContext(this);
                            return modelContext.update({
                                where: anyArgs.where,
                                data: { deletedAt: new Date() },
                            });
                        }
                        if (operation === 'deleteMany') {
                            const modelContext = client_1.Prisma.getExtensionContext(this);
                            return modelContext.updateMany({
                                where: anyArgs.where,
                                data: { deletedAt: new Date() },
                            });
                        }
                    }
                    return query(args);
                },
            },
        },
    });
});
//# sourceMappingURL=prisma-soft-delete.extension.js.map