import { EncryptionService } from '../common/services/encryption.service';
export declare const encryptionExtension: (encryptionService: EncryptionService) => (client: any) => {
    $extends: {
        extArgs: import("@prisma/client/runtime/library").InternalArgs<unknown, unknown, {}, unknown>;
    };
};
