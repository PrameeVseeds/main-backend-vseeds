import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EncryptionService } from '../common/services/encryption.service';
export declare class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
    private readonly encryptionService;
    private readonly logger;
    private readonly _client;
    private readonly _baseClient;
    constructor(encryptionService: EncryptionService);
    onModuleInit(): Promise<void>;
    onModuleDestroy(): Promise<void>;
}
