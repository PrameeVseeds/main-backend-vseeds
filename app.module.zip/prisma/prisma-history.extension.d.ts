import { PrismaClient } from '@prisma/client';
export declare const historyExtension: (baseClient: PrismaClient) => (client: any) => {
    $extends: {
        extArgs: import("@prisma/client/runtime/library").InternalArgs<unknown, unknown, {}, unknown>;
    };
};
