// cPanel Passenger startup file — starts the NestJS application
require('./main.js');
